// components/Layout.jsx
import { useState } from 'react';
import Head from 'next/head';
import Ticker from './Ticker';
import Header from './Header';
import Footer from './Footer';
import CartDrawer from './CartDrawer';
import { useCart } from '../lib/CartContext';

export default function Layout({ children, title }) {
  const [cartOpen, setCartOpen] = useState(false);
  const { toast } = useCart();

  return (
    <>
      <Head>
        <title>{title ? `${title} · PlayBeat Digital` : 'PlayBeat Digital'}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      </Head>
      <Ticker />
      <Header onOpenCart={() => setCartOpen(true)} />
      <main>{children}</main>
      <Footer />
      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} />
      <div className={`cart-toast${toast ? ' show' : ''}`}>{toast}</div>
    </>
  );
}
