// components/admin/Modal.jsx
export default function Modal({ title, onClose, children, footer }) {
  return (
    <div className="a-mo" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="a-mo-box">
        <h3>{title}</h3>
        {children}
        {footer && <div className="a-mo-ft">{footer}</div>}
      </div>
    </div>
  );
}
