// components/admin/AdminLayout.jsx
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import { useAdmin } from '../../lib/AdminContext';
import { adminGet } from '../../lib/adminApi';

const NAV = [
  {
    section: 'Overview',
    items: [
      { id: 'dashboard', href: '/admin', label: 'Dashboard', icon: '📊' },
      { id: 'analytics', href: '/admin/analytics', label: 'Analytics', icon: '📈' },
    ],
  },
  {
    section: 'Commerce',
    items: [
      { id: 'orders', href: '/admin/orders', label: 'Orders', icon: '🛒' },
      { id: 'products', href: '/admin/products', label: 'Products', icon: '📦' },
      { id: 'coupons', href: '/admin/coupons', label: 'Coupons', icon: '🏷️' },
      { id: 'customers', href: '/admin/customers', label: 'Customers', icon: '👥' },
    ],
  },
  {
    section: 'Storefront',
    items: [
      { id: 'homepage', href: '/admin/homepage', label: 'Homepage', icon: '🖼️' },
      { id: 'payments', href: '/admin/payments', label: 'Payment Gateways', icon: '💳' },
    ],
  },
  {
    section: 'Settings',
    items: [
      { id: 'roles', href: '/admin/roles', label: 'Roles & Users', icon: '🔑' },
    ],
  },
];

export default function AdminLayout({ title, children }) {
  const router = useRouter();
  const { token, ready, logout, toast } = useAdmin();
  const [apiOk, setApiOk] = useState(null);

  useEffect(() => {
    if (ready && !token) router.replace('/admin/login');
  }, [ready, token, router]);

  useEffect(() => {
    if (!token) return;
    adminGet(token, '/products?limit=1')
      .then(() => setApiOk(true))
      .catch(() => setApiOk(false));
  }, [token]);

  if (!ready || !token) return null;

  return (
    <div className="admin">
      <Head>
        <title>{title} · PlayBeat Admin</title>
      </Head>
      <div className="a-shell">
        <aside className="a-sidebar">
          <div className="a-sb-logo">
            <div className="a-sb-logo-mark">
              <div className="a-sb-bolt">⚡</div>
              <span className="a-sb-name">PlayBeat</span>
            </div>
            <div className="a-sb-sub">Admin Console</div>
          </div>
          <nav className="a-sb-nav">
            {NAV.map((group) => (
              <div key={group.section}>
                <div className="a-sb-label">{group.section}</div>
                {group.items.map((item) => (
                  <div
                    key={item.id}
                    className={`a-sb-item${router.pathname === item.href ? ' active' : ''}`}
                    onClick={() => router.push(item.href)}
                  >
                    <span>{item.icon}</span>
                    <span>{item.label}</span>
                  </div>
                ))}
              </div>
            ))}
          </nav>
          <div className="a-sb-footer">
            <div className="a-user-row" onClick={logout} title="Log out">
              <div className="a-avatar">PB</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="a-u-name">Admin</div>
                <div className="a-u-role">Super Admin · Log out</div>
              </div>
              <div className="a-dot-live" />
            </div>
          </div>
        </aside>

        <div className="a-main">
          <div className="a-conn-bar">
            <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <span
                className="a-cdot"
                style={{
                  background:
                    apiOk === false ? 'var(--red)' : apiOk ? 'var(--green)' : 'var(--amber)',
                }}
              />
              API:{' '}
              <span style={{ color: 'var(--text2)' }}>
                {apiOk === false ? 'offline' : apiOk ? 'connected' : 'checking…'}
              </span>
            </span>
            <span style={{ marginLeft: 'auto' }} />
            <Clock />
          </div>
          <div className="a-topbar">
            <div className="a-tb-title">{title}</div>
          </div>
          <div className="a-content">{children}</div>
        </div>
      </div>
      <div className={`a-toast${toast ? ' show' : ''}`}>{toast}</div>
    </div>
  );
}

function Clock() {
  const [time, setTime] = useState('');
  useEffect(() => {
    function tick() {
      setTime(
        new Date().toLocaleTimeString('en-PK', {
          timeZone: 'Asia/Karachi',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false,
        }) + ' PKT'
      );
    }
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return <span style={{ fontFamily: 'var(--mono)' }}>{time}</span>;
}
