// components/ProductCard.jsx
import { useRouter } from 'next/router';
import { useCart } from '../lib/CartContext';
import { formatPKR } from '../lib/products';

export default function ProductCard({ product, rank }) {
  const router = useRouter();
  const { addToCart, toggleWish, isWished } = useCart();
  const wished = isWished(product.id);

  function goToProduct() {
    router.push(`/product/${product.id}`);
  }

  function buyNow(e) {
    e.stopPropagation();
    addToCart(product);
    router.push('/checkout');
  }

  return (
    <div className="product-card card-silver-glow">
      {rank ? (
        <span className="rank-badge">{rank}</span>
      ) : product.badge ? (
        <span className={product.badge === 'NEW' || product.badge === 'NEW LOW' ? 'badge-new' : 'badge-sale'}>
          {product.badge}
        </span>
      ) : null}
      <button
        className={`wishlist-btn${wished ? ' active' : ''}`}
        onClick={(e) => { e.stopPropagation(); toggleWish(product); }}
        aria-label="Toggle wishlist"
      >
        {wished ? '♥' : '♡'}
      </button>
      <div className="product-card-img" onClick={goToProduct} style={{ cursor: 'pointer' }}>
        {product.emoji}
      </div>
      <div className="product-card-body">
        <div onClick={goToProduct} style={{ cursor: 'pointer' }}>
          <div className="product-card-game">{product.brand}</div>
          <div className="product-card-name">{product.name}</div>
          {product.oldPrice ? (
            <div className="price-row">
              <div className="price">{formatPKR(product.price)}</div>
              <div className="price-old">{formatPKR(product.oldPrice)}</div>
            </div>
          ) : (
            <div className="price">{formatPKR(product.price)}</div>
          )}
        </div>
        <div className="product-offers">
          <button className="add-cart-btn" onClick={(e) => { e.stopPropagation(); addToCart(product); }}>+ Cart</button>
          <button className="buy-btn" onClick={buyNow}>Buy Now</button>
        </div>
      </div>
    </div>
  );
}
