// components/CartDrawer.jsx
import Link from 'next/link';
import { useCart } from '../lib/CartContext';
import { formatPKR } from '../lib/products';

export default function CartDrawer({ open, onClose }) {
  const { cart, removeFromCart, updateQty, cartTotal } = useCart();
  if (!open) return null;

  return (
    <>
      <div className="cart-drawer-backdrop" onClick={onClose} />
      <div className="cart-drawer">
        <button className="close-btn" onClick={onClose} aria-label="Close cart">×</button>
        <h2>Your Cart</h2>
        {cart.length === 0 ? (
          <div className="cart-empty">Your cart is empty.</div>
        ) : (
          <div>
            {cart.map((item) => (
              <div className="cart-line" key={item.id}>
                <div className="cart-line-emoji">{item.emoji}</div>
                <div className="cart-line-info">
                  <div className="cart-line-name">{item.name}</div>
                  <div className="cart-line-price">{formatPKR(item.price)}</div>
                </div>
                <div className="qty-controls">
                  <button onClick={() => updateQty(item.id, item.qty - 1)}>−</button>
                  <span>{item.qty}</span>
                  <button onClick={() => updateQty(item.id, item.qty + 1)}>+</button>
                </div>
                <button className="close-btn" style={{ position: 'static', fontSize: '1rem' }} onClick={() => removeFromCart(item.id)} aria-label="Remove">🗑</button>
              </div>
            ))}
          </div>
        )}
        <div className="cart-drawer-footer">
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem', fontWeight: 700 }}>
            <span>Total</span>
            <span style={{ color: 'var(--accent)' }}>{formatPKR(cartTotal)}</span>
          </div>
          <Link href="/checkout" className="buy-btn" style={{ display: 'block', textAlign: 'center', padding: '0.8rem', borderRadius: '0.6rem' }} onClick={onClose}>
            Checkout
          </Link>
        </div>
      </div>
    </>
  );
}
