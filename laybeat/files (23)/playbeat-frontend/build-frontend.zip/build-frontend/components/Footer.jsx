// components/Footer.jsx
import Link from 'next/link';
import { useState } from 'react';
import { CATEGORIES } from '../lib/products';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [done, setDone] = useState(false);

  function subscribe(e) {
    e.preventDefault();
    if (!email) return;
    setDone(true);
    setEmail('');
  }

  return (
    <footer className="site-footer">
      <div className="footer-inner">
        <div className="footer-banner">
          <Link className="footer-logo" href="/" aria-label="PlayBeat Digital home">
            <span className="footer-logo-digital">Digital</span>
            <div className="footer-logo-wordmark">
              <span className="footer-logo-play">play</span><span className="footer-logo-beat">beat</span>
            </div>
            <div className="footer-logo-pvt">Digital Pvt Ltd</div>
            <div className="footer-logo-line" />
            <p className="footer-tagline">Driven by <span className="ft-play">Play</span>, Defined by <span className="ft-beat">beat.</span></p>
          </Link>
          <div className="footer-support">
            <span className="support-label">Support</span>
            <a className="btn-support email" href="mailto:support@playbeat.gg">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="4" width="20" height="16" rx="2" /><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" /></svg> Email
            </a>
            <a className="btn-support whatsapp" href="https://wa.me/923318333368" target="_blank" rel="noopener noreferrer">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 0 0-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z" /></svg> WhatsApp
            </a>
            <a className="btn-support telegram" href="https://t.me/playbeat" target="_blank" rel="noopener noreferrer">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" /></svg> Telegram
            </a>
          </div>
        </div>
        <div className="footer-grid">
          <div className="footer-col">
            <h3 className="footer-col-title">Marketplace</h3>
            <div className="footer-nav-grid">
              <Link href="/" className="footer-nav-link">🏠 Home</Link>
              {CATEGORIES.map((c) => (
                <Link key={c.slug} href={`/${c.slug}`} className="footer-nav-link">{c.icon} {c.label}</Link>
              ))}
              <Link href="/trending" className="footer-nav-link special">✦ Trending</Link>
            </div>
          </div>
          <div className="footer-col">
            <h3 className="footer-col-title">Discover</h3>
            <ul className="footer-link-list">
              <li><Link href="/trending">✦ Trending</Link></li>
              <li><Link href="/best-value">◈ Best Value</Link></li>
              <li><Link href="/contact">Contact Us</Link></li>
            </ul>
          </div>
          <div className="footer-col">
            <h3 className="footer-col-title">Legal</h3>
            <ul className="footer-link-list">
              <li><Link href="/privacy">Privacy Policy</Link></li>
              <li><Link href="/terms">Terms of Service</Link></li>
              <li><Link href="/refund">Refund Policy</Link></li>
            </ul>
          </div>
          <div className="footer-col">
            <h3 className="footer-col-title">Newsletter</h3>
            <p style={{ fontSize: '11.5px', color: 'var(--text-dim)', lineHeight: 1.75, marginBottom: 14 }}>
              Exclusive deals, flash sales, and new arrivals straight to your inbox.
            </p>
            <form className="footer-nl-row" onSubmit={subscribe}>
              <input type="email" placeholder="your@email.com" value={email} onChange={(e) => setEmail(e.target.value)} />
              <button type="submit">{done ? 'Subscribed ✓' : 'Subscribe'}</button>
            </form>
          </div>
        </div>
        <div className="footer-bottom">
          <p className="footer-copy">© {new Date().getFullYear()} <strong>PlayBeat Digital (Pvt) Ltd</strong> — All rights reserved. Prices in PKR. Reg. No. 00681011050474</p>
          <nav className="footer-legal-links" aria-label="Legal">
            <Link href="/privacy">Privacy</Link><span>·</span>
            <Link href="/terms">Terms</Link><span>·</span>
            <Link href="/refund">Refunds</Link><span>·</span>
            <Link href="/contact">Contact</Link>
          </nav>
        </div>
      </div>
    </footer>
  );
}
