// components/PaymentLogos.jsx
import { useEffect, useState } from 'react';
import Image from 'next/image';
import { getPaymentMethods } from '../lib/api';

// Renders ONLY the logos/names of enabled payment gateways, as returned by
// /api/payments/methods. No keys, account numbers, or secrets ever reach
// this component — that data stays server-side.
export default function PaymentLogos({ selected, onSelect }) {
  const [methods, setMethods] = useState(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    getPaymentMethods()
      .then((data) => setMethods(data.methods))
      .catch(() => setError(true));
  }, []);

  if (error) {
    return (
      <p style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>
        Payment methods unavailable — backend not reachable.
      </p>
    );
  }

  if (!methods) {
    return <p style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>Loading payment methods…</p>;
  }

  if (methods.length === 0) {
    return <p style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>No payment methods are currently enabled.</p>;
  }

  return (
    <div style={{ display: 'flex', gap: '0.6rem', flexWrap: 'wrap' }}>
      {methods.map((m) => (
        <button
          key={m.id}
          type="button"
          onClick={() => onSelect?.(m.id)}
          style={{
            display: 'flex',
            alignItems: 'center',
            padding: '0.5rem 0.75rem',
            borderRadius: '0.5rem',
            border: `1px solid ${selected === m.id ? 'var(--accent)' : 'rgba(199,205,216,0.15)'}`,
            background: selected === m.id ? 'rgba(255,90,79,0.08)' : 'rgba(199,205,216,0.05)',
            cursor: 'pointer',
          }}
        >
          <Image src={m.logo} alt={m.name} width={90} height={24} style={{ height: 24, width: 'auto' }} />
        </button>
      ))}
    </div>
  );
}
