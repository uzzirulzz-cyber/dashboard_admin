// components/Header.jsx
import Link from 'next/link';
import { useRouter } from 'next/router';
import { useState } from 'react';
import { CATEGORIES } from '../lib/products';
import { useCart } from '../lib/CartContext';

const NAV_LINKS = [
  { href: '/', label: 'Home' },
  ...CATEGORIES.map((c) => ({ href: `/${c.slug}`, label: c.label })),
];

export default function Header({ onOpenCart }) {
  const router = useRouter();
  const { cartCount, wishlist } = useCart();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All');

  function doSearch(e) {
    e.preventDefault();
    if (!query.trim()) return;
    router.push(`/search?q=${encodeURIComponent(query.trim())}&cat=${encodeURIComponent(category)}`);
  }

  return (
    <header>
      <div className="header-top">
        <div className="header-top-inner">
          <div className="search-wrap">
            <form className="search-bar" onSubmit={doSearch}>
              <select className="search-category" value={category} onChange={(e) => setCategory(e.target.value)}>
                <option>All</option>
                {CATEGORIES.map((c) => (
                  <option key={c.slug}>{c.label}</option>
                ))}
              </select>
              <span className="search-ico">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
                </svg>
              </span>
              <input
                className="search-input"
                type="text"
                placeholder="Search games, gift cards, subscriptions…"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                autoComplete="off"
              />
              <button className="search-btn" type="submit">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
                </svg> Search
              </button>
            </form>
          </div>
          <div className="top-actions">
            <button className="btn-wish" aria-label="Wishlist" onClick={() => router.push('/wishlist')}>
              <svg width="17" height="17" viewBox="0 0 24 24" fill={wishlist.length ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
              </svg>
            </button>
            <button className="btn-login" onClick={() => router.push('/login')}>Sign In</button>
            <button className="btn-prime" onClick={onOpenCart}>
              🛒 Cart{cartCount > 0 ? ` (${cartCount})` : ''}
            </button>
          </div>
        </div>
      </div>
      <div className="header-inner">
        <Link className="logo" href="/" aria-label="PlayBeat Digital home">
          <span className="logo-digital">Digital</span>
          <div className="logo-wordmark">
            <span className="logo-play">play</span><span className="logo-beat">beat</span>
          </div>
          <div className="logo-pvt">Digital Pvt Ltd</div>
          <div className="logo-underline" />
        </Link>
        <nav aria-label="Main navigation">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`nav-item${router.pathname === link.href ? ' active' : ''}`}
            >
              {link.label}
            </Link>
          ))}
          <div className="nav-sep" />
          <Link href="/trending" className={`nav-item nav-special${router.pathname === '/trending' ? ' active' : ''}`}>✦ Trending</Link>
          <Link href="/best-value" className={`nav-item nav-outsource${router.pathname === '/best-value' ? ' active' : ''}`}>◈ Best Value</Link>
        </nav>
      </div>
    </header>
  );
}
