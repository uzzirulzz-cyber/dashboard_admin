// components/Ticker.jsx
const DEALS = [
  '✦ ChatGPT Plus — PKR 5,999',
  '✦ Netflix 4K — PKR 699',
  '✦ PUBG UC 1800 — PKR 1,799',
  '✦ Steam Wallet ₨5000 — PKR 5,200',
  '✦ Valorant Elderflame — PKR 7,999',
  '✦ MS Office 365 — PKR 2,499',
  '✦ Midjourney — PKR 2,999',
  '✦ Free Fire 1000💎 — PKR 1,499',
];

export default function Ticker() {
  const text = DEALS.join(' \u00A0');
  return (
    <div className="ticker-bar">
      <div className="ticker-inner">
        <span className="t-live"><span className="pulse" />LIVE DEALS</span>
        <span>{text}</span>
        <span className="t-live"><span className="pulse" />LIVE DEALS</span>
        <span>{text}</span>
      </div>
    </div>
  );
}
