# PlayBeat Digital — Frontend (Next.js 14)

## Setup

```bash
npm install
cp .env.local.example .env.local   # set NEXT_PUBLIC_API_URL
npm run dev                         # http://localhost:3000
```

---

## Storefront pages

| Route | File |
|-------|------|
| `/` | `pages/index.js` |
| `/[category]` | `pages/[category].js` (games, gift-cards, software, ai-tools, game-items, accounts) |
| `/product/[id]` | `pages/product/[id].js` |
| `/checkout` | `pages/checkout.js` |
| `/trending`, `/best-value` | curated listing pages |
| `/search` | `pages/search.js` |
| `/wishlist` | `pages/wishlist.js` |
| `/login` | `pages/login.js` (customer login) |
| `/contact`, `/privacy`, `/terms`, `/refund` | static pages |

---

## Admin panel (`/admin/*`)

All admin routes require a valid JWT (stored in `localStorage` as `pb_admin_token`).  
Login: `/admin/login` → authenticates against `POST /api/admin/login`.

| Route | File | Description |
|-------|------|-------------|
| `/admin/login` | `pages/admin/login.js` | Auth page |
| `/admin` | `pages/admin/index.js` | Dashboard — KPIs, revenue chart, payment mix, recent orders |
| `/admin/analytics` | `pages/admin/analytics.js` | Deep analytics: daily revenue, DoW heatmap, top products, top customers, gateway/status split |
| `/admin/orders` | `pages/admin/orders.js` | Searchable order log, status/key/notes editor |
| `/admin/products` | `pages/admin/products.js` | Full product CRUD, stock badges, category filter |
| `/admin/coupons` | `pages/admin/coupons.js` | Coupon CRUD — percent or fixed, expiry, usage limits, quick toggle |
| `/admin/customers` | `pages/admin/customers.js` | Customer directory (aggregated from orders), profile + order history modal |
| `/admin/homepage` | `pages/admin/homepage.js` | Homepage editor — announcement bar, ticker items, hero banners, featured categories, SEO |
| `/admin/payments` | `pages/admin/payments.js` | Gateway cards with on/off toggles and masked key status |
| `/admin/roles` | `pages/admin/roles.js` | Admin user management — create, assign roles, set extra permissions |

### Admin architecture

```
pages/admin/*.js
  └─ AdminLayout  (sidebar, status bar, PKT clock, toast)
       └─ AdminContext  (JWT state, login/logout, showToast)
            └─ adminApi.js  (adminGet/Post/Patch/Delete + validateCoupon)
                 └─ Express /api/admin/*
```

### Sidebar nav groups

| Section | Pages |
|---------|-------|
| Overview | Dashboard, Analytics |
| Commerce | Orders, Products, Coupons, Customers |
| Storefront | Homepage, Payment Gateways |
| Settings | Roles & Users |

---

## Coupon validation at checkout

```js
import { validateCoupon } from '../lib/adminApi';

const { coupon, discount } = await validateCoupon('SUMMER20', cartTotal);
// discount = PKR amount to subtract
```

---

## Env vars

| Variable | Default | Notes |
|----------|---------|-------|
| `NEXT_PUBLIC_API_URL` | `http://localhost:5000/api` | Backend base URL |

---

## Design system

All admin UI lives under `.admin { … }` — fully scoped, doesn't touch storefront styles.

Key CSS classes: `.a-card`, `.a-metric`, `.a-pill`, `.a-btn / .a-bp / .a-bs`, `.a-tgl`, `.a-grid-2/3/4`, `.a-callout-*`, `.a-toast`.
