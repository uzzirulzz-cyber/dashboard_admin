// pages/index.js
import Link from 'next/link';
import Layout from '../components/Layout';
import ProductCard from '../components/ProductCard';
import { getProductById, formatPKR } from '../lib/products';

const HERO_PRODUCTS = [
  'chatgpt-plus---1-month',
  'netflix-premium-4k---1-month',
  'steam-wallet-5000',
  'pubg-mobile-uc---1800-uc',
  'ms-office-365-personal---1yr',
  'spotify-premium---3-months',
];

const HOT = ['steam-wallet-5000', 'chatgpt-plus---1-month', 'pubg-mobile-uc---1800-uc'];
const TRENDING = ['netflix-premium-4k---1-month', 'valorant-elderflame-bundle', 'ak-47-redline-field-tested'];
const POPULAR = ['roblox-400-robux', 'windows-11-pro---digital-key', 'conqueror-account---season-20'];

const FEATURED = [
  'chatgpt-plus---1-month', 'netflix-premium-4k---1-month', 'pubg-mobile-uc---1800-uc',
  'ms-office-365-personal---1yr', 'steam-wallet-5000', 'free-fire---1000-diamonds',
  'valorant-elderflame-bundle', 'spotify-premium---3-months', 'windows-11-pro---digital-key',
  'xbox-game-pass-ultimate---1-month', 'midjourney-basic---1-month', 'mobile-legends---86-diamonds',
];

function HtpColumn({ icon, title, tag, ids }) {
  return (
    <div className="htp-col">
      <div className="htp-col-head">
        <span style={{ fontSize: '1.1rem' }}>{icon}</span>
        <span className="htp-col-title">{title}</span>
        <span className="htp-col-tag">{tag}</span>
      </div>
      {ids.map((id, i) => {
        const p = getProductById(id);
        if (!p) return null;
        return (
          <Link href={`/product/${p.id}`} className="htp-item" key={id}>
            <span className="htp-num">{String(i + 1).padStart(2, '0')}</span>
            <span className="htp-emoji">{p.emoji}</span>
            <div>
              <p className="htp-name">{p.name}</p>
              <p className="htp-price">{formatPKR(p.price)}</p>
            </div>
          </Link>
        );
      })}
    </div>
  );
}

export default function Home() {
  return (
    <Layout title="Home">
      {/* Hero */}
      <section className="wrap hero">
        <div>
          <span className="hero-badge">✦ Pakistan&apos;s Trusted Digital Marketplace</span>
          <h1>Everything Digital.<br />One Platform.</h1>
          <p className="lead">Games, Gift Cards, AI Tools, Software, Accounts, Subscriptions &amp; Top-Ups delivered instantly worldwide.</p>
          <div className="hero-ctas">
            <Link href="/trending" className="btn-primary">Shop Now</Link>
            <Link href="/games" className="btn-secondary">Explore Categories</Link>
          </div>
          <div className="trust-grid">
            <p>✓ Instant Delivery</p>
            <p>✓ Secure Payments</p>
            <p>✓ PKR Pricing</p>
            <p>✓ 24/7 Support</p>
          </div>
        </div>
        <div className="hero-grid">
          {HERO_PRODUCTS.map((id) => {
            const p = getProductById(id);
            if (!p) return null;
            return (
              <Link href={`/product/${p.id}`} className="hero-product" key={id}>
                {p.oldPrice && (
                  <span className="hero-product-badge">
                    -{Math.round(((p.oldPrice - p.price) / p.oldPrice) * 100)}%
                  </span>
                )}
                <div style={{ fontSize: '1.8rem', marginBottom: '0.4rem' }}>{p.emoji}</div>
                <div className="hero-product-name">{p.name}</div>
                <div className="hero-product-price">{formatPKR(p.price)}</div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Hot / Trending / Popular */}
      <section className="wrap" style={{ paddingTop: '1rem', paddingBottom: '3rem' }}>
        <div className="section-header">
          <div>
            <div className="section-eyebrow">Right Now in Heaven</div>
            <h2 className="section-title">Hot · Trending · Popular</h2>
          </div>
          <Link href="/trending" className="section-link">View all →</Link>
        </div>
        <div className="htp-grid">
          <HtpColumn icon="🔥" title="Hot" tag="Limited" ids={HOT} />
          <HtpColumn icon="📈" title="Trending" tag="Today" ids={TRENDING} />
          <HtpColumn icon="⭐" title="Popular" tag="All Time" ids={POPULAR} />
        </div>
      </section>

      {/* Stats */}
      <section className="wrap" style={{ paddingBottom: '3.5rem' }}>
        <div className="stats-bar">
          <div className="stat-item"><p className="stat-num">10,000+</p><p className="stat-label">Customers</p></div>
          <div className="stat-item"><p className="stat-num">500+</p><p className="stat-label">Products</p></div>
          <div className="stat-item"><p className="stat-num">99.9%</p><p className="stat-label">Delivery Success</p></div>
          <div className="stat-item"><p className="stat-num">24/7</p><p className="stat-label">Support</p></div>
        </div>
      </section>

      {/* Featured This Week */}
      <section className="wrap" style={{ paddingBottom: '3rem' }}>
        <div className="section-header">
          <div>
            <div className="section-eyebrow">Curated For You</div>
            <h2 className="section-title">Featured This Week</h2>
          </div>
          <Link href="/trending" className="section-link">View all →</Link>
        </div>
        <div className="product-grid">
          {FEATURED.map((id) => {
            const p = getProductById(id);
            return p ? <ProductCard product={p} key={id} /> : null;
          })}
        </div>

        <div className="promo-pair">
          <div className="promo-card prime">
            <span className="promo-icon">🤖</span>
            <div className="promo-tag">AI Tools</div>
            <div className="promo-title">Power Up With AI</div>
            <p className="promo-sub">ChatGPT, Midjourney, Claude Pro &amp; Gemini Advanced — activated on your own account within minutes.</p>
            <Link href="/ai-tools" className="promo-btn">Explore AI Tools →</Link>
          </div>
          <div className="promo-card silver">
            <span className="promo-icon">📺</span>
            <div className="promo-tag">Subscriptions</div>
            <div className="promo-title">Stream Without Limits</div>
            <p className="promo-sub">Netflix, Disney+, Spotify &amp; Xbox Game Pass — every screen, every show, one marketplace.</p>
            <Link href="/subscriptions" className="promo-btn">Browse Subscriptions →</Link>
          </div>
        </div>
      </section>
    </Layout>
  );
}
