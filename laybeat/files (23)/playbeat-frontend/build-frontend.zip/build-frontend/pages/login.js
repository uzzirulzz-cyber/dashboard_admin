// pages/login.js
import { useState } from 'react';
import Layout from '../components/Layout';
import { useCart } from '../lib/CartContext';

export default function LoginPage() {
  const [mode, setMode] = useState('signin');
  const { showToast } = useCart();

  function handleSubmit(e) {
    e.preventDefault();
    // TODO: call Express /api/auth/login or /api/auth/register, store JWT.
    showToast('Auth placeholder — backend not connected yet');
  }

  return (
    <Layout title="Sign In">
      <div className="wrap" style={{ paddingTop: '28px', paddingBottom: '64px', maxWidth: '28rem' }}>
        <div className="cat-banner">
          <div className="section-eyebrow">Account</div>
          <h1>{mode === 'signin' ? 'Sign In' : 'Create Account'}</h1>
          <p>Access your orders, wishlist and saved details.</p>
        </div>
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.9rem', marginTop: '1.5rem' }}>
          {mode === 'register' && (
            <input className="search-input" style={{ background: 'rgba(199,205,216,0.06)', border: '1px solid rgba(199,205,216,0.15)', borderRadius: '0.5rem', padding: '0.7rem' }}
              placeholder="Full name" required />
          )}
          <input className="search-input" style={{ background: 'rgba(199,205,216,0.06)', border: '1px solid rgba(199,205,216,0.15)', borderRadius: '0.5rem', padding: '0.7rem' }}
            type="email" placeholder="Email address" required />
          <input className="search-input" style={{ background: 'rgba(199,205,216,0.06)', border: '1px solid rgba(199,205,216,0.15)', borderRadius: '0.5rem', padding: '0.7rem' }}
            type="password" placeholder="Password" required />
          <button className="buy-btn" type="submit" style={{ padding: '0.9rem', borderRadius: '0.6rem', fontSize: '0.9rem' }}>
            {mode === 'signin' ? 'Sign In' : 'Create Account'}
          </button>
        </form>
        <p style={{ marginTop: '1rem', fontSize: '0.8rem', color: 'var(--text-dim)' }}>
          {mode === 'signin' ? "Don't have an account? " : 'Already have an account? '}
          <button onClick={() => setMode(mode === 'signin' ? 'register' : 'signin')}
            style={{ background: 'none', border: 'none', color: 'var(--accent)', cursor: 'pointer', fontSize: '0.8rem', padding: 0 }}>
            {mode === 'signin' ? 'Create one' : 'Sign in'}
          </button>
        </p>
      </div>
    </Layout>
  );
}
