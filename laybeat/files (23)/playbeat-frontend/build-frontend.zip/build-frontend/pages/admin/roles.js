// pages/admin/roles.js
import { useEffect, useState, useCallback } from 'react';
import AdminLayout from '../../components/admin/AdminLayout';
import Modal from '../../components/admin/Modal';
import { useAdmin } from '../../lib/AdminContext';
import { adminGet, adminPost, adminPatch, adminDelete } from '../../lib/adminApi';
import { fmtDate } from './index';

const ROLE_LABELS = {
  super_admin: { label: 'Super Admin', cls: 'a-pgo', desc: 'Full access to everything' },
  manager: { label: 'Manager', cls: 'a-pb', desc: 'Orders, products, coupons, homepage' },
  support: { label: 'Support', cls: 'a-pg', desc: 'View orders and customers' },
  viewer: { label: 'Viewer', cls: 'a-pa', desc: 'Dashboard and analytics read-only' },
};

const EMPTY = {
  name: '',
  email: '',
  password: '',
  role: 'viewer',
  permissions: [],
  active: true,
};

export default function AdminRolesPage() {
  const { token, showToast } = useAdmin();
  const [users, setUsers] = useState(null);
  const [roles, setRoles] = useState([]);
  const [permissions, setPermissions] = useState([]);
  const [modal, setModal] = useState(null);

  const load = useCallback(() => {
    if (!token) return;
    adminGet(token, '/admin/users')
      .then((d) => { setUsers(d.users); setRoles(d.roles); setPermissions(d.permissions); })
      .catch((err) => showToast('⚠ ' + err.message));
  }, [token, showToast]);

  useEffect(() => { load(); }, [load]);

  function setField(k, v) {
    setModal((m) => ({ ...m, form: { ...m.form, [k]: v } }));
  }

  function togglePerm(p) {
    const prev = modal.form.permissions || [];
    const next = prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p];
    setField('permissions', next);
  }

  async function save() {
    const { mode, id, form } = modal;
    const payload = { ...form };
    if (!payload.password) delete payload.password; // don't send empty password on edit
    try {
      if (mode === 'add') {
        await adminPost(token, '/admin/users', payload);
        showToast('✅ Admin user created');
      } else {
        await adminPatch(token, `/admin/users/${id}`, payload);
        showToast('✅ User updated');
      }
      setModal(null);
      load();
    } catch (err) {
      showToast('❌ ' + err.message);
    }
  }

  async function remove() {
    if (!confirm(`Remove "${modal.form.name}"? They will lose admin access immediately.`)) return;
    try {
      await adminDelete(token, `/admin/users/${modal.id}`);
      showToast('🗑 User removed');
      setModal(null);
      load();
    } catch (err) {
      showToast('❌ ' + err.message);
    }
  }

  return (
    <AdminLayout title="Roles & Admin Users">
      {/* Role reference */}
      <div className="a-grid-4" style={{ marginBottom: 18 }}>
        {Object.entries(ROLE_LABELS).map(([role, info]) => (
          <div className="a-metric" key={role}>
            <div className="a-m-label" style={{ marginBottom: 6 }}><span className={`a-pill ${info.cls}`}>{info.label}</span></div>
            <div style={{ fontSize: 12, color: 'var(--text2)', lineHeight: 1.5 }}>{info.desc}</div>
          </div>
        ))}
      </div>

      <div className="a-card">
        <div className="a-card-hd">
          <span className="a-card-title">Admin Users</span>
          <span className="a-card-sub">{users ? users.length : '—'} users</span>
          <button className="a-btn a-bs a-bp" onClick={() => setModal({ mode: 'add', form: { ...EMPTY } })}>+ Invite Admin</button>
        </div>

        {!users ? (
          <p style={{ color: 'var(--text3)', fontSize: 12 }}>Loading…</p>
        ) : users.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 24 }}>
            <p style={{ color: 'var(--text3)', fontSize: 13, marginBottom: 12 }}>
              No admin users in the database yet. The current login uses your <code>.env</code> credentials.
            </p>
            <p style={{ color: 'var(--text3)', fontSize: 12 }}>
              Create the first admin user above to switch to DB-backed login.
            </p>
          </div>
        ) : (
          <table>
            <thead>
              <tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Last Login</th><th></th></tr>
            </thead>
            <tbody>
              {users.map((u) => {
                const ri = ROLE_LABELS[u.role] || { label: u.role, cls: 'a-pa' };
                return (
                  <tr key={u.id}>
                    <td style={{ fontWeight: 600 }}>
                      <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                        <div style={{ width: 28, height: 28, borderRadius: 7, background: 'linear-gradient(135deg,var(--accent),var(--gold))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, flexShrink: 0 }}>
                          {u.avatarInitials}
                        </div>
                        {u.name}
                      </div>
                    </td>
                    <td style={{ fontSize: 12, color: 'var(--text2)' }}>{u.email}</td>
                    <td><span className={`a-pill ${ri.cls}`}>{ri.label}</span></td>
                    <td>{u.active ? <span className="a-pill a-pg">Active</span> : <span className="a-pill a-pr">Disabled</span>}</td>
                    <td style={{ color: 'var(--text3)', fontSize: 12 }}>{u.lastLoginAt ? fmtDate(u.lastLoginAt) : '—'}</td>
                    <td>
                      <button
                        className="a-btn a-bi a-bs"
                        title="Edit"
                        onClick={() => setModal({
                          mode: 'edit',
                          id: u.id,
                          form: { ...EMPTY, name: u.name, email: u.email, role: u.role, permissions: u.permissions || [], active: u.active, password: '' },
                        })}
                      >✎</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {modal && (
        <Modal
          title={modal.mode === 'add' ? 'Invite Admin User' : `Edit — ${modal.form.name}`}
          onClose={() => setModal(null)}
          footer={<>
            {modal.mode === 'edit' && <button className="a-btn a-bd" style={{ marginRight: 'auto' }} onClick={remove}>Remove</button>}
            <button className="a-btn" onClick={() => setModal(null)}>Cancel</button>
            <button className="a-btn a-bp" onClick={save}>
              {modal.mode === 'add' ? 'Create User' : 'Save Changes'}
            </button>
          </>}
        >
          <div className="a-frow">
            <div className="a-fg">
              <label>Full Name *</label>
              <input type="text" placeholder="Ali Hassan" value={modal.form.name} onChange={(e) => setField('name', e.target.value)} />
            </div>
            <div className="a-fg">
              <label>Email *</label>
              <input type="email" placeholder="ali@playbeat.gg" value={modal.form.email} onChange={(e) => setField('email', e.target.value)} />
            </div>
          </div>

          <div className="a-frow">
            <div className="a-fg">
              <label>{modal.mode === 'add' ? 'Password *' : 'New Password (leave blank to keep)'}</label>
              <input type="password" placeholder={modal.mode === 'add' ? 'Min 8 chars' : '••••••••'} value={modal.form.password} onChange={(e) => setField('password', e.target.value)} />
            </div>
            <div className="a-fg">
              <label>Role</label>
              <select value={modal.form.role} onChange={(e) => setField('role', e.target.value)}>
                {roles.map((r) => <option key={r} value={r}>{ROLE_LABELS[r]?.label || r}</option>)}
              </select>
            </div>
          </div>

          <div className="a-fg">
            <label>Status</label>
            <select value={modal.form.active ? '1' : '0'} onChange={(e) => setField('active', e.target.value === '1')}>
              <option value="1">Active</option>
              <option value="0">Disabled</option>
            </select>
          </div>

          <div className="a-fg">
            <label style={{ marginBottom: 8 }}>Extra Permissions (in addition to role defaults)</label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {permissions.map((p) => {
                const on = modal.form.permissions?.includes(p);
                return (
                  <button
                    key={p}
                    type="button"
                    className={`a-btn a-bs${on ? ' a-bp' : ''}`}
                    onClick={() => togglePerm(p)}
                    style={{ fontSize: 11 }}
                  >
                    {on ? '✓ ' : ''}{p.replace('_', ' ')}
                  </button>
                );
              })}
            </div>
            <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 6 }}>
              Role <span className={`a-pill ${ROLE_LABELS[modal.form.role]?.cls || 'a-pa'}`} style={{ fontSize: 10 }}>{ROLE_LABELS[modal.form.role]?.label || modal.form.role}</span> already includes its default permissions — only add extras here.
            </div>
          </div>
        </Modal>
      )}
    </AdminLayout>
  );
}
