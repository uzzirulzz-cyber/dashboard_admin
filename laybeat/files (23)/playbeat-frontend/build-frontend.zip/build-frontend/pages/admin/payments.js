// pages/admin/payments.js
import { useEffect, useState, useCallback } from 'react';
import Image from 'next/image';
import AdminLayout from '../../components/admin/AdminLayout';
import { useAdmin } from '../../lib/AdminContext';
import { adminGet, adminPatch } from '../../lib/adminApi';

export default function AdminPaymentsPage() {
  const { token, showToast } = useAdmin();
  const [gateways, setGateways] = useState(null);

  const load = useCallback(() => {
    if (!token) return;
    adminGet(token, '/admin/gateways')
      .then((data) => setGateways(data.gateways))
      .catch((err) => showToast('⚠ ' + err.message));
  }, [token, showToast]);

  useEffect(() => { load(); }, [load]);

  async function toggle(id, enabled) {
    setGateways((g) => ({ ...g, [id]: { ...g[id], enabled } }));
    try {
      await adminPatch(token, `/admin/gateways/${id}`, { enabled });
      showToast(`${enabled ? '✅' : '⏸'} ${gateways[id].label} ${enabled ? 'enabled' : 'disabled'}`);
    } catch (err) {
      showToast('❌ ' + err.message);
      setGateways((g) => ({ ...g, [id]: { ...g[id], enabled: !enabled } }));
    }
  }

  return (
    <AdminLayout title="Payment Gateways">
      <div style={{ background: 'rgba(79,160,255,.08)', border: '1px solid rgba(79,160,255,.25)', borderRadius: 12, padding: '12px 18px', marginBottom: 18, display: 'flex', gap: 12, fontSize: 13, color: 'var(--blue)' }}>
        <span style={{ fontSize: 18 }}>🛡️</span>
        <div>
          <strong>Credentials stored server-side only.</strong> API keys, secrets, merchant passwords, and hash keys
          live in the backend&apos;s <code>.env</code> file and are never exposed in this panel — only masked
          previews and configured/not-configured status. The on/off toggles below control which logos appear at checkout.
        </div>
      </div>

      {!gateways ? (
        <p style={{ color: 'var(--text3)', fontSize: 12 }}>Loading…</p>
      ) : (
        <div className="a-gw-grid">
          {Object.entries(gateways).map(([id, gw]) => (
            <div className={`a-gw-card${gw.enabled ? '' : ' a-gw-off'}`} key={id}>
              <div className="a-gw-head">
                <div className="a-gw-logo">
                  <Image src={gw.logo} alt={gw.label} width={48} height={28} style={{ width: 'auto', height: 28 }} />
                </div>
                <div>
                  <div className="a-gw-name">{gw.label}</div>
                  <div className="a-gw-reg">{gw.description}</div>
                </div>
              </div>

              <div className="a-gw-sr">
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{gw.enabled ? 'Visible at checkout' : 'Hidden from checkout'}</div>
                  {gw.mode && <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 2 }}>mode: {gw.mode}</div>}
                </div>
                <label className="a-tgl">
                  <input type="checkbox" checked={gw.enabled} onChange={(e) => toggle(id, e.target.checked)} />
                  <span className="a-tgl-sl" />
                </label>
              </div>

              <div className="a-gw-fields">
                {gw.secretFields.map((f) => (
                  <div key={f.field} style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span className="mono">{f.field}</span>
                    {f.configured
                      ? <span className="mono" style={{ color: 'var(--gold2)' }}>{f.preview}</span>
                      : <span style={{ color: 'var(--red)' }}>not set</span>}
                  </div>
                ))}
              </div>

              <div className="a-gw-note">
                <span>🔒</span>
                <span>Keys configured via backend <code>.env</code> — <strong style={{ color: 'var(--gold2)' }}>never shown in full here</strong>.</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </AdminLayout>
  );
}
