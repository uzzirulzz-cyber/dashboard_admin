// pages/admin/coupons.js
import { useEffect, useState, useCallback } from 'react';
import AdminLayout from '../../components/admin/AdminLayout';
import Modal from '../../components/admin/Modal';
import { useAdmin } from '../../lib/AdminContext';
import { adminGet, adminPost, adminPatch, adminDelete } from '../../lib/adminApi';
import { fmtDate } from './index';

const EMPTY = {
  code: '',
  type: 'percent',
  value: '',
  minOrder: '',
  maxUses: '',
  expiresAt: '',
  active: true,
  description: '',
};

function usageLabel(c) {
  if (c.maxUses === null || c.maxUses === undefined) return `${c.usedCount} used / ∞`;
  return `${c.usedCount} / ${c.maxUses} used`;
}

function isExpired(c) {
  if (!c.expiresAt) return false;
  return new Date(c.expiresAt) < new Date();
}

export default function AdminCouponsPage() {
  const { token, showToast } = useAdmin();
  const [coupons, setCoupons] = useState(null);
  const [q, setQ] = useState('');
  const [modal, setModal] = useState(null);

  const load = useCallback(() => {
    if (!token) return;
    const params = new URLSearchParams();
    if (q) params.set('q', q);
    adminGet(token, `/admin/coupons?${params}`)
      .then((d) => setCoupons(d.coupons))
      .catch((err) => showToast('⚠ ' + err.message));
  }, [token, q, showToast]);

  useEffect(() => { load(); }, [load]);

  function setField(k, v) {
    setModal((m) => ({ ...m, form: { ...m.form, [k]: v } }));
  }

  async function save() {
    const { mode, id, form } = modal;
    const payload = {
      ...form,
      code: form.code.toUpperCase().trim(),
      value: Number(form.value),
      minOrder: form.minOrder === '' ? 0 : Number(form.minOrder),
      maxUses: form.maxUses === '' ? null : Number(form.maxUses),
      expiresAt: form.expiresAt || null,
    };
    try {
      if (mode === 'add') {
        await adminPost(token, '/admin/coupons', payload);
        showToast('✅ Coupon created');
      } else {
        await adminPatch(token, `/admin/coupons/${id}`, payload);
        showToast('✅ Coupon updated');
      }
      setModal(null);
      load();
    } catch (err) {
      showToast('❌ ' + err.message);
    }
  }

  async function remove() {
    if (!confirm(`Delete coupon "${modal.form.code}"?`)) return;
    try {
      await adminDelete(token, `/admin/coupons/${modal.id}`);
      showToast('🗑 Coupon deleted');
      setModal(null);
      load();
    } catch (err) {
      showToast('❌ ' + err.message);
    }
  }

  async function quickToggle(c) {
    try {
      await adminPatch(token, `/admin/coupons/${c._id}`, { active: !c.active });
      showToast(`${!c.active ? '✅ Enabled' : '⏸ Disabled'} ${c.code}`);
      load();
    } catch (err) {
      showToast('❌ ' + err.message);
    }
  }

  return (
    <AdminLayout title="Coupons">
      <div className="a-card">
        <div className="a-card-hd">
          <span className="a-card-title">Discount Coupons</span>
          <span className="a-card-sub">{coupons ? coupons.length : '—'} coupons</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <input type="search" placeholder="Search code…" value={q} onChange={(e) => setQ(e.target.value)} style={{ width: 160 }} />
            <button className="a-btn a-bs a-bp" onClick={() => setModal({ mode: 'add', form: { ...EMPTY } })}>+ New Coupon</button>
          </div>
        </div>

        {!coupons ? (
          <p style={{ color: 'var(--text3)', fontSize: 12 }}>Loading…</p>
        ) : coupons.length === 0 ? (
          <p style={{ color: 'var(--text3)', fontSize: 12, textAlign: 'center', padding: 24 }}>No coupons yet — create one above</p>
        ) : (
          <table>
            <thead>
              <tr><th>Code</th><th>Discount</th><th>Min Order</th><th>Usage</th><th>Expires</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
              {coupons.map((c) => {
                const expired = isExpired(c);
                return (
                  <tr key={c._id}>
                    <td>
                      <span className="mono" style={{ fontWeight: 700, color: 'var(--gold2)', letterSpacing: 1, fontSize: 13 }}>{c.code}</span>
                      {c.description && <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 2 }}>{c.description}</div>}
                    </td>
                    <td className="mono">
                      {c.type === 'percent' ? `${c.value}%` : `PKR ${c.value.toLocaleString()}`}
                    </td>
                    <td style={{ color: 'var(--text3)', fontSize: 12 }}>
                      {c.minOrder > 0 ? `PKR ${c.minOrder.toLocaleString()}` : '—'}
                    </td>
                    <td style={{ fontSize: 12 }}>{usageLabel(c)}</td>
                    <td style={{ color: expired ? 'var(--red)' : 'var(--text3)', fontSize: 12 }}>
                      {c.expiresAt ? fmtDate(c.expiresAt) : '∞'}
                    </td>
                    <td>
                      {expired ? (
                        <span className="a-pill a-pr">Expired</span>
                      ) : c.active ? (
                        <span className="a-pill a-pg">Active</span>
                      ) : (
                        <span className="a-pill a-pa">Paused</span>
                      )}
                    </td>
                    <td style={{ whiteSpace: 'nowrap' }}>
                      <button
                        className="a-btn a-bi a-bs"
                        title={c.active ? 'Disable' : 'Enable'}
                        onClick={() => quickToggle(c)}
                        style={{ marginRight: 4 }}
                      >
                        {c.active ? '⏸' : '▶'}
                      </button>
                      <button
                        className="a-btn a-bi a-bs"
                        title="Edit"
                        onClick={() => setModal({
                          mode: 'edit',
                          id: c._id,
                          form: {
                            ...EMPTY,
                            ...c,
                            minOrder: c.minOrder ?? '',
                            maxUses: c.maxUses ?? '',
                            expiresAt: c.expiresAt ? c.expiresAt.slice(0, 10) : '',
                          },
                        })}
                      >✎</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {modal && (
        <Modal
          title={modal.mode === 'add' ? 'New Coupon' : `Edit — ${modal.form.code}`}
          onClose={() => setModal(null)}
          footer={<>
            {modal.mode === 'edit' && <button className="a-btn a-bd" style={{ marginRight: 'auto' }} onClick={remove}>Delete</button>}
            <button className="a-btn" onClick={() => setModal(null)}>Cancel</button>
            <button className="a-btn a-bp" onClick={save}>Save Coupon</button>
          </>}
        >
          <div className="a-frow">
            <div className="a-fg">
              <label>Code *</label>
              <input
                type="text"
                placeholder="SUMMER20"
                value={modal.form.code}
                onChange={(e) => setField('code', e.target.value.toUpperCase())}
                style={{ textTransform: 'uppercase', letterSpacing: 1 }}
              />
            </div>
            <div className="a-fg">
              <label>Type *</label>
              <select value={modal.form.type} onChange={(e) => setField('type', e.target.value)}>
                <option value="percent">Percentage (%)</option>
                <option value="fixed">Fixed Amount (PKR)</option>
              </select>
            </div>
          </div>

          <div className="a-frow">
            <div className="a-fg">
              <label>{modal.form.type === 'percent' ? 'Discount %' : 'Discount PKR'} *</label>
              <input type="number" placeholder={modal.form.type === 'percent' ? '20' : '500'} value={modal.form.value} onChange={(e) => setField('value', e.target.value)} />
            </div>
            <div className="a-fg">
              <label>Min Cart Total (PKR)</label>
              <input type="number" placeholder="0 = no minimum" value={modal.form.minOrder} onChange={(e) => setField('minOrder', e.target.value)} />
            </div>
          </div>

          <div className="a-frow">
            <div className="a-fg">
              <label>Max Uses</label>
              <input type="number" placeholder="Blank = unlimited" value={modal.form.maxUses} onChange={(e) => setField('maxUses', e.target.value)} />
            </div>
            <div className="a-fg">
              <label>Expires On</label>
              <input type="date" value={modal.form.expiresAt} onChange={(e) => setField('expiresAt', e.target.value)} />
            </div>
          </div>

          <div className="a-fg">
            <label>Internal Description</label>
            <input type="text" placeholder="e.g. Summer sale coupon for influencer X" value={modal.form.description} onChange={(e) => setField('description', e.target.value)} />
          </div>

          <div className="a-fg">
            <label>Status</label>
            <select value={modal.form.active ? '1' : '0'} onChange={(e) => setField('active', e.target.value === '1')}>
              <option value="1">Active</option>
              <option value="0">Paused</option>
            </select>
          </div>
        </Modal>
      )}
    </AdminLayout>
  );
}
