// pages/admin/analytics.js
import { useEffect, useState } from 'react';
import AdminLayout from '../../components/admin/AdminLayout';
import { useAdmin } from '../../lib/AdminContext';
import { adminGet } from '../../lib/adminApi';
import { formatPKR } from '../../lib/products';

const RANGES = [
  { label: '7d', value: 7 },
  { label: '30d', value: 30 },
  { label: '90d', value: 90 },
  { label: '365d', value: 365 },
];

const GW_COLORS = { stripe: '#6772e5', jazzcash: '#e53935', alfalah: '#1565c0', meezan: '#00897b' };
const DOW_COLORS = ['#a0a0ff', '#7c6cff', '#9d6fff', '#b46fff', '#c46fff', '#d47fff', '#a0a0ff'];

export default function AdminAnalyticsPage() {
  const { token, showToast } = useAdmin();
  const [range, setRange] = useState(30);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!token) return;
    setLoading(true);
    adminGet(token, `/admin/analytics?range=${range}`)
      .then((d) => setData(d))
      .catch((err) => showToast('⚠ ' + err.message))
      .finally(() => setLoading(false));
  }, [token, range, showToast]);

  const maxRev = data?.revenueSeries?.length
    ? Math.max(...data.revenueSeries.map((d) => d.revenue), 1) : 1;

  const maxDow = data?.dowBreakdown?.length
    ? Math.max(...data.dowBreakdown.map((d) => d.orders), 1) : 1;

  const totalGwRev = data?.gwBreakdown?.reduce((s, g) => s + g.revenue, 0) || 0;

  return (
    <AdminLayout title="Analytics">
      {/* Range switcher */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
        {RANGES.map((r) => (
          <button
            key={r.value}
            className={`a-btn a-bs${range === r.value ? ' a-bp' : ''}`}
            onClick={() => setRange(r.value)}
          >
            {r.label}
          </button>
        ))}
        {loading && <span style={{ fontSize: 12, color: 'var(--text3)', alignSelf: 'center', marginLeft: 6 }}>Updating…</span>}
      </div>

      {/* Summary cards */}
      {data && (
        <div className="a-grid-3" style={{ marginBottom: 18 }}>
          <Metric label="Revenue" value={formatPKR(data.summary.totalRevenue)} sub={`Last ${range} days`} />
          <Metric label="Orders" value={data.summary.totalOrders} sub={`Last ${range} days`} />
          <Metric label="Avg Order Value" value={formatPKR(data.summary.avgOrderValue)} sub="Paid orders" />
        </div>
      )}

      <div className="a-grid-2">
        {/* Revenue sparkline */}
        <div className="a-card">
          <div className="a-card-hd"><span className="a-card-title">Daily Revenue (PKR)</span></div>
          {!data ? <Loader /> : data.revenueSeries.length === 0 ? <Empty text="No paid orders in range" /> : (
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 3, height: 120, paddingBottom: 4 }}>
              {data.revenueSeries.map((d, i) => {
                const h = Math.max(4, (d.revenue / maxRev) * 110);
                const label = `${d._id.d}/${d._id.m}`;
                return (
                  <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }} title={`${label}: ${formatPKR(d.revenue)}`}>
                    <div style={{ width: '100%', height: h, background: 'linear-gradient(180deg,var(--accent),rgba(124,108,255,.3))', borderRadius: '3px 3px 0 0', minHeight: 3 }} />
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Day of week */}
        <div className="a-card">
          <div className="a-card-hd"><span className="a-card-title">Orders by Day of Week</span></div>
          {!data ? <Loader /> : (
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 120, paddingBottom: 4 }}>
              {data.dowBreakdown.map((d, i) => {
                const h = Math.max(4, (d.orders / maxDow) * 110);
                return (
                  <div key={d.day} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }} title={`${d.day}: ${d.orders} orders`}>
                    <div style={{ width: '100%', height: h, background: DOW_COLORS[i] || 'var(--accent)', borderRadius: '3px 3px 0 0', opacity: 0.7, minHeight: 3 }} />
                    <span style={{ fontSize: 10, color: 'var(--text3)' }}>{d.day}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div className="a-grid-2">
        {/* Top products */}
        <div className="a-card">
          <div className="a-card-hd"><span className="a-card-title">Top Products</span><span className="a-card-sub">By revenue</span></div>
          {!data ? <Loader /> : data.topProducts.length === 0 ? <Empty text="No order data" /> : (
            <table>
              <thead><tr><th>Product</th><th>Qty</th><th>Revenue</th></tr></thead>
              <tbody>
                {data.topProducts.map((p) => (
                  <tr key={p._id}>
                    <td style={{ fontSize: 13 }}>{p.emoji} {p.name}</td>
                    <td style={{ fontSize: 12, color: 'var(--text3)' }}>{p.qty}</td>
                    <td className="mono">{formatPKR(p.revenue)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Top customers */}
        <div className="a-card">
          <div className="a-card-hd"><span className="a-card-title">Top Customers</span><span className="a-card-sub">By spend (paid)</span></div>
          {!data ? <Loader /> : data.topCustomers.length === 0 ? <Empty text="No paid orders" /> : (
            <table>
              <thead><tr><th>Customer</th><th>Orders</th><th>Spent</th></tr></thead>
              <tbody>
                {data.topCustomers.map((c, i) => (
                  <tr key={c._id}>
                    <td>
                      <div style={{ fontSize: 12, fontWeight: 600 }}>{c.name || '—'}</div>
                      <div style={{ fontSize: 11, color: 'var(--text3)' }}>{c.email}</div>
                    </td>
                    <td style={{ textAlign: 'center', fontSize: 12 }}>{c.orders}</td>
                    <td className="mono">{formatPKR(c.spent)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      <div className="a-grid-2">
        {/* Gateway revenue split */}
        <div className="a-card">
          <div className="a-card-hd"><span className="a-card-title">Revenue by Gateway</span></div>
          {!data ? <Loader /> : data.gwBreakdown.length === 0 ? <Empty text="No paid orders" /> : (
            <>
              {data.gwBreakdown.map((g) => {
                const pct = totalGwRev ? Math.round((g.revenue / totalGwRev) * 100) : 0;
                return (
                  <div key={g._id} style={{ display: 'flex', alignItems: 'center', gap: 12, fontSize: 13, marginBottom: 12 }}>
                    <span style={{ width: 80, color: 'var(--text2)', textTransform: 'capitalize', flexShrink: 0 }}>{g._id}</span>
                    <div className="a-bt" style={{ flex: 1 }}>
                      <div className="a-bf" style={{ width: `${pct}%`, background: GW_COLORS[g._id] || '#7c6cff' }} />
                    </div>
                    <span className="mono" style={{ width: 100, textAlign: 'right', fontSize: 12 }}>{formatPKR(g.revenue)}</span>
                    <span style={{ width: 32, textAlign: 'right', fontWeight: 500, fontSize: 12 }}>{pct}%</span>
                  </div>
                );
              })}
            </>
          )}
        </div>

        {/* Order status breakdown */}
        <div className="a-card">
          <div className="a-card-hd"><span className="a-card-title">Order Status Mix</span></div>
          {!data ? <Loader /> : data.statusBreakdown.length === 0 ? <Empty text="No orders" /> : (
            <>
              {(() => {
                const totalStatus = data.statusBreakdown.reduce((s, x) => s + x.count, 0);
                const colors = { pending: 'var(--amber)', processing: 'var(--blue)', fulfilled: 'var(--green)', cancelled: 'var(--red)' };
                return data.statusBreakdown.map((s) => {
                  const pct = Math.round((s.count / totalStatus) * 100);
                  return (
                    <div key={s._id} style={{ display: 'flex', alignItems: 'center', gap: 12, fontSize: 13, marginBottom: 12 }}>
                      <span style={{ width: 90, color: 'var(--text2)', textTransform: 'capitalize', flexShrink: 0 }}>{s._id}</span>
                      <div className="a-bt" style={{ flex: 1 }}>
                        <div className="a-bf" style={{ width: `${pct}%`, background: colors[s._id] || '#7c6cff' }} />
                      </div>
                      <span style={{ width: 32, textAlign: 'right', fontWeight: 500, fontSize: 12 }}>{s.count}</span>
                    </div>
                  );
                });
              })()}
            </>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}

function Metric({ label, value, sub }) {
  return (
    <div className="a-metric">
      <div className="a-m-label">{label}</div>
      <div className="a-m-val">{value}</div>
      {sub && <div className="a-m-delta a-flat">{sub}</div>}
    </div>
  );
}

function Loader() {
  return <p style={{ color: 'var(--text3)', fontSize: 12 }}>Loading…</p>;
}

function Empty({ text }) {
  return <p style={{ color: 'var(--text3)', fontSize: 12, textAlign: 'center', padding: 16 }}>{text}</p>;
}
