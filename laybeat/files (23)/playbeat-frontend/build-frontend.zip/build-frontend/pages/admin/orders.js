// pages/admin/orders.js
import { useEffect, useState, useCallback } from 'react';
import AdminLayout from '../../components/admin/AdminLayout';
import Modal from '../../components/admin/Modal';
import { StatusPill, fmtDate } from './index';
import { useAdmin } from '../../lib/AdminContext';
import { adminGet, adminPatch, adminDelete } from '../../lib/adminApi';
import { formatPKR } from '../../lib/products';

const STATUSES = ['pending', 'processing', 'fulfilled', 'cancelled'];
const PAY_STATUSES = ['pending', 'paid', 'failed', 'refunded'];

export default function AdminOrdersPage() {
  const { token, showToast } = useAdmin();
  const [orders, setOrders] = useState(null);
  const [total, setTotal] = useState(0);
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');
  const [active, setActive] = useState(null); // order being viewed/edited
  const [form, setForm] = useState({ status: '', paymentStatus: '', deliveryKey: '', notes: '' });

  const load = useCallback(() => {
    if (!token) return;
    const params = new URLSearchParams({ limit: '100' });
    if (status) params.set('status', status);
    if (q) params.set('q', q);
    adminGet(token, `/admin/orders?${params}`)
      .then((data) => { setOrders(data.orders); setTotal(data.total); })
      .catch((err) => showToast('⚠ ' + err.message));
  }, [token, status, q, showToast]);

  useEffect(() => { load(); }, [load]);

  function openOrder(o) {
    setActive(o);
    setForm({
      status: o.status,
      paymentStatus: o.paymentStatus,
      deliveryKey: o.items?.[0]?.deliveryKey || '',
      notes: o.adminNotes || '',
    });
  }

  async function saveOrder() {
    try {
      await adminPatch(token, `/admin/orders/${active.orderId}`, form);
      showToast('✅ Order updated');
      setActive(null);
      load();
    } catch (err) {
      showToast('❌ ' + err.message);
    }
  }

  async function cancelOrder(o) {
    if (!confirm(`Cancel order ${o.orderId}?`)) return;
    try {
      await adminDelete(token, `/admin/orders/${o.orderId}`);
      showToast('🗑 Order cancelled');
      load();
    } catch (err) {
      showToast('❌ ' + err.message);
    }
  }

  return (
    <AdminLayout title="Orders">
      <div className="a-card">
        <div className="a-card-hd">
          <span className="a-card-title">Order Log</span>
          <span className="a-card-sub">{total} orders</span>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <input type="search" placeholder="Email / name…" value={q} onChange={(e) => setQ(e.target.value)} style={{ width: 180 }} />
            <select value={status} onChange={(e) => setStatus(e.target.value)} style={{ height: 34 }}>
              <option value="">All statuses</option>
              {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
            <button className="a-btn a-bs" onClick={load}>↻</button>
          </div>
        </div>

        {!orders ? (
          <p style={{ color: 'var(--text3)', fontSize: 12 }}>Loading…</p>
        ) : orders.length === 0 ? (
          <p style={{ color: 'var(--text3)', fontSize: 12, textAlign: 'center', padding: 24 }}>No orders found</p>
        ) : (
          <table>
            <thead>
              <tr><th>ID</th><th>Customer</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th>Date</th><th></th></tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.orderId}>
                  <td className="mono" style={{ fontWeight: 700, color: 'var(--gold2)' }}>{o.orderId.slice(-8)}</td>
                  <td style={{ fontSize: 12, color: 'var(--text2)' }}>{o.email || o.customer?.name}</td>
                  <td style={{ fontSize: 12 }}>{o.items?.length || 0} item(s)</td>
                  <td className="mono">{formatPKR(o.totalPKR)}</td>
                  <td><span className="a-pill a-pb">{o.paymentMethod}</span></td>
                  <td><StatusPill status={o.status} /></td>
                  <td style={{ color: 'var(--text3)', fontSize: 12 }}>{fmtDate(o.createdAt)}</td>
                  <td style={{ whiteSpace: 'nowrap' }}>
                    <button className="a-btn a-bi a-bs" onClick={() => openOrder(o)} title="View/Edit">✎</button>
                    <button className="a-btn a-bi a-bs a-bd" onClick={() => cancelOrder(o)} title="Cancel">×</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {active && (
        <Modal
          title={`Order ${active.orderId.slice(-8)}`}
          onClose={() => setActive(null)}
          footer={<>
            <button className="a-btn" onClick={() => setActive(null)}>Close</button>
            <button className="a-btn a-bp" onClick={saveOrder}>Update Order</button>
          </>}
        >
          <div style={{ marginBottom: 16 }}>
            <div className="a-mr"><span style={{ color: 'var(--text3)' }}>Customer</span><span>{active.email}</span></div>
            <div className="a-mr"><span style={{ color: 'var(--text3)' }}>Total</span><span className="mono">{formatPKR(active.totalPKR)}</span></div>
            <div className="a-mr"><span style={{ color: 'var(--text3)' }}>Payment Method</span><span style={{ textTransform: 'capitalize' }}>{active.paymentMethod}</span></div>
            <div className="a-mr"><span style={{ color: 'var(--text3)' }}>Items</span><span>{active.items?.map((i) => `${i.name} ×${i.qty}`).join(', ')}</span></div>
            <div className="a-mr"><span style={{ color: 'var(--text3)' }}>Placed</span><span>{fmtDate(active.createdAt)}</span></div>
          </div>
          <div className="a-fg">
            <label>Order Status</label>
            <select value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))}>
              {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="a-fg">
            <label>Payment Status</label>
            <select value={form.paymentStatus} onChange={(e) => setForm((f) => ({ ...f, paymentStatus: e.target.value }))}>
              {PAY_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="a-fg">
            <label>Delivery Key / License</label>
            <input type="text" placeholder="XXXX-XXXX-XXXX-XXXX" value={form.deliveryKey} onChange={(e) => setForm((f) => ({ ...f, deliveryKey: e.target.value }))} />
          </div>
          <div className="a-fg">
            <label>Admin Notes</label>
            <textarea rows={2} placeholder="Internal notes…" value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} />
          </div>
        </Modal>
      )}
    </AdminLayout>
  );
}
