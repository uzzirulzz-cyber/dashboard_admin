// pages/admin/index.js
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import AdminLayout from '../../components/admin/AdminLayout';
import { useAdmin } from '../../lib/AdminContext';
import { adminGet } from '../../lib/adminApi';
import { formatPKR } from '../../lib/products';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const GW_COLORS = { stripe: '#6772e5', jazzcash: '#e53935', alfalah: '#1565c0', meezan: '#00897b' };

export default function AdminDashboard() {
  const router = useRouter();
  const { token, showToast } = useAdmin();
  const [stats, setStats] = useState(null);
  const [orders, setOrders] = useState(null);

  useEffect(() => {
    if (!token) return;
    Promise.all([
      adminGet(token, '/admin/stats'),
      adminGet(token, '/admin/orders?limit=5'),
    ])
      .then(([statsData, ordersData]) => {
        setStats(statsData.stats);
        setOrders(ordersData.orders);
      })
      .catch((err) => showToast('⚠ ' + err.message));
  }, [token, showToast]);

  const maxRev = stats?.monthlyRevenue?.length
    ? Math.max(...stats.monthlyRevenue.map((m) => m.total), 1)
    : 1;

  const totalPaymentCount = stats?.paymentBreakdown?.reduce((s, g) => s + g.count, 0) || 0;

  return (
    <AdminLayout title="Dashboard">
      <div className="a-grid-4">
        <Metric label="Total Revenue" value={stats ? formatPKR(stats.totalRevenue) : '—'} delta="From paid orders" />
        <Metric label="Total Orders" value={stats ? stats.totalOrders : '—'} delta={stats ? `↑ ${stats.todayOrders} today` : ''} cls="a-flat" />
        <Metric label="Customers" value={stats ? stats.totalUsers : '—'} delta={stats ? `↑ ${stats.newUsers} today` : ''} cls="a-flat" />
        <Metric
          label="Pending Orders"
          value={stats ? stats.pendingOrders : '—'}
          delta={stats ? (stats.pendingOrders > 0 ? 'Needs attention' : 'All clear') : ''}
          cls={stats?.pendingOrders > 0 ? 'a-pa' : 'a-up'}
        />
      </div>

      <div className="a-grid-2">
        <div className="a-card">
          <div className="a-card-hd">
            <span className="a-card-title">Monthly Revenue (PKR)</span>
          </div>
          {!stats ? (
            <p style={{ color: 'var(--text3)', fontSize: 12 }}>Loading…</p>
          ) : stats.monthlyRevenue.length === 0 ? (
            <p style={{ color: 'var(--text3)', fontSize: 12 }}>No revenue data yet</p>
          ) : (
            <div className="a-chart-bars">
              {stats.monthlyRevenue.map((m) => {
                const mon = MONTHS[m._id.month - 1];
                const h = Math.max(6, (m.total / maxRev) * 110);
                return (
                  <div className="a-cbc" key={`${m._id.year}-${m._id.month}`} title={`${formatPKR(m.total)} — ${mon} ${m._id.year}`}>
                    <div className="a-cb" style={{ height: h }} />
                    <div className="a-cl">{mon}</div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="a-card">
          <div className="a-card-hd">
            <span className="a-card-title">Payment Methods</span>
          </div>
          {!stats ? (
            <p style={{ color: 'var(--text3)', fontSize: 12 }}>Loading…</p>
          ) : stats.paymentBreakdown.length === 0 ? (
            <p style={{ color: 'var(--text3)', fontSize: 12 }}>No payment data yet</p>
          ) : (
            stats.paymentBreakdown.map((g) => {
              const pct = Math.round((g.count / totalPaymentCount) * 100);
              return (
                <div key={g._id} style={{ display: 'flex', alignItems: 'center', gap: 12, fontSize: 13, marginBottom: 10 }}>
                  <span style={{ width: 100, color: 'var(--text2)', textTransform: 'capitalize' }}>{g._id}</span>
                  <div className="a-bt" style={{ flex: 1 }}>
                    <div className="a-bf" style={{ width: `${pct}%`, background: GW_COLORS[g._id] || '#7c6cff' }} />
                  </div>
                  <span style={{ width: 36, textAlign: 'right', fontWeight: 500 }}>{pct}%</span>
                </div>
              );
            })
          )}
        </div>
      </div>

      <div className="a-card">
        <div className="a-card-hd">
          <span className="a-card-title">Recent Orders</span>
          <button className="a-btn a-bs" onClick={() => router.push('/admin/orders')}>View all →</button>
        </div>
        {!orders ? (
          <p style={{ color: 'var(--text3)', fontSize: 12 }}>Loading…</p>
        ) : orders.length === 0 ? (
          <p style={{ color: 'var(--text3)', fontSize: 12, textAlign: 'center', padding: 16 }}>No orders yet</p>
        ) : (
          <table>
            <thead>
              <tr><th>ID</th><th>Email</th><th>Total</th><th>Status</th><th>Date</th></tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.orderId}>
                  <td className="mono">{o.orderId}</td>
                  <td style={{ color: 'var(--text2)' }}>{o.email}</td>
                  <td className="mono">{formatPKR(o.totalPKR)}</td>
                  <td><StatusPill status={o.status} /></td>
                  <td style={{ color: 'var(--text3)', fontSize: 12 }}>{fmtDate(o.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </AdminLayout>
  );
}

function Metric({ label, value, delta, cls = 'a-flat' }) {
  return (
    <div className="a-metric">
      <div className="a-m-label">{label}</div>
      <div className="a-m-val">{value}</div>
      {delta && <div className={`a-m-delta ${cls}`}>{delta}</div>}
    </div>
  );
}

export function StatusPill({ status }) {
  const map = { pending: 'a-pa', processing: 'a-pb', fulfilled: 'a-pg', cancelled: 'a-pr', paid: 'a-pg', failed: 'a-pr', refunded: 'a-pr' };
  return <span className={`a-pill ${map[status] || 'a-pa'}`}>{status || 'unknown'}</span>;
}

export function fmtDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'Asia/Karachi' });
}
