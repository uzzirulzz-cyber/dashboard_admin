// pages/admin/login.js
import { useState } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import { useAdmin } from '../../lib/AdminContext';
import { adminLogin } from '../../lib/adminApi';

export default function AdminLoginPage() {
  const router = useRouter();
  const { login, token, ready } = useAdmin();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (ready && token) {
    router.replace('/admin');
    return null;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const data = await adminLogin(email, password);
      login(data.token);
      router.push('/admin');
    } catch (err) {
      setError(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="admin">
      <Head><title>Admin Login · PlayBeat</title></Head>
      <div className="a-login-screen">
        <div className="a-login-card">
          <div className="a-login-logo">play<span>beat</span></div>
          <div className="a-login-sub">Admin Control Panel</div>
          <form onSubmit={handleSubmit}>
            <input
              className="a-field"
              type="email"
              placeholder="admin@playbeat.gg"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="username"
              required
            />
            <input
              className="a-field"
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              required
            />
            <button className="a-login-btn" type="submit" disabled={loading}>
              {loading ? 'Signing in…' : 'Access Dashboard'}
            </button>
          </form>
          {error && <div className="a-login-err">{error}</div>}
        </div>
      </div>
    </div>
  );
}
