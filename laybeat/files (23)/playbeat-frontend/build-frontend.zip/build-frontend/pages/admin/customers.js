// pages/admin/customers.js
import { useEffect, useState, useCallback } from 'react';
import AdminLayout from '../../components/admin/AdminLayout';
import Modal from '../../components/admin/Modal';
import { useAdmin } from '../../lib/AdminContext';
import { adminGet } from '../../lib/adminApi';
import { formatPKR } from '../../lib/products';
import { fmtDate } from './index';

export default function AdminCustomersPage() {
  const { token, showToast } = useAdmin();
  const [customers, setCustomers] = useState(null);
  const [total, setTotal] = useState(0);
  const [q, setQ] = useState('');
  const [active, setActive] = useState(null); // customer detail view
  const [detail, setDetail] = useState(null);
  const [loadingDetail, setLoadingDetail] = useState(false);

  const load = useCallback(() => {
    if (!token) return;
    const params = new URLSearchParams({ limit: '100' });
    if (q) params.set('q', q);
    adminGet(token, `/admin/customers?${params}`)
      .then((d) => { setCustomers(d.customers); setTotal(d.total); })
      .catch((err) => showToast('⚠ ' + err.message));
  }, [token, q, showToast]);

  useEffect(() => { load(); }, [load]);

  async function openCustomer(c) {
    setActive(c);
    setLoadingDetail(true);
    try {
      const d = await adminGet(token, `/admin/customers/${encodeURIComponent(c.email)}`);
      setDetail(d);
    } catch (err) {
      showToast('⚠ ' + err.message);
    } finally {
      setLoadingDetail(false);
    }
  }

  const tier = (spent) => {
    if (spent >= 50000) return { label: 'VIP', cls: 'a-pgo' };
    if (spent >= 20000) return { label: 'Regular', cls: 'a-pg' };
    return { label: 'New', cls: 'a-pb' };
  };

  return (
    <AdminLayout title="Customers">
      <div className="a-card">
        <div className="a-card-hd">
          <span className="a-card-title">Customer Directory</span>
          <span className="a-card-sub">{total} customers</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <input
              type="search"
              placeholder="Email or name…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              style={{ width: 200 }}
            />
            <button className="a-btn a-bs" onClick={load}>↻</button>
          </div>
        </div>

        {!customers ? (
          <p style={{ color: 'var(--text3)', fontSize: 12 }}>Loading…</p>
        ) : customers.length === 0 ? (
          <p style={{ color: 'var(--text3)', fontSize: 12, textAlign: 'center', padding: 24 }}>No customers found</p>
        ) : (
          <table>
            <thead>
              <tr><th>Customer</th><th>Orders</th><th>Total Spent</th><th>Last Order</th><th>Gateways</th><th>Tier</th><th></th></tr>
            </thead>
            <tbody>
              {customers.map((c) => {
                const t = tier(c.totalSpent);
                return (
                  <tr key={c._id}>
                    <td>
                      <div style={{ fontWeight: 600, fontSize: 13 }}>{c.name || '—'}</div>
                      <div style={{ fontSize: 11, color: 'var(--text3)' }}>{c.email}</div>
                    </td>
                    <td style={{ textAlign: 'center' }}>{c.orderCount}</td>
                    <td className="mono">{formatPKR(c.totalSpent)}</td>
                    <td style={{ color: 'var(--text3)', fontSize: 12 }}>{fmtDate(c.lastOrderAt)}</td>
                    <td style={{ fontSize: 11 }}>
                      {c.paymentMethods.map((m) => (
                        <span key={m} className="a-pill a-pb" style={{ marginRight: 4, fontSize: 10 }}>{m}</span>
                      ))}
                    </td>
                    <td><span className={`a-pill ${t.cls}`}>{t.label}</span></td>
                    <td>
                      <button className="a-btn a-bi a-bs" onClick={() => openCustomer(c)} title="View profile">👤</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {active && (
        <Modal
          title={`Customer — ${active.name || active.email}`}
          onClose={() => { setActive(null); setDetail(null); }}
          footer={<button className="a-btn" onClick={() => { setActive(null); setDetail(null); }}>Close</button>}
        >
          {loadingDetail ? (
            <p style={{ color: 'var(--text3)', fontSize: 13 }}>Loading order history…</p>
          ) : detail ? (
            <>
              <div style={{ marginBottom: 18 }}>
                <div className="a-mr"><span style={{ color: 'var(--text3)' }}>Email</span><span>{detail.customer.email}</span></div>
                <div className="a-mr"><span style={{ color: 'var(--text3)' }}>Phone</span><span>{detail.customer.phone || '—'}</span></div>
                <div className="a-mr"><span style={{ color: 'var(--text3)' }}>Total orders</span><span>{detail.customer.orderCount}</span></div>
                <div className="a-mr"><span style={{ color: 'var(--text3)' }}>Total spent</span><span className="mono">{formatPKR(detail.customer.totalSpent)}</span></div>
                <div className="a-mr"><span style={{ color: 'var(--text3)' }}>Paid orders value</span><span className="mono">{formatPKR(detail.customer.paidSpent)}</span></div>
              </div>

              <div style={{ fontSize: 12, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Order History</div>
              {detail.orders.map((o) => (
                <div key={o.orderId} style={{ padding: '10px 0', borderBottom: '1px solid rgba(212,175,55,.06)', fontSize: 13 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span className="mono" style={{ color: 'var(--gold2)', fontSize: 11 }}>{String(o.orderId).slice(-8)}</span>
                    <span className="mono">{formatPKR(o.total)}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    <span className={`a-pill ${o.status === 'fulfilled' ? 'a-pg' : o.status === 'cancelled' ? 'a-pr' : 'a-pa'}`}>{o.status}</span>
                    <span className="a-pill a-pb">{o.paymentMethod}</span>
                    <span style={{ color: 'var(--text3)', fontSize: 11, marginLeft: 'auto' }}>{fmtDate(o.createdAt)}</span>
                  </div>
                </div>
              ))}
            </>
          ) : null}
        </Modal>
      )}
    </AdminLayout>
  );
}
