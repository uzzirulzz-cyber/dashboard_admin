// pages/admin/homepage.js
import { useEffect, useState } from 'react';
import AdminLayout from '../../components/admin/AdminLayout';
import Modal from '../../components/admin/Modal';
import { useAdmin } from '../../lib/AdminContext';
import { adminGet, adminPatch, adminPost, adminDelete } from '../../lib/adminApi';

const ALL_CATS = ['games', 'gift-cards', 'software', 'ai-tools', 'game-items', 'accounts'];

const EMPTY_BANNER = {
  id: '',
  title: '',
  subtitle: '',
  cta: 'Shop Now',
  href: '/',
  badge: '',
  gradient: 'linear-gradient(135deg,#1a1a2e,#16213e)',
  emoji: '⚡',
  active: true,
};

export default function AdminHomepagePage() {
  const { token, showToast } = useAdmin();
  const [cfg, setCfg] = useState(null);
  const [saving, setSaving] = useState(false);
  const [bannerModal, setBannerModal] = useState(null);
  const [tickerInput, setTickerInput] = useState('');

  useEffect(() => {
    if (!token) return;
    adminGet(token, '/admin/homepage')
      .then((d) => setCfg(d.config))
      .catch((err) => showToast('⚠ ' + err.message));
  }, [token, showToast]);

  async function patch(partial) {
    setSaving(true);
    try {
      const res = await adminPatch(token, '/admin/homepage', partial);
      setCfg(res.config);
      showToast('✅ Saved');
    } catch (err) {
      showToast('❌ ' + err.message);
    } finally {
      setSaving(false);
    }
  }

  // ── Ticker ────────────────────────────────────────────────────────────────
  function addTickerItem() {
    const trimmed = tickerInput.trim();
    if (!trimmed) return;
    const items = [...(cfg.ticker?.items || []), trimmed];
    setCfg((c) => ({ ...c, ticker: { ...c.ticker, items } }));
    setTickerInput('');
  }

  function removeTickerItem(i) {
    const items = cfg.ticker.items.filter((_, idx) => idx !== i);
    setCfg((c) => ({ ...c, ticker: { ...c.ticker, items } }));
  }

  function saveTicker() {
    patch({ ticker: cfg.ticker });
  }

  // ── Banners ───────────────────────────────────────────────────────────────
  async function saveBanner() {
    const { mode, form } = bannerModal;
    setSaving(true);
    try {
      if (mode === 'add') {
        const id = form.id || `banner-${Date.now()}`;
        await adminPost(token, '/admin/homepage/banner', { ...form, id });
        showToast('✅ Banner added');
      } else {
        await adminPatch(token, `/admin/homepage/banner/${form.id}`, form);
        showToast('✅ Banner updated');
      }
      const res = await adminGet(token, '/admin/homepage');
      setCfg(res.config);
      setBannerModal(null);
    } catch (err) {
      showToast('❌ ' + err.message);
    } finally {
      setSaving(false);
    }
  }

  async function deleteBanner(id) {
    if (!confirm('Delete this banner?')) return;
    try {
      await adminDelete(token, `/admin/homepage/banner/${id}`);
      const res = await adminGet(token, '/admin/homepage');
      setCfg(res.config);
      showToast('🗑 Banner deleted');
    } catch (err) {
      showToast('❌ ' + err.message);
    }
  }

  function setBField(k, v) {
    setBannerModal((m) => ({ ...m, form: { ...m.form, [k]: v } }));
  }

  // ── Featured categories ───────────────────────────────────────────────────
  function toggleFeatCat(slug) {
    const prev = cfg.featuredCategories || [];
    const next = prev.includes(slug) ? prev.filter((c) => c !== slug) : [...prev, slug];
    setCfg((c) => ({ ...c, featuredCategories: next }));
  }

  if (!cfg) return <AdminLayout title="Homepage Editor"><p style={{ color: 'var(--text3)', fontSize: 12, padding: 20 }}>Loading…</p></AdminLayout>;

  return (
    <AdminLayout title="Homepage Editor">
      {/* Announcement bar */}
      <div className="a-card">
        <div className="a-card-hd">
          <span className="a-card-title">📢 Announcement Bar</span>
          <label className="a-tgl" title="Enable / disable">
            <input type="checkbox" checked={!!cfg.announcementBar?.enabled} onChange={(e) => {
              setCfg((c) => ({ ...c, announcementBar: { ...c.announcementBar, enabled: e.target.checked } }));
            }} />
            <span className="a-tgl-sl" />
          </label>
        </div>
        <div className="a-frow" style={{ marginBottom: 0 }}>
          <div className="a-fg">
            <label>Message</label>
            <input
              type="text"
              placeholder="🚀 Free delivery on orders above PKR 5,000"
              value={cfg.announcementBar?.text || ''}
              onChange={(e) => setCfg((c) => ({ ...c, announcementBar: { ...c.announcementBar, text: e.target.value } }))}
            />
          </div>
          <div className="a-fg" style={{ maxWidth: 120 }}>
            <label>Color</label>
            <input
              type="color"
              value={cfg.announcementBar?.color || '#d4af37'}
              onChange={(e) => setCfg((c) => ({ ...c, announcementBar: { ...c.announcementBar, color: e.target.value } }))}
              style={{ height: 36, padding: 2, cursor: 'pointer' }}
            />
          </div>
        </div>
        <div className="a-mo-ft" style={{ marginTop: 14, paddingTop: 0, border: 'none', justifyContent: 'flex-start' }}>
          <button className="a-btn a-bs a-bp" disabled={saving} onClick={() => patch({ announcementBar: cfg.announcementBar })}>
            Save
          </button>
        </div>
      </div>

      {/* Ticker */}
      <div className="a-card">
        <div className="a-card-hd">
          <span className="a-card-title">📣 Ticker / Marquee</span>
          <label className="a-tgl">
            <input type="checkbox" checked={!!cfg.ticker?.enabled} onChange={(e) => setCfg((c) => ({ ...c, ticker: { ...c.ticker, enabled: e.target.checked } }))} />
            <span className="a-tgl-sl" />
          </label>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 10 }}>
          {(cfg.ticker?.items || []).map((item, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'rgba(212,175,55,.04)', borderRadius: 8, padding: '6px 10px', fontSize: 13 }}>
              <span style={{ flex: 1 }}>{item}</span>
              <button className="a-btn a-bi a-bs a-bd" onClick={() => removeTickerItem(i)} style={{ width: 24, height: 24, fontSize: 14 }}>×</button>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <input type="text" placeholder="⚡ Add a ticker item…" value={tickerInput} onChange={(e) => setTickerInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') addTickerItem(); }} style={{ flex: 1 }} />
          <button className="a-btn a-bs" onClick={addTickerItem}>+ Add</button>
          <button className="a-btn a-bs a-bp" disabled={saving} onClick={saveTicker}>Save</button>
        </div>
      </div>

      {/* Hero Banners */}
      <div className="a-card">
        <div className="a-card-hd">
          <span className="a-card-title">🖼 Hero Banners</span>
          <button className="a-btn a-bs a-bp" onClick={() => setBannerModal({ mode: 'add', form: { ...EMPTY_BANNER } })}>+ New Banner</button>
        </div>
        {(!cfg.heroBanners || cfg.heroBanners.length === 0) ? (
          <p style={{ color: 'var(--text3)', fontSize: 12 }}>No banners yet</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[...cfg.heroBanners].sort((a, b) => (a.order || 0) - (b.order || 0)).map((b) => (
              <div key={b.id} style={{
                borderRadius: 12, padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 14,
                background: b.active ? 'rgba(212,175,55,.04)' : 'rgba(255,255,255,.02)',
                border: `1px solid ${b.active ? 'rgba(212,175,55,.18)' : 'rgba(255,255,255,.06)'}`,
                opacity: b.active ? 1 : 0.5,
              }}>
                <div style={{ fontSize: 28, width: 40, textAlign: 'center' }}>{b.emoji}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 2 }}>{b.title || '(Untitled)'}</div>
                  <div style={{ fontSize: 11, color: 'var(--text3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{b.subtitle}</div>
                  <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 3 }}>→ {b.href} · CTA: {b.cta}</div>
                </div>
                {b.badge && <span className="a-pill a-pa" style={{ fontSize: 10 }}>{b.badge}</span>}
                {b.active ? <span className="a-pill a-pg" style={{ fontSize: 10 }}>Active</span> : <span className="a-pill a-pr" style={{ fontSize: 10 }}>Hidden</span>}
                <button className="a-btn a-bi a-bs" onClick={() => setBannerModal({ mode: 'edit', form: { ...EMPTY_BANNER, ...b } })}>✎</button>
                <button className="a-btn a-bi a-bs a-bd" onClick={() => deleteBanner(b.id)}>🗑</button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Featured categories */}
      <div className="a-card">
        <div className="a-card-hd">
          <span className="a-card-title">🗂 Featured Categories</span>
          <button className="a-btn a-bs a-bp" disabled={saving} onClick={() => patch({ featuredCategories: cfg.featuredCategories })}>Save</button>
        </div>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          {ALL_CATS.map((slug) => {
            const on = (cfg.featuredCategories || []).includes(slug);
            return (
              <button
                key={slug}
                className={`a-btn a-bs${on ? ' a-bp' : ''}`}
                onClick={() => toggleFeatCat(slug)}
              >
                {on ? '✓ ' : ''}{slug}
              </button>
            );
          })}
        </div>
      </div>

      {/* SEO */}
      <div className="a-card">
        <div className="a-card-hd">
          <span className="a-card-title">🔍 SEO Settings</span>
        </div>
        <div className="a-fg">
          <label>Page Title</label>
          <input type="text" value={cfg.seo?.title || ''} onChange={(e) => setCfg((c) => ({ ...c, seo: { ...c.seo, title: e.target.value } }))} />
        </div>
        <div className="a-fg">
          <label>Meta Description</label>
          <textarea rows={2} value={cfg.seo?.description || ''} onChange={(e) => setCfg((c) => ({ ...c, seo: { ...c.seo, description: e.target.value } }))} />
        </div>
        <button className="a-btn a-bs a-bp" disabled={saving} onClick={() => patch({ seo: cfg.seo })}>Save SEO</button>
      </div>

      {/* Banner modal */}
      {bannerModal && (
        <Modal
          title={bannerModal.mode === 'add' ? 'New Hero Banner' : 'Edit Banner'}
          onClose={() => setBannerModal(null)}
          footer={<>
            <button className="a-btn" onClick={() => setBannerModal(null)}>Cancel</button>
            <button className="a-btn a-bp" disabled={saving} onClick={saveBanner}>Save Banner</button>
          </>}
        >
          <div className="a-frow">
            <div className="a-fg">
              <label>ID / Slug</label>
              <input type="text" placeholder="games-banner" value={bannerModal.form.id} onChange={(e) => setBField('id', e.target.value)} />
            </div>
            <div className="a-fg">
              <label>Emoji</label>
              <input type="text" placeholder="🎮" value={bannerModal.form.emoji} onChange={(e) => setBField('emoji', e.target.value)} />
            </div>
          </div>
          <div className="a-fg">
            <label>Title *</label>
            <input type="text" placeholder="Top Games — Lowest PKR Prices" value={bannerModal.form.title} onChange={(e) => setBField('title', e.target.value)} />
          </div>
          <div className="a-fg">
            <label>Subtitle</label>
            <input type="text" placeholder="A short subtitle or tagline" value={bannerModal.form.subtitle} onChange={(e) => setBField('subtitle', e.target.value)} />
          </div>
          <div className="a-frow">
            <div className="a-fg">
              <label>CTA Label</label>
              <input type="text" placeholder="Shop Now" value={bannerModal.form.cta} onChange={(e) => setBField('cta', e.target.value)} />
            </div>
            <div className="a-fg">
              <label>CTA Link</label>
              <input type="text" placeholder="/games" value={bannerModal.form.href} onChange={(e) => setBField('href', e.target.value)} />
            </div>
          </div>
          <div className="a-frow">
            <div className="a-fg">
              <label>Badge Text</label>
              <input type="text" placeholder="🔥 Trending" value={bannerModal.form.badge} onChange={(e) => setBField('badge', e.target.value)} />
            </div>
            <div className="a-fg">
              <label>Status</label>
              <select value={bannerModal.form.active ? '1' : '0'} onChange={(e) => setBField('active', e.target.value === '1')}>
                <option value="1">Active</option>
                <option value="0">Hidden</option>
              </select>
            </div>
          </div>
          <div className="a-fg">
            <label>Background Gradient CSS</label>
            <input type="text" placeholder="linear-gradient(135deg,#0d1b2a,#1a3a5c)" value={bannerModal.form.gradient} onChange={(e) => setBField('gradient', e.target.value)} />
            <div style={{ marginTop: 6, height: 28, borderRadius: 6, background: bannerModal.form.gradient }} />
          </div>
        </Modal>
      )}
    </AdminLayout>
  );
}
