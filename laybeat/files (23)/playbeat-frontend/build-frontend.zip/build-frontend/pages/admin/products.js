// pages/admin/products.js
import { useEffect, useState, useCallback } from 'react';
import AdminLayout from '../../components/admin/AdminLayout';
import Modal from '../../components/admin/Modal';
import { useAdmin } from '../../lib/AdminContext';
import { adminGet, adminPost, adminPatch, adminDelete } from '../../lib/adminApi';
import { CATEGORIES, formatPKR } from '../../lib/products';

const EMPTY = {
  name: '', category: 'games', brand: '', emoji: '🛒', price: '', oldPrice: '',
  badge: '', stock: 0, delivery: 'Instant', description: '', active: true,
};

export default function AdminProductsPage() {
  const { token, showToast } = useAdmin();
  const [products, setProducts] = useState(null);
  const [count, setCount] = useState(0);
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('');
  const [modal, setModal] = useState(null); // { mode: 'add'|'edit', form }

  const load = useCallback(() => {
    if (!token) return;
    const params = new URLSearchParams({ limit: '200' });
    if (cat) params.set('cat', cat);
    if (q) params.set('q', q);
    adminGet(token, `/admin/products?${params}`)
      .then((data) => { setProducts(data.products); setCount(data.count); })
      .catch((err) => showToast('⚠ ' + err.message));
  }, [token, cat, q, showToast]);

  useEffect(() => { load(); }, [load]);

  function openAdd() {
    setModal({ mode: 'add', form: { ...EMPTY } });
  }

  function openEdit(p) {
    setModal({ mode: 'edit', id: p.id, form: { ...EMPTY, ...p, price: p.price, oldPrice: p.oldPrice || '' } });
  }

  function setField(key, value) {
    setModal((m) => ({ ...m, form: { ...m.form, [key]: value } }));
  }

  async function save() {
    const { mode, id, form } = modal;
    const payload = {
      ...form,
      price: Number(form.price) || 0,
      oldPrice: form.oldPrice === '' ? undefined : Number(form.oldPrice),
      stock: Number(form.stock) || 0,
    };
    try {
      if (mode === 'add') {
        await adminPost(token, '/admin/products', payload);
        showToast('✅ Product added');
      } else {
        await adminPatch(token, `/admin/products/${id}`, payload);
        showToast('✅ Product updated');
      }
      setModal(null);
      load();
    } catch (err) {
      showToast('❌ ' + err.message);
    }
  }

  async function remove() {
    if (!confirm(`Delete "${modal.form.name}"? This cannot be undone.`)) return;
    try {
      await adminDelete(token, `/admin/products/${modal.id}`);
      showToast('🗑 Product deleted');
      setModal(null);
      load();
    } catch (err) {
      showToast('❌ ' + err.message);
    }
  }

  return (
    <AdminLayout title="Products">
      <div className="a-card">
        <div className="a-card-hd">
          <span className="a-card-title">All Products</span>
          <span className="a-card-sub">{count} products</span>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <input type="search" placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} style={{ width: 160 }} />
            <select value={cat} onChange={(e) => setCat(e.target.value)} style={{ height: 34 }}>
              <option value="">All categories</option>
              {CATEGORIES.map((c) => <option key={c.slug} value={c.slug}>{c.label}</option>)}
            </select>
            <button className="a-btn a-bs a-bp" onClick={openAdd}>+ New Product</button>
          </div>
        </div>

        {!products ? (
          <p style={{ color: 'var(--text3)', fontSize: 12 }}>Loading…</p>
        ) : products.length === 0 ? (
          <p style={{ color: 'var(--text3)', fontSize: 12, textAlign: 'center', padding: 24 }}>No products found</p>
        ) : (
          <table>
            <thead>
              <tr><th>Name</th><th>Category</th><th>Price</th><th>Sale Price</th><th>Stock</th><th>Status</th><th>Delivery</th><th></th></tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id}>
                  <td style={{ fontWeight: 600 }}>
                    {p.emoji} {p.name}{p.badge ? <span className="a-pill a-pa" style={{ fontSize: 10, marginLeft: 6 }}>{p.badge}</span> : null}
                  </td>
                  <td><span className="a-pill a-pac">{p.category}</span></td>
                  <td className="mono">{formatPKR(p.price)}</td>
                  <td className="mono">{p.oldPrice ? formatPKR(p.oldPrice) : '—'}</td>
                  <td>
                    {p.stock === 0 ? <span className="a-sk a-sk-out">Out of stock</span>
                      : p.stock <= 10 ? <span className="a-sk a-sk-lw">{p.stock} units ⚠</span>
                      : <span className="a-sk a-sk-ok">{p.stock} units</span>}
                  </td>
                  <td>{p.active === false ? <span className="a-pill a-pr">Inactive</span> : <span className="a-pill a-pg">Active</span>}</td>
                  <td><span className={`a-pill ${p.delivery === 'Instant' ? 'a-pg' : 'a-pa'}`}>{p.delivery}</span></td>
                  <td><button className="a-btn a-bi a-bs" onClick={() => openEdit(p)} title="Edit">✎</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {modal && (
        <Modal
          title={modal.mode === 'add' ? 'Add New Product' : 'Edit Product'}
          onClose={() => setModal(null)}
          footer={<>
            {modal.mode === 'edit' && <button className="a-btn a-bd" style={{ marginRight: 'auto' }} onClick={remove}>Delete</button>}
            <button className="a-btn" onClick={() => setModal(null)}>Cancel</button>
            <button className="a-btn a-bp" onClick={save}>Save Product</button>
          </>}
        >
          <div className="a-frow">
            <div className="a-fg"><label>Name *</label><input type="text" value={modal.form.name} onChange={(e) => setField('name', e.target.value)} placeholder="e.g. ChatGPT Plus — 1 Month" /></div>
            <div className="a-fg"><label>Category *</label>
              <select value={modal.form.category} onChange={(e) => setField('category', e.target.value)}>
                {CATEGORIES.map((c) => <option key={c.slug} value={c.slug}>{c.label}</option>)}
              </select>
            </div>
          </div>
          <div className="a-frow">
            <div className="a-fg"><label>Brand</label><input type="text" value={modal.form.brand} onChange={(e) => setField('brand', e.target.value)} placeholder="e.g. OpenAI" /></div>
            <div className="a-fg"><label>Emoji</label><input type="text" value={modal.form.emoji} onChange={(e) => setField('emoji', e.target.value)} placeholder="💬" /></div>
          </div>
          <div className="a-frow">
            <div className="a-fg"><label>Price (PKR) *</label><input type="number" value={modal.form.price} onChange={(e) => setField('price', e.target.value)} placeholder="5999" /></div>
            <div className="a-fg"><label>Sale (old) Price</label><input type="number" value={modal.form.oldPrice} onChange={(e) => setField('oldPrice', e.target.value)} placeholder="Optional" /></div>
          </div>
          <div className="a-frow">
            <div className="a-fg"><label>Stock</label><input type="number" value={modal.form.stock} onChange={(e) => setField('stock', e.target.value)} placeholder="50" /></div>
            <div className="a-fg"><label>Delivery</label>
              <select value={modal.form.delivery} onChange={(e) => setField('delivery', e.target.value)}>
                <option>Instant</option><option>Manual</option>
              </select>
            </div>
          </div>
          <div className="a-fg"><label>Description</label><textarea rows={3} value={modal.form.description} onChange={(e) => setField('description', e.target.value)} placeholder="Short product description…" /></div>
          <div className="a-frow">
            <div className="a-fg"><label>Badge</label>
              <select value={modal.form.badge} onChange={(e) => setField('badge', e.target.value)}>
                <option value="">None</option><option>HOT</option><option>NEW</option><option>SALE</option><option>BEST VALUE</option><option>RARE</option>
              </select>
            </div>
            <div className="a-fg"><label>Status</label>
              <select value={modal.form.active ? '1' : '0'} onChange={(e) => setField('active', e.target.value === '1')}>
                <option value="1">Active</option><option value="0">Inactive</option>
              </select>
            </div>
          </div>
        </Modal>
      )}
    </AdminLayout>
  );
}
