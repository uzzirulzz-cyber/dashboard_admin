// pages/search.js
import { useRouter } from 'next/router';
import Layout from '../components/Layout';
import ProductCard from '../components/ProductCard';
import { PRODUCTS, getCategory } from '../lib/products';

export default function SearchPage() {
  const router = useRouter();
  const { q = '', cat = 'All' } = router.query;
  const query = String(q).toLowerCase();

  const results = PRODUCTS.filter((p) => {
    const matchesQuery = !query ||
      p.name.toLowerCase().includes(query) ||
      p.brand.toLowerCase().includes(query);
    const matchesCat = cat === 'All' || getCategory(p.category)?.label === cat;
    return matchesQuery && matchesCat;
  });

  return (
    <Layout title={`Search: ${q}`}>
      <div className="wrap" style={{ paddingTop: '28px' }}>
        <div className="cat-banner">
          <div className="section-eyebrow">Search Results</div>
          <h1>&quot;{q}&quot;</h1>
          <p>{results.length} product{results.length === 1 ? '' : 's'} found{cat !== 'All' ? ` in ${cat}` : ''}.</p>
        </div>
      </div>
      <div className="wrap" style={{ paddingBottom: '64px' }}>
        {results.length === 0 ? (
          <div className="cart-empty">No products matched your search. Try a different keyword.</div>
        ) : (
          <div className="product-grid">
            {results.map((p) => (
              <ProductCard product={p} key={p.id} />
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
