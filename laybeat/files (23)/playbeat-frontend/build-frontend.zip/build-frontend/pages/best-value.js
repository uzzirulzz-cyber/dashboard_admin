// pages/best-value.js
import { useState, useMemo } from 'react';
import Layout from '../components/Layout';
import ProductCard from '../components/ProductCard';
import { getBestValue } from '../lib/products';

export async function getStaticProps() {
  return { props: { products: getBestValue() } };
}

export default function BestValuePage({ products }) {
  const [sort, setSort] = useState('default');

  const sorted = useMemo(() => {
    const list = [...products];
    if (sort === 'price-asc') list.sort((a, b) => a.price - b.price);
    if (sort === 'price-desc') list.sort((a, b) => b.price - a.price);
    return list;
  }, [products, sort]);

  return (
    <Layout title="Best Value">
      <div className="wrap" style={{ paddingTop: '28px' }}>
        <div className="cat-banner">
          <div className="section-eyebrow">Biggest Discounts · Site-Wide</div>
          <h1>◈ Best Value</h1>
          <p>The deepest discounts across PlayBeat Digital, ranked by savings.</p>
          <div className="cat-stats">
            <div className="cat-stat">💰 Up to <b>50%</b> Off</div>
            <div className="cat-stat">🌍 All Categories</div>
            <div className="cat-stat">🛡️ Buyer Protected</div>
          </div>
        </div>
        <div className="filter-bar">
          <span className="filter-label">Sort by</span>
          <select className="filter-select" value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="default">Featured</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
          </select>
          <span className="result-count">{products.length} PRODUCTS</span>
        </div>
      </div>
      <div className="wrap" style={{ paddingBottom: '64px' }}>
        <div className="product-grid">
          {sorted.map((p) => (
            <ProductCard product={{ ...p, badge: `-${p.discount}%` }} key={p.id} />
          ))}
        </div>
      </div>
    </Layout>
  );
}
