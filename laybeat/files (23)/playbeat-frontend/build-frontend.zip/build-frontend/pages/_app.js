// pages/_app.js
import '../styles/globals.css';
import '../styles/admin.css';
import { CartProvider } from '../lib/CartContext';
import { AdminProvider } from '../lib/AdminContext';

export default function App({ Component, pageProps }) {
  return (
    <CartProvider>
      <AdminProvider>
        <Component {...pageProps} />
      </AdminProvider>
    </CartProvider>
  );
}
