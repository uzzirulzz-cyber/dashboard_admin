// pages/checkout.js
import { useState } from 'react';
import Link from 'next/link';
import Layout from '../components/Layout';
import PaymentLogos from '../components/PaymentLogos';
import { useCart } from '../lib/CartContext';
import { createOrder, initiateCheckout } from '../lib/api';
import { formatPKR } from '../lib/products';

export default function CheckoutPage() {
  const { cart, cartTotal, updateQty, removeFromCart, showToast } = useCart();
  const [form, setForm] = useState({ name: '', email: '', phone: '', notes: '' });
  const [method, setMethod] = useState(null);
  const [loading, setLoading] = useState(false);
  const [bankInstructions, setBankInstructions] = useState(null);

  function handleChange(e) {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
  }

  async function placeOrder(e) {
    e.preventDefault();
    if (!method) {
      showToast('Choose a payment method first');
      return;
    }
    setLoading(true);
    setBankInstructions(null);
    try {
      const items = cart.map((i) => ({ productId: i.id, name: i.name, price: i.price, qty: i.qty, emoji: i.emoji }));
      const { order } = await createOrder({ items, customer: form });
      const result = await initiateCheckout(order._id, method);

      if (result.type === 'redirect') {
        window.location.href = result.url; // Stripe Checkout
      } else if (result.type === 'form_post') {
        // JazzCash — build & auto-submit a hidden form to the gateway
        submitGatewayForm(result.action, result.fields);
      } else if (result.mode === 'manual_transfer' || result.mode === 'gateway') {
        setBankInstructions(result); // Alfalah / Meezan bank details
      }
    } catch (err) {
      showToast(err.message || 'Checkout failed');
    } finally {
      setLoading(false);
    }
  }

  function submitGatewayForm(action, fields) {
    const f = document.createElement('form');
    f.method = 'POST';
    f.action = action;
    Object.entries(fields).forEach(([key, value]) => {
      const input = document.createElement('input');
      input.type = 'hidden';
      input.name = key;
      input.value = value;
      f.appendChild(input);
    });
    document.body.appendChild(f);
    f.submit();
  }

  return (
    <Layout title="Checkout">
      <div className="wrap" style={{ paddingTop: '28px' }}>
        <div className="cat-banner">
          <div className="section-eyebrow">Almost There</div>
          <h1>🧾 Checkout</h1>
          <p>Review your order and choose how you&apos;d like to pay.</p>
        </div>
      </div>
      <div className="wrap pdp" style={{ paddingBottom: '64px' }}>
        <div>
          <h2 className="section-title" style={{ marginBottom: '1rem' }}>Order Summary</h2>
          {cart.length === 0 ? (
            <div className="cart-empty">
              Your cart is empty. <Link href="/" style={{ color: 'var(--accent)' }}>Continue shopping →</Link>
            </div>
          ) : (
            <>
              {cart.map((item) => (
                <div className="cart-line" key={item.id}>
                  <div className="cart-line-emoji">{item.emoji}</div>
                  <div className="cart-line-info">
                    <div className="cart-line-name">{item.name}</div>
                    <div className="cart-line-price">{formatPKR(item.price)}</div>
                  </div>
                  <div className="qty-controls">
                    <button onClick={() => updateQty(item.id, item.qty - 1)}>−</button>
                    <span>{item.qty}</span>
                    <button onClick={() => updateQty(item.id, item.qty + 1)}>+</button>
                  </div>
                  <button className="close-btn" style={{ position: 'static', fontSize: '1rem' }} onClick={() => removeFromCart(item.id)} aria-label="Remove">🗑</button>
                </div>
              ))}
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '1rem', fontWeight: 700, fontSize: '1.1rem' }}>
                <span>Total</span>
                <span style={{ color: 'var(--accent)' }}>{formatPKR(cartTotal)}</span>
              </div>
            </>
          )}
        </div>
        <div>
          <h2 className="section-title" style={{ marginBottom: '1rem' }}>Delivery Details</h2>
          <form onSubmit={placeOrder} style={{ display: 'flex', flexDirection: 'column', gap: '0.9rem' }}>
            <input className="search-input" style={{ background: 'rgba(199,205,216,0.06)', border: '1px solid rgba(199,205,216,0.15)', borderRadius: '0.5rem', padding: '0.7rem' }}
              name="name" placeholder="Full name" value={form.name} onChange={handleChange} required />
            <input className="search-input" style={{ background: 'rgba(199,205,216,0.06)', border: '1px solid rgba(199,205,216,0.15)', borderRadius: '0.5rem', padding: '0.7rem' }}
              name="email" type="email" placeholder="Email address" value={form.email} onChange={handleChange} required />
            <input className="search-input" style={{ background: 'rgba(199,205,216,0.06)', border: '1px solid rgba(199,205,216,0.15)', borderRadius: '0.5rem', padding: '0.7rem' }}
              name="phone" placeholder="WhatsApp / Phone number" value={form.phone} onChange={handleChange} required />
            <textarea className="search-input" style={{ background: 'rgba(199,205,216,0.06)', border: '1px solid rgba(199,205,216,0.15)', borderRadius: '0.5rem', padding: '0.7rem', minHeight: '90px' }}
              name="notes" placeholder="Account details / notes (e.g. game ID, email for activation)" value={form.notes} onChange={handleChange} />

            <div>
              <p style={{ fontSize: '0.8rem', color: 'var(--text-dim)', marginBottom: '0.5rem' }}>Pay with</p>
              <PaymentLogos selected={method} onSelect={setMethod} />
            </div>

            <button className="buy-btn" type="submit" style={{ padding: '0.9rem', borderRadius: '0.6rem', fontSize: '0.9rem' }} disabled={cart.length === 0 || loading}>
              {loading ? 'Processing…' : `Place Order — ${formatPKR(cartTotal)}`}
            </button>
          </form>

          {bankInstructions && (
            <div style={{ marginTop: '1.25rem', padding: '1rem', borderRadius: '0.6rem', border: '1px solid rgba(199,205,216,0.15)', background: 'rgba(199,205,216,0.05)' }}>
              <p style={{ fontWeight: 700, marginBottom: '0.5rem' }}>{bankInstructions.bank}</p>
              {bankInstructions.iban && <p style={{ fontSize: '0.85rem' }}>IBAN: {bankInstructions.iban}</p>}
              {bankInstructions.accountNumber && <p style={{ fontSize: '0.85rem' }}>Account: {bankInstructions.accountNumber}</p>}
              <p style={{ fontSize: '0.85rem' }}>Title: {bankInstructions.accountTitle}</p>
              <p style={{ fontSize: '0.85rem' }}>Amount: {formatPKR(bankInstructions.amount)}</p>
              <p style={{ fontSize: '0.85rem' }}>Reference: {bankInstructions.reference}</p>
              {bankInstructions.instructions && (
                <p style={{ fontSize: '0.75rem', color: 'var(--text-dim)', marginTop: '0.5rem' }}>{bankInstructions.instructions}</p>
              )}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
