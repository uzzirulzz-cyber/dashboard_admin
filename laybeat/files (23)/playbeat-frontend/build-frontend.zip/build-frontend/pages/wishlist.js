// pages/wishlist.js
import Layout from '../components/Layout';
import ProductCard from '../components/ProductCard';
import { useCart } from '../lib/CartContext';

export default function WishlistPage() {
  const { wishlist } = useCart();

  return (
    <Layout title="Wishlist">
      <div className="wrap" style={{ paddingTop: '28px' }}>
        <div className="cat-banner">
          <div className="section-eyebrow">Saved For Later</div>
          <h1>♥ Your Wishlist</h1>
          <p>{wishlist.length} item{wishlist.length === 1 ? '' : 's'} saved.</p>
        </div>
      </div>
      <div className="wrap" style={{ paddingBottom: '64px' }}>
        {wishlist.length === 0 ? (
          <div className="cart-empty">Your wishlist is empty. Tap the ♡ on any product to save it here.</div>
        ) : (
          <div className="product-grid">
            {wishlist.map((p) => (
              <ProductCard product={p} key={p.id} />
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
