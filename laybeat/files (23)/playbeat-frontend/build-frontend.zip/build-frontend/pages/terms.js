// pages/terms.js
import Layout from '../components/Layout';

export default function TermsPage() {
  return (
    <Layout title="Terms of Service">
      <div className="wrap" style={{ paddingTop: '28px', paddingBottom: '64px', maxWidth: '40rem' }}>
        <div className="cat-banner">
          <div className="section-eyebrow">Legal</div>
          <h1>Terms of Service</h1>
          <p>The rules that govern your use of PlayBeat Digital.</p>
        </div>
        <p style={{ color: 'var(--text-secondary)', lineHeight: 1.9 }}>
          By placing an order on PlayBeat Digital you agree to provide accurate account information
          for activation, and to use purchased digital goods in accordance with each platform&apos;s
          own terms of service. PlayBeat Digital is not affiliated with the brands listed unless
          stated otherwise.
        </p>
      </div>
    </Layout>
  );
}
