// pages/privacy.js
import Layout from '../components/Layout';

export default function PrivacyPage() {
  return (
    <Layout title="Privacy Policy">
      <div className="wrap" style={{ paddingTop: '28px', paddingBottom: '64px', maxWidth: '40rem' }}>
        <div className="cat-banner">
          <div className="section-eyebrow">Legal</div>
          <h1>Privacy Policy</h1>
          <p>How PlayBeat Digital (Pvt) Ltd collects, uses and protects your information.</p>
        </div>
        <p style={{ color: 'var(--text-secondary)', lineHeight: 1.9 }}>
          We collect only the information needed to process your order — name, contact details,
          and account information required for product activation. We never sell your data to
          third parties. Payment details are processed securely by our payment partners and are
          not stored on our servers.
        </p>
      </div>
    </Layout>
  );
}
