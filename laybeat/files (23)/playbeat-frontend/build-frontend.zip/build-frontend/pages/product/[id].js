// pages/product/[id].js
import Link from 'next/link';
import { useRouter } from 'next/router';
import Layout from '../../components/Layout';
import ProductCard from '../../components/ProductCard';
import { useCart } from '../../lib/CartContext';
import { PRODUCTS, getProductById, getCategory, getProductsByCategory, formatPKR } from '../../lib/products';

export async function getStaticPaths() {
  return {
    paths: PRODUCTS.map((p) => ({ params: { id: p.id } })),
    fallback: false,
  };
}

export async function getStaticProps({ params }) {
  const product = getProductById(params.id);
  const category = getCategory(product.category);
  const related = getProductsByCategory(product.category)
    .filter((p) => p.id !== product.id)
    .slice(0, 4);
  return { props: { product, category, related } };
}

export default function ProductPage({ product, category, related }) {
  const router = useRouter();
  const { addToCart, toggleWish, isWished } = useCart();
  const wished = isWished(product.id);
  const discount = product.oldPrice
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
    : null;

  function buyNow() {
    addToCart(product);
    router.push('/checkout');
  }

  return (
    <Layout title={product.name}>
      <div className="wrap pdp">
        <div>
          <div className="pdp-image">{product.emoji}</div>
        </div>
        <div>
          <p className="pdp-breadcrumb">
            <Link href="/">Home</Link> / <Link href={`/${category.slug}`}>{category.label}</Link> / {product.name}
          </p>
          <h1>{product.name}</h1>
          <div className="pdp-brand">{product.brand}</div>
          <div className="pdp-price-row">
            <span className="pdp-price">{formatPKR(product.price)}</span>
            {product.oldPrice && <span className="pdp-old-price">{formatPKR(product.oldPrice)}</span>}
            {discount && <span className="pdp-discount">Save {discount}%</span>}
          </div>
          <div className="pdp-actions">
            <button className="add-cart-btn" onClick={() => addToCart(product)}>+ Add to Cart</button>
            <button className="buy-btn" onClick={buyNow}>Buy Now</button>
            <button className={`btn-secondary${wished ? '' : ''}`} onClick={() => toggleWish(product)}>
              {wished ? '♥ Wishlisted' : '♡ Add to Wishlist'}
            </button>
          </div>
          <div className="pdp-features">
            <div className="pdp-feature"><b>⚡ Instant Delivery</b>Delivered to your account or inbox within minutes.</div>
            <div className="pdp-feature"><b>🛡️ Buyer Protected</b>Full refund if the code or service doesn&apos;t work.</div>
            <div className="pdp-feature"><b>💬 24/7 Support</b>Real human support via WhatsApp &amp; Telegram.</div>
          </div>
          <p className="pdp-description">
            {product.name} from {product.brand}, available now on PlayBeat Digital. All prices are listed
            in PKR with instant digital delivery and full buyer protection. Need help activating your
            purchase? Our support team is available around the clock via WhatsApp, Telegram, or email.
          </p>
        </div>
      </div>

      {related.length > 0 && (
        <div className="wrap" style={{ paddingBottom: '64px' }}>
          <div className="section-header">
            <h2 className="section-title">You may also like</h2>
            <Link href={`/${category.slug}`} className="section-link">View all →</Link>
          </div>
          <div className="product-grid">
            {related.map((p) => (
              <ProductCard product={p} key={p.id} />
            ))}
          </div>
        </div>
      )}
    </Layout>
  );
}
