// pages/[category].js
import { useState, useMemo } from 'react';
import Layout from '../components/Layout';
import ProductCard from '../components/ProductCard';
import { CATEGORIES, getCategory, getProductsByCategory } from '../lib/products';

export async function getStaticPaths() {
  return {
    paths: CATEGORIES.map((c) => ({ params: { category: c.slug } })),
    fallback: false,
  };
}

export async function getStaticProps({ params }) {
  const category = getCategory(params.category);
  const products = getProductsByCategory(params.category);
  return { props: { category, products } };
}

export default function CategoryPage({ category, products }) {
  const [sort, setSort] = useState('default');

  const sorted = useMemo(() => {
    const list = [...products];
    if (sort === 'price-asc') list.sort((a, b) => a.price - b.price);
    if (sort === 'price-desc') list.sort((a, b) => b.price - a.price);
    return list;
  }, [products, sort]);

  return (
    <Layout title={category.label}>
      <div className="wrap" style={{ paddingTop: '28px' }}>
        <div className="cat-banner">
          <div className="section-eyebrow">{category.eyebrow}</div>
          <h1>{category.title}</h1>
          <p>{category.description}</p>
          <div className="cat-stats">
            {category.stats.map((s) => (
              <div className="cat-stat" key={s} dangerouslySetInnerHTML={{ __html: s.replace(/(\d+\+?%?)/, '<b>$1</b>') }} />
            ))}
          </div>
        </div>
        <div className="filter-bar">
          <span className="filter-label">Sort by</span>
          <select className="filter-select" value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="default">Featured</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
          </select>
          <span className="result-count">{products.length} PRODUCTS</span>
        </div>
      </div>
      <div className="wrap" style={{ paddingBottom: '64px' }}>
        <div className="product-grid">
          {sorted.map((p) => (
            <ProductCard product={p} key={p.id} />
          ))}
        </div>
      </div>
    </Layout>
  );
}
