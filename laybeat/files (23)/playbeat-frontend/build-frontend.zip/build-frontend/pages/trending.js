// pages/trending.js
import { useState, useMemo } from 'react';
import Layout from '../components/Layout';
import ProductCard from '../components/ProductCard';
import { getTrending } from '../lib/products';

export async function getStaticProps() {
  return { props: { products: getTrending() } };
}

export default function TrendingPage({ products }) {
  const [sort, setSort] = useState('default');

  const sorted = useMemo(() => {
    const list = products.map((p, i) => ({ ...p, rank: i + 1 }));
    if (sort === 'price-asc') return [...list].sort((a, b) => a.price - b.price);
    if (sort === 'price-desc') return [...list].sort((a, b) => b.price - a.price);
    return list;
  }, [products, sort]);

  return (
    <Layout title="Trending">
      <div className="wrap" style={{ paddingTop: '28px' }}>
        <div className="cat-banner">
          <div className="section-eyebrow">Updated Hourly · Across All Categories</div>
          <h1>✦ Trending Now</h1>
          <p>What PlayBeat shoppers are buying right now — ranked live.</p>
          <div className="cat-stats">
            <div className="cat-stat">🔥 <b>{products.length}</b> Hot Picks</div>
            <div className="cat-stat">📈 Refreshed Hourly</div>
            <div className="cat-stat">🛡️ Buyer Protected</div>
          </div>
        </div>
        <div className="filter-bar">
          <span className="filter-label">Sort by</span>
          <select className="filter-select" value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="default">Featured</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
          </select>
          <span className="result-count">{products.length} PRODUCTS</span>
        </div>
      </div>
      <div className="wrap" style={{ paddingBottom: '64px' }}>
        <div className="product-grid">
          {sorted.map((p) => (
            <ProductCard product={p} rank={sort === 'default' ? p.rank : undefined} key={p.id} />
          ))}
        </div>
      </div>
    </Layout>
  );
}
