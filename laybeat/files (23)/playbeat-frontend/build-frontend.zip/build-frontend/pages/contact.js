// pages/contact.js
import Layout from '../components/Layout';

export default function ContactPage() {
  return (
    <Layout title="Contact Us">
      <div className="wrap" style={{ paddingTop: '28px', paddingBottom: '64px', maxWidth: '40rem' }}>
        <div className="cat-banner">
          <div className="section-eyebrow">We&apos;re Here to Help</div>
          <h1>Contact Us</h1>
          <p>Reach out via any of the channels below — our team responds 24/7.</p>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginTop: '1.5rem' }}>
          <a className="btn-support email" href="mailto:support@playbeat.gg">📧 support@playbeat.gg</a>
          <a className="btn-support whatsapp" href="https://wa.me/923318333368" target="_blank" rel="noopener noreferrer">💬 WhatsApp: +92 331 8333368</a>
          <a className="btn-support telegram" href="https://t.me/playbeat" target="_blank" rel="noopener noreferrer">✈️ Telegram: @playbeat</a>
        </div>
      </div>
    </Layout>
  );
}
