// pages/refund.js
import Layout from '../components/Layout';

export default function RefundPage() {
  return (
    <Layout title="Refund Policy">
      <div className="wrap" style={{ paddingTop: '28px', paddingBottom: '64px', maxWidth: '40rem' }}>
        <div className="cat-banner">
          <div className="section-eyebrow">Legal</div>
          <h1>Refund Policy</h1>
          <p>Buyer protection for every order placed on PlayBeat Digital.</p>
        </div>
        <p style={{ color: 'var(--text-secondary)', lineHeight: 1.9 }}>
          If a code, key, or account fails to activate, contact support within 24 hours with your
          order ID. We will issue a replacement or a full refund to your original payment method
          once the issue is verified. Refunds are not available once a digital code has been
          revealed and successfully redeemed.
        </p>
      </div>
    </Layout>
  );
}
