# PlayBeat Digital — Backend (Express + MongoDB)

## Setup

```bash
npm install
cp .env.example .env   # fill in real values — .env is gitignored
npm run dev            # nodemon, port 5000
npm run seed           # seed all 96 products into MongoDB
```

Health check: `GET http://localhost:5000/api/health`

---

## ⚠️ Security notes

- **`.env` is gitignored.** Never commit it.
- Test-mode Stripe keys (`sk_test_`/`pk_test_`/`rk_test_`) are fine for development — rotate in the Stripe dashboard before going live.
- No payment secrets are ever sent to the Next.js frontend.
- Admin JWT tokens expire after 12 hours.

---

## API Surface

### Public
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/products` | Product catalog (`?cat=&q=&limit=`) |
| GET | `/api/products/:id` | Single product |
| POST | `/api/orders` | Create order |
| GET | `/api/payments/methods` | Enabled gateway logos |
| POST | `/api/payments/checkout` | Initiate payment |
| GET | `/api/homepage` | Homepage config (banners, ticker, SEO) |

### Admin (all require `Authorization: Bearer <jwt>`)
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/admin/login` | Login → JWT |
| GET | `/api/admin/users` | List admin users |
| POST | `/api/admin/users` | Create admin user |
| PATCH | `/api/admin/users/:id` | Update user / reset password |
| DELETE | `/api/admin/users/:id` | Remove user |
| GET | `/api/admin/stats` | Dashboard KPIs |
| GET | `/api/admin/analytics` | Deep analytics (`?range=30`) |
| GET | `/api/admin/orders` | Order list (`?status=&q=&limit=`) |
| PATCH | `/api/admin/orders/:id` | Update order |
| DELETE | `/api/admin/orders/:id` | Cancel order |
| GET | `/api/admin/products` | Product list (`?cat=&q=&limit=`) |
| POST | `/api/admin/products` | Create product |
| PATCH | `/api/admin/products/:id` | Update product |
| DELETE | `/api/admin/products/:id` | Delete product |
| GET | `/api/admin/coupons` | Coupon list |
| POST | `/api/admin/coupons` | Create coupon |
| PATCH | `/api/admin/coupons/:id` | Update coupon |
| DELETE | `/api/admin/coupons/:id` | Delete coupon |
| POST | `/api/admin/coupons/validate` | Validate code at checkout |
| GET | `/api/admin/customers` | Customer list (aggregated from orders) |
| GET | `/api/admin/customers/:email` | Customer profile + order history |
| GET | `/api/admin/homepage` | Get homepage config |
| PUT | `/api/admin/homepage` | Replace homepage config |
| PATCH | `/api/admin/homepage` | Partial update |
| POST | `/api/admin/homepage/banner` | Add hero banner |
| PATCH | `/api/admin/homepage/banner/:id` | Update banner |
| DELETE | `/api/admin/homepage/banner/:id` | Delete banner |
| GET | `/api/admin/gateways` | Gateway status |
| PATCH | `/api/admin/gateways/:id` | Toggle gateway |
| GET | `/api/admin/payments` | Masked key view |

---

## Models

| Model | File | Notes |
|-------|------|-------|
| `Order` | `src/models/Order.js` | Cart items, totals, customer, payment |
| `Product` | `src/models/Product.js` | Catalog; seed with `npm run seed` |
| `PaymentSettings` | `src/models/PaymentSettings.js` | Gateway enabled/disabled overrides |
| `Coupon` | `src/models/Coupon.js` | Discount codes (percent / fixed PKR) |
| `HomepageConfig` | `src/models/HomepageConfig.js` | Banners, ticker, SEO — single document |
| `AdminUser` | `src/models/AdminUser.js` | RBAC admin accounts (4 roles) |

---

## Admin roles

| Role | Permissions |
|------|-------------|
| `super_admin` | Everything |
| `manager` | dashboard, orders, products, coupons, customers, homepage, analytics |
| `support` | dashboard, orders, customers |
| `viewer` | dashboard, analytics |

Custom per-user permission overrides stack on top of role defaults.

**Login fallback:** Until you create the first `AdminUser` in the DB, login falls back to `ADMIN_EMAIL`/`ADMIN_PASSWORD` in `.env`.

---

## Payment architecture

```
Checkout page (Next.js)
   │  GET /api/payments/methods   → enabled gateway logos only
   │  POST /api/orders            → { order }
   │  POST /api/payments/checkout → gateway-specific response:
   │       stripe   → { type: 'redirect', url }
   │       jazzcash → { type: 'form_post', action, fields }
   │       alfalah  → { mode: 'gateway' | 'manual_transfer', ... }
   │       meezan   → { mode: 'gateway' | 'manual_transfer', ... }
   ▼
Express API (src/controllers/*Controller.js)
   ▼
Stripe / JazzCash / Bank Alfalah / Meezan APIs
```
