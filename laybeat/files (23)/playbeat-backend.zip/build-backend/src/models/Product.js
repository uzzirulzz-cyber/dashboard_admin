// src/models/Product.js
const mongoose = require('mongoose');

const productSchema = new mongoose.Schema(
  {
    id: { type: String, required: true, unique: true }, // stable slug, e.g. "chatgpt-plus---1-month"
    name: { type: String, required: true },
    category: { type: String, required: true },
    brand: { type: String, default: '' },
    emoji: { type: String, default: '🛒' },
    price: { type: Number, required: true },
    oldPrice: { type: Number },
    badge: { type: String, default: '' },
    stock: { type: Number, default: 0 },
    delivery: { type: String, enum: ['Instant', 'Manual'], default: 'Instant' },
    description: { type: String, default: '' },
    active: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Product', productSchema);
