// src/models/PaymentSettings.js
const mongoose = require('mongoose');

const paymentSettingsSchema = new mongoose.Schema(
  {
    gatewayId: { type: String, required: true, unique: true }, // 'stripe' | 'jazzcash' | 'alfalah' | 'meezan'
    enabled: { type: Boolean, default: false },
    updatedBy: { type: String, default: 'system' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('PaymentSettings', paymentSettingsSchema);
