// src/models/AdminUser.js
// Full admin user accounts with role-based access control.
// In Step 6 this replaces the ADMIN_EMAIL/ADMIN_PASSWORD env-variable approach.
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const ROLES = ['super_admin', 'manager', 'support', 'viewer'];
const PERMISSIONS = [
  'dashboard', 'orders', 'products', 'coupons',
  'payments', 'customers', 'homepage', 'analytics', 'admin_users',
];

const adminUserSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true },
    role: { type: String, enum: ROLES, default: 'viewer' },
    // Custom permission overrides (per-user, takes precedence over role defaults)
    permissions: [{ type: String, enum: PERMISSIONS }],
    active: { type: Boolean, default: true },
    lastLoginAt: { type: Date },
    avatarInitials: { type: String, default: '' },
  },
  { timestamps: true }
);

// Virtual: effective permissions combining role defaults + custom grants
adminUserSchema.virtual('effectivePermissions').get(function () {
  const roleDefaults = {
    super_admin: PERMISSIONS, // all
    manager: ['dashboard', 'orders', 'products', 'coupons', 'customers', 'homepage', 'analytics'],
    support: ['dashboard', 'orders', 'customers'],
    viewer: ['dashboard', 'analytics'],
  };
  const base = new Set(roleDefaults[this.role] || []);
  (this.permissions || []).forEach((p) => base.add(p));
  return [...base];
});

adminUserSchema.methods.checkPassword = async function (plain) {
  return bcrypt.compare(plain, this.passwordHash);
};

adminUserSchema.statics.hashPassword = (plain) => bcrypt.hash(plain, 12);

adminUserSchema.statics.ROLES = ROLES;
adminUserSchema.statics.PERMISSIONS = PERMISSIONS;

// Strip sensitive fields when serialising
adminUserSchema.methods.toSafe = function () {
  return {
    id: this._id,
    name: this.name,
    email: this.email,
    role: this.role,
    permissions: this.effectivePermissions,
    active: this.active,
    lastLoginAt: this.lastLoginAt,
    avatarInitials: this.avatarInitials || this.name.slice(0, 2).toUpperCase(),
    createdAt: this.createdAt,
  };
};

module.exports = mongoose.model('AdminUser', adminUserSchema);
