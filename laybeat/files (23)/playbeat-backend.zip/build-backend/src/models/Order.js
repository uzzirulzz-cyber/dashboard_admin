// src/models/Order.js
const mongoose = require('mongoose');

const orderItemSchema = new mongoose.Schema(
  {
    productId: { type: String, required: true },
    name: { type: String, required: true },
    price: { type: Number, required: true },
    qty: { type: Number, required: true, default: 1 },
    emoji: String,
    deliveryKey: { type: String, default: '' },
  },
  { _id: false }
);

const orderSchema = new mongoose.Schema(
  {
    items: [orderItemSchema],
    total: { type: Number, required: true },
    currency: { type: String, default: 'PKR' },
    customer: {
      name: String,
      email: String,
      phone: String,
      notes: String,
    },
    paymentMethod: { type: String, enum: ['stripe', 'jazzcash', 'alfalah', 'meezan'], required: true },
    paymentStatus: { type: String, enum: ['pending', 'paid', 'failed', 'refunded'], default: 'pending' },
    paymentRef: { type: String }, // gateway transaction/session id
    status: { type: String, enum: ['pending', 'processing', 'fulfilled', 'cancelled'], default: 'pending' },
    adminNotes: { type: String, default: '' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Order', orderSchema);
