// src/models/HomepageConfig.js
// Stores the admin-editable homepage settings as a single config document.
const mongoose = require('mongoose');

const bannerSchema = new mongoose.Schema(
  {
    id: { type: String, required: true },
    title: { type: String, default: '' },
    subtitle: { type: String, default: '' },
    cta: { type: String, default: 'Shop Now' },
    href: { type: String, default: '/' },
    badge: { type: String, default: '' },
    gradient: { type: String, default: 'linear-gradient(135deg,#1a1a2e,#16213e)' },
    emoji: { type: String, default: '⚡' },
    active: { type: Boolean, default: true },
    order: { type: Number, default: 0 },
  },
  { _id: false }
);

const homepageConfigSchema = new mongoose.Schema(
  {
    // Only one document; use upsert with key: 'singleton'
    _key: { type: String, default: 'singleton', unique: true },

    ticker: {
      enabled: { type: Boolean, default: true },
      items: [{ type: String }],
    },

    heroBanners: [bannerSchema],

    featuredCategories: [{ type: String }], // array of category slugs

    announcementBar: {
      enabled: { type: Boolean, default: false },
      text: { type: String, default: '' },
      color: { type: String, default: '#d4af37' },
    },

    seo: {
      title: { type: String, default: 'PlayBeat — Gaming & Digital Store Pakistan' },
      description: { type: String, default: 'Buy games, gift cards, software and AI tools instantly in Pakistan.' },
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('HomepageConfig', homepageConfigSchema);
