// src/middleware/adminAuth.js
const jwt = require('jsonwebtoken');

// Protects /api/admin/* routes. Expects "Authorization: Bearer <token>".
// The JWT payload must include { role: 'admin' }. Full auth flow (login,
// user model, password hashing) is part of Step 7 — this middleware just
// validates whatever token that flow issues.
module.exports = function adminAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'Missing authorization token' });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'dev-secret');
    if (payload.role !== 'admin') {
      return res.status(403).json({ error: 'Admin access required' });
    }
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
};
