// src/server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');

const productsRoutes = require('./routes/products');
const ordersRoutes = require('./routes/orders');
const paymentsRoutes = require('./routes/payments');

const adminUsersRoutes = require('./routes/adminUsers');    // login + user CRUD (replaces adminAuth)
const adminStatsRoutes = require('./routes/adminStats');
const adminOrdersRoutes = require('./routes/adminOrders');
const adminProductsRoutes = require('./routes/adminProducts');
const adminPaymentsRoutes = require('./routes/adminPayments');
const adminGatewaysRoutes = require('./routes/adminGateways');
const adminCouponsRoutes = require('./routes/adminCoupons');
const adminCustomersRoutes = require('./routes/adminCustomers');
const adminHomepageRoutes = require('./routes/adminHomepage');
const adminAnalyticsRoutes = require('./routes/adminAnalytics');

const app = express();

app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:3000' }));
app.use(express.json());

app.get('/api/health', (req, res) => res.json({ ok: true }));

// ── Public ────────────────────────────────────────────────────────────────────
app.use('/api/products', productsRoutes);
app.use('/api/orders', ordersRoutes);
app.use('/api/payments', paymentsRoutes);
// Public homepage config (storefront reads this)
app.use('/api/homepage', require('./routes/adminHomepage'));

// ── Admin ─────────────────────────────────────────────────────────────────────
// POST /api/admin/login  — now handled by adminUsers (falls back to env vars)
app.use('/api/admin', adminUsersRoutes);       // /login + /users CRUD
app.use('/api/admin/stats', adminStatsRoutes);
app.use('/api/admin/orders', adminOrdersRoutes);
app.use('/api/admin/products', adminProductsRoutes);
app.use('/api/admin/payments', adminPaymentsRoutes);   // masked key view (legacy)
app.use('/api/admin/gateways', adminGatewaysRoutes);   // gateway toggles (admin UI)
app.use('/api/admin/coupons', adminCouponsRoutes);
app.use('/api/admin/customers', adminCustomersRoutes);
app.use('/api/admin/homepage', adminHomepageRoutes);
app.use('/api/admin/analytics', adminAnalyticsRoutes);

const PORT = process.env.PORT || 5000;

connectDB().then(() => {
  app.listen(PORT, () => console.log(`🚀 PlayBeat API running on port ${PORT}`));
});
