// src/controllers/meezanController.js
const meezan = require('../config/payments/meezan');

// Meezan Bank's MezPay API uses HTTP Basic Auth (username/password from your
// onboarding pack) plus success/failed callback paths. The exact request
// shape depends on the API version Meezan provisions for your merchant
// account — once you have that doc, post the order details (amount,
// reference, IBAN) to their endpoint here.
//
// Until those credentials are configured, return manual bank-transfer
// instructions using the IBAN/title you provided so checkout still works.
function buildPaymentRequest(order) {
  if (!meezan.username || !meezan.password) {
    return {
      mode: 'manual_transfer',
      bank: 'Meezan Bank',
      iban: meezan.iban,
      accountTitle: meezan.accountTitle,
      amount: order.total,
      reference: String(order._id),
      instructions:
        'Transfer the order total to this IBAN and share the transaction receipt via WhatsApp. ' +
        'The order will be marked as paid once the receipt is verified.',
    };
  }

  return {
    mode: 'gateway',
    iban: meezan.iban,
    accountTitle: meezan.accountTitle,
    amount: order.total,
    reference: String(order._id),
    successCallback: meezan.successCallback,
    failedCallback: meezan.failedCallback,
  };
}

module.exports = { buildPaymentRequest };
