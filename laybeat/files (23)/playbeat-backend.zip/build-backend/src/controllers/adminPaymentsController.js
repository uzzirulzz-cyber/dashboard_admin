// src/controllers/adminPaymentsController.js
const PaymentSettings = require('../models/PaymentSettings');
const { getAdminPaymentMethods } = require('../config/payments');

// GET /api/admin/payments
// Returns masked key previews + current enabled state (DB override > env).
async function getSettings(req, res) {
  const methods = getAdminPaymentMethods();
  const overrides = await PaymentSettings.find({});
  const overrideMap = overrides.reduce((acc, d) => {
    acc[d.gatewayId] = d.enabled;
    return acc;
  }, {});

  const result = methods.map((m) => ({
    ...m,
    enabled: overrideMap[m.id] !== undefined ? overrideMap[m.id] : m.enabled,
    envDefault: m.enabled,
  }));

  res.json({ methods: result });
}

// PATCH /api/admin/payments/:gatewayId
// Body: { enabled: boolean }
async function updateSetting(req, res) {
  const { gatewayId } = req.params;
  const { enabled } = req.body;

  if (typeof enabled !== 'boolean') {
    return res.status(400).json({ error: '"enabled" must be a boolean' });
  }

  const allowed = ['stripe', 'jazzcash', 'alfalah', 'meezan'];
  if (!allowed.includes(gatewayId)) {
    return res.status(404).json({ error: 'Unknown gateway' });
  }

  const updated = await PaymentSettings.findOneAndUpdate(
    { gatewayId },
    { gatewayId, enabled, updatedBy: req.user?.email || 'admin' },
    { upsert: true, new: true }
  );

  res.json({ gatewayId: updated.gatewayId, enabled: updated.enabled });
}

module.exports = { getSettings, updateSetting };
