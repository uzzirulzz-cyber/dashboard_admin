// src/controllers/alfalahController.js
const crypto = require('crypto');
const alfalah = require('../config/payments/alfalah');

// Bank Alfalah's HS (Hosted Session) API expects an HMAC-SHA256 request hash
// built from key business fields, signed with key_1/key_2 from the merchant
// onboarding pack. The exact field order/format is specified in Bank
// Alfalah's integration guide for your merchant_id — fill that in once you
// have it. This function is wired up and ready for those details.
function generateRequestHash(payload) {
  if (!alfalah.key1) return null;
  const base = `${payload.merchant_id}${payload.store_id}${payload.order_id}${payload.amount}${alfalah.key1}`;
  return crypto.createHmac('sha256', alfalah.key2 || alfalah.key1).update(base).digest('hex');
}

// Builds a Bank Alfalah hosted-checkout request for the given order. If the
// merchant credentials aren't configured yet, returns manual bank-transfer
// instructions instead (account number + title you provided), so checkout
// still works while onboarding with Bank Alfalah is in progress.
function buildPaymentRequest(order) {
  if (!alfalah.merchantUsername || !alfalah.merchantHash) {
    return {
      mode: 'manual_transfer',
      bank: 'Bank Alfalah',
      accountTitle: alfalah.accountTitle,
      accountNumber: alfalah.accountNumber,
      amount: order.total,
      reference: String(order._id),
      instructions:
        'Transfer the order total to this account and share the transaction receipt via WhatsApp. ' +
        'The order will be marked as paid once the receipt is verified.',
    };
  }

  const payload = {
    api_url: alfalah.apiUrl,
    channel_id: alfalah.channelId,
    merchant_id: alfalah.merchantId,
    store_id: alfalah.storeId,
    order_id: String(order._id),
    amount: order.total.toFixed(2),
    currency: 'PKR',
    return_url: alfalah.returnUrl,
  };
  payload.request_hash = generateRequestHash(payload);

  return { mode: 'gateway', ...payload };
}

module.exports = { buildPaymentRequest, generateRequestHash };
