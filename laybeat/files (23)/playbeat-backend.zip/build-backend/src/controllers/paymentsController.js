// src/controllers/paymentsController.js
const Order = require('../models/Order');
const { getMergedCatalog } = require('../utils/paymentSettingsStore');
const stripeController = require('./stripeController');
const jazzcashController = require('./jazzcashController');
const alfalahController = require('./alfalahController');
const meezanController = require('./meezanController');

// GET /api/payments/methods
// Returns ONLY { id, name, logo, enabled } for each gateway — used by the
// checkout page to render logos/buttons. No secrets, no account numbers.
async function getMethods(req, res) {
  const catalog = await getMergedCatalog();
  const methods = catalog
    .filter((g) => g.enabled)
    .map((g) => ({ id: g.id, name: g.name, logo: g.logo }));
  res.json({ methods });
}

// POST /api/payments/checkout
// Body: { orderId, method }
// Creates the gateway-specific session/instructions for an existing order.
async function initiateCheckout(req, res) {
  try {
    const { orderId, method } = req.body;
    if (!orderId || !method) {
      return res.status(400).json({ error: 'orderId and method are required' });
    }

    const order = await Order.findById(orderId);
    if (!order) return res.status(404).json({ error: 'Order not found' });

    const catalog = await getMergedCatalog();
    const gateway = catalog.find((g) => g.id === method);
    if (!gateway || !gateway.enabled) {
      return res.status(400).json({ error: `Payment method "${method}" is not available` });
    }

    order.paymentMethod = method;
    await order.save();

    switch (method) {
      case 'stripe': {
        const session = await stripeController.createCheckoutSession(order);
        order.paymentRef = session.id;
        await order.save();
        return res.json({ type: 'redirect', url: session.url });
      }
      case 'jazzcash': {
        const txn = jazzcashController.buildTransactionRequest(order);
        return res.json({ type: 'form_post', ...txn });
      }
      case 'alfalah': {
        const txn = alfalahController.buildPaymentRequest(order);
        return res.json(txn);
      }
      case 'meezan': {
        const txn = meezanController.buildPaymentRequest(order);
        return res.json(txn);
      }
      default:
        return res.status(400).json({ error: 'Unsupported payment method' });
    }
  } catch (err) {
    console.error('Checkout initiation failed:', err);
    res.status(500).json({ error: err.message || 'Checkout initiation failed' });
  }
}

module.exports = { getMethods, initiateCheckout };
