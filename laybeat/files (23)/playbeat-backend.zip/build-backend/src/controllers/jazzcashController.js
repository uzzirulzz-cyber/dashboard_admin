// src/controllers/jazzcashController.js
const crypto = require('crypto');
const jazzcash = require('../config/payments/jazzcash');

function pad(n) {
  return String(n).padStart(2, '0');
}

// JazzCash dates are formatted YYYYMMDDHHmmss in the configured timezone.
function jazzcashDateTime(date = new Date()) {
  return (
    date.getFullYear() +
    pad(date.getMonth() + 1) +
    pad(date.getDate()) +
    pad(date.getHours()) +
    pad(date.getMinutes()) +
    pad(date.getSeconds())
  );
}

// JazzCash's secure hash: sort all non-empty pp_* params alphabetically by
// key, join "key=value" pairs with "&", prefix with the Integrity Salt
// (hashKey), then HMAC-SHA256 -> uppercase hex.
function generateSecureHash(params) {
  const sorted = Object.keys(params)
    .filter((k) => params[k] !== '' && params[k] !== undefined && params[k] !== null)
    .sort()
    .map((k) => `${k}=${params[k]}`)
    .join('&');

  const stringToHash = `${jazzcash.hashKey}&${sorted}`;
  return crypto.createHmac('sha256', jazzcash.hashKey).update(stringToHash).digest('hex').toUpperCase();
}

// Builds the form-post params for JazzCash's "Mobile Wallet" / "Page
// Redirection" flow. The frontend renders a hidden form that auto-submits
// these fields to `sandboxApiUrl` / `apiUrl`.
function buildTransactionRequest(order) {
  if (!jazzcash.merchantId || !jazzcash.hashKey) {
    throw new Error('JazzCash is not configured (missing merchant ID / hash key)');
  }

  const now = new Date();
  const expiry = new Date(now.getTime() + 60 * 60 * 1000); // +1 hour

  const params = {
    pp_Version: '1.1',
    pp_TxnType: 'MWALLET',
    pp_Language: 'EN',
    pp_MerchantID: jazzcash.merchantId,
    pp_SubMerchantID: '',
    pp_Password: jazzcash.password,
    pp_BankID: '',
    pp_ProductID: '',
    pp_TxnRefNo: `T${order._id}`,
    pp_Amount: String(Math.round(order.total * 100)), // amount in paisa
    pp_TxnCurrency: 'PKR',
    pp_TxnDateTime: jazzcashDateTime(now),
    pp_BillReference: String(order._id),
    pp_Description: `PlayBeat Digital Order #${order._id}`,
    pp_TxnExpiryDateTime: jazzcashDateTime(expiry),
    pp_ReturnURL: jazzcash.returnUrl,
    pp_SecureHash: '',
    ppmpf_1: order.customer?.email || '',
    ppmpf_2: order.customer?.phone || '',
  };

  params.pp_SecureHash = generateSecureHash(params);

  return {
    action: jazzcash.mode === 'production' ? jazzcash.apiUrl : jazzcash.sandboxApiUrl,
    fields: params,
  };
}

module.exports = { buildTransactionRequest, generateSecureHash, jazzcashDateTime };
