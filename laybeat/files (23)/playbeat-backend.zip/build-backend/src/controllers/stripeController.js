// src/controllers/stripeController.js
const Stripe = require('stripe');
const stripeConfig = require('../config/payments/stripe');

let stripeClient = null;
function getClient() {
  if (!stripeConfig.secretKey) return null;
  if (!stripeClient) stripeClient = new Stripe(stripeConfig.secretKey);
  return stripeClient;
}

// Creates a Stripe Checkout Session for the given order and returns the
// hosted checkout URL. The frontend redirects the browser to this URL —
// no card data or secret keys ever touch the Next.js app.
async function createCheckoutSession(order) {
  const stripe = getClient();
  if (!stripe) {
    throw new Error('Stripe is not configured (missing STRIPE_SECRET_KEY)');
  }

  const line_items = order.items.map((item) => ({
    price_data: {
      currency: 'pkr',
      product_data: { name: item.name },
      unit_amount: Math.round(item.price * 100), // smallest currency unit
    },
    quantity: item.qty,
  }));

  const sessionParams = {
    mode: 'payment',
    payment_method_types: ['card'],
    line_items,
    customer_email: order.customer?.email || undefined,
    metadata: { orderId: String(order._id) },
    success_url: `${process.env.FRONTEND_URL}/checkout/return/stripe?session_id={CHECKOUT_SESSION_ID}&order=${order._id}`,
    cancel_url: `${process.env.FRONTEND_URL}/checkout?cancelled=1`,
  };

  // If you're using Stripe Connect (the acct_... account from your dashboard
  // link), route the session to that connected account:
  const requestOptions = stripeConfig.accountId ? { stripeAccount: stripeConfig.accountId } : undefined;

  const session = await stripe.checkout.sessions.create(sessionParams, requestOptions);
  return { url: session.url, id: session.id };
}

// Verifies a webhook event signature using the webhook secret.
function constructWebhookEvent(rawBody, signature) {
  const stripe = getClient();
  if (!stripe) throw new Error('Stripe is not configured');
  return stripe.webhooks.constructEvent(rawBody, signature, stripeConfig.webhookSecret);
}

module.exports = { createCheckoutSession, constructWebhookEvent };
