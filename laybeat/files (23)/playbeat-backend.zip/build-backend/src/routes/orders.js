// src/routes/orders.js
const express = require('express');
const Order = require('../models/Order');
const { serializeOrder } = require('../utils/serializeOrder');

const router = express.Router();

// POST /api/orders — create a pending order from the cart, before payment.
router.post('/', async (req, res) => {
  try {
    const { items, customer } = req.body;
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'items is required and must be a non-empty array' });
    }

    const total = items.reduce((sum, i) => sum + i.price * (i.qty || 1), 0);

    const order = await Order.create({
      items,
      total,
      customer,
      paymentMethod: 'stripe', // placeholder, set for real on /api/payments/checkout
      paymentStatus: 'pending',
      status: 'pending',
    });

    res.status(201).json({ order });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create order' });
  }
});

// GET /api/orders/:id
router.get('/:id', async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json({ order: serializeOrder(order) });
});

module.exports = router;
