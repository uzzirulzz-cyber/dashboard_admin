// src/routes/adminStats.js
const express = require('express');
const adminAuth = require('../middleware/adminAuth');
const Order = require('../models/Order');
const Product = require('../models/Product');

const router = express.Router();
router.use(adminAuth);

// GET /api/admin/stats
router.get('/', async (req, res) => {
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);

  const [
    totalRevenueAgg,
    totalOrders,
    todayOrders,
    pendingOrders,
    completedOrders,
    totalProducts,
    monthlyRevenue,
    paymentBreakdown,
    distinctCustomers,
    newCustomersToday,
  ] = await Promise.all([
    Order.aggregate([
      { $match: { paymentStatus: 'paid' } },
      { $group: { _id: null, total: { $sum: '$total' } } },
    ]),
    Order.countDocuments({}),
    Order.countDocuments({ createdAt: { $gte: startOfToday } }),
    Order.countDocuments({ status: 'pending' }),
    Order.countDocuments({ status: 'fulfilled' }),
    Product.countDocuments({}),
    Order.aggregate([
      { $match: { paymentStatus: 'paid' } },
      {
        $group: {
          _id: { year: { $year: '$createdAt' }, month: { $month: '$createdAt' } },
          total: { $sum: '$total' },
        },
      },
      { $sort: { '_id.year': 1, '_id.month': 1 } },
    ]),
    Order.aggregate([{ $group: { _id: '$paymentMethod', count: { $sum: 1 } } }]),
    Order.distinct('customer.email'),
    Order.distinct('customer.email', { createdAt: { $gte: startOfToday } }),
  ]);

  res.json({
    stats: {
      totalRevenue: totalRevenueAgg[0]?.total || 0,
      totalOrders,
      todayOrders,
      pendingOrders,
      completedOrders,
      totalProducts,
      // No dedicated User model yet (Step 7) — approximated from order emails.
      totalUsers: distinctCustomers.filter(Boolean).length,
      newUsers: newCustomersToday.filter(Boolean).length,
      monthlyRevenue,
      paymentBreakdown,
    },
  });
});

module.exports = router;
