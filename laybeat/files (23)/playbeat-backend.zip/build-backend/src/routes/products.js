// src/routes/products.js — public product catalog
const express = require('express');
const Product = require('../models/Product');

const router = express.Router();

// GET /api/products?cat=&q=&limit=
router.get('/', async (req, res) => {
  const { cat, q, limit } = req.query;
  const filter = { active: true };
  if (cat) filter.category = cat;
  if (q) filter.name = { $regex: q, $options: 'i' };

  const query = Product.find(filter).sort({ createdAt: -1 });
  if (limit) query.limit(Number(limit));

  const products = await query;
  res.json({ products, count: products.length });
});

// GET /api/products/:id
router.get('/:id', async (req, res) => {
  const product = await Product.findOne({ id: req.params.id });
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json({ product });
});

module.exports = router;
