// src/routes/adminUsers.js
// Admin user management — create/edit roles, reset passwords.
// The super_admin can do everything; other roles are restricted by permission checks.
const express = require('express');
const jwt = require('jsonwebtoken');
const adminAuth = require('../middleware/adminAuth');
const AdminUser = require('../models/AdminUser');

const router = express.Router();

// ─── Public: login (replaces env-var approach) ──────────────────────────────
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

  // Fall back to env-var super_admin if no DB users exist yet
  const dbUser = await AdminUser.findOne({ email: email.toLowerCase(), active: true });
  if (!dbUser) {
    // Legacy env-based login
    if (email === process.env.ADMIN_EMAIL && password === process.env.ADMIN_PASSWORD) {
      const token = jwt.sign({ email, role: 'admin' }, process.env.JWT_SECRET || 'dev-secret', { expiresIn: '12h' });
      return res.json({ token, user: { name: 'Admin', email, role: 'super_admin', permissions: AdminUser.PERMISSIONS } });
    }
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const ok = await dbUser.checkPassword(password);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

  dbUser.lastLoginAt = new Date();
  await dbUser.save();

  const token = jwt.sign(
    { id: dbUser._id, email: dbUser.email, role: 'admin', adminRole: dbUser.role },
    process.env.JWT_SECRET || 'dev-secret',
    { expiresIn: '12h' }
  );

  res.json({ token, user: dbUser.toSafe() });
});

// ─── Protected routes ────────────────────────────────────────────────────────
router.use(adminAuth);

// GET /api/admin/users
router.get('/', async (req, res) => {
  const users = await AdminUser.find({}).sort({ createdAt: 1 });
  res.json({ users: users.map((u) => u.toSafe()), roles: AdminUser.ROLES, permissions: AdminUser.PERMISSIONS });
});

// POST /api/admin/users
router.post('/', async (req, res) => {
  try {
    const { name, email, password, role, permissions } = req.body;
    const passwordHash = await AdminUser.hashPassword(password || 'ChangeMe123!');
    const user = await AdminUser.create({ name, email, passwordHash, role, permissions });
    res.status(201).json({ user: user.toSafe() });
  } catch (err) {
    if (err.code === 11000) return res.status(409).json({ error: 'Email already in use' });
    res.status(400).json({ error: err.message });
  }
});

// PATCH /api/admin/users/:id
router.patch('/:id', async (req, res) => {
  const { name, role, permissions, active, password } = req.body;
  const user = await AdminUser.findById(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  if (name !== undefined) user.name = name;
  if (role !== undefined) user.role = role;
  if (permissions !== undefined) user.permissions = permissions;
  if (active !== undefined) user.active = active;
  if (password) user.passwordHash = await AdminUser.hashPassword(password);

  await user.save();
  res.json({ user: user.toSafe() });
});

// DELETE /api/admin/users/:id
router.delete('/:id', async (req, res) => {
  await AdminUser.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
