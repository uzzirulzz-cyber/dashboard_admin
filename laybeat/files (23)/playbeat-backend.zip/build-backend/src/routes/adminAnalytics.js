// src/routes/adminAnalytics.js
// Rich analytics endpoint: revenue trends, top products, top customers,
// conversion funnel proxy, and day-of-week breakdown.
const express = require('express');
const adminAuth = require('../middleware/adminAuth');
const Order = require('../models/Order');
const Product = require('../models/Product');

const router = express.Router();
router.use(adminAuth);

// GET /api/admin/analytics?range=30  (days, default 30)
router.get('/', async (req, res) => {
  const range = Math.min(Number(req.query.range) || 30, 365);
  const since = new Date(Date.now() - range * 24 * 60 * 60 * 1000);

  const [
    revenueSeries,
    topProducts,
    topCustomers,
    gwBreakdown,
    statusBreakdown,
    dowBreakdown,
    totalRevAgg,
    totalOrdersInRange,
    avgOrderAgg,
  ] = await Promise.all([
    // Daily revenue for sparkline / area chart
    Order.aggregate([
      { $match: { createdAt: { $gte: since }, paymentStatus: 'paid' } },
      {
        $group: {
          _id: {
            y: { $year: '$createdAt' },
            m: { $month: '$createdAt' },
            d: { $dayOfMonth: '$createdAt' },
          },
          revenue: { $sum: '$total' },
          orders: { $sum: 1 },
        },
      },
      { $sort: { '_id.y': 1, '_id.m': 1, '_id.d': 1 } },
    ]),

    // Top selling products by order count (approximate: flatten items)
    Order.aggregate([
      { $match: { createdAt: { $gte: since } } },
      { $unwind: '$items' },
      {
        $group: {
          _id: '$items.productId',
          name: { $first: '$items.name' },
          emoji: { $first: '$items.emoji' },
          qty: { $sum: '$items.qty' },
          revenue: { $sum: { $multiply: ['$items.price', '$items.qty'] } },
        },
      },
      { $sort: { revenue: -1 } },
      { $limit: 10 },
    ]),

    // Top customers by spend
    Order.aggregate([
      { $match: { createdAt: { $gte: since }, paymentStatus: 'paid' } },
      {
        $group: {
          _id: { $toLower: '$customer.email' },
          name: { $first: '$customer.name' },
          email: { $first: '$customer.email' },
          orders: { $sum: 1 },
          spent: { $sum: '$total' },
        },
      },
      { $sort: { spent: -1 } },
      { $limit: 10 },
    ]),

    // Revenue by gateway
    Order.aggregate([
      { $match: { createdAt: { $gte: since }, paymentStatus: 'paid' } },
      { $group: { _id: '$paymentMethod', revenue: { $sum: '$total' }, count: { $sum: 1 } } },
      { $sort: { revenue: -1 } },
    ]),

    // Order status breakdown
    Order.aggregate([
      { $match: { createdAt: { $gte: since } } },
      { $group: { _id: '$status', count: { $sum: 1 } } },
    ]),

    // Orders by day of week (0=Sun…6=Sat)
    Order.aggregate([
      { $match: { createdAt: { $gte: since } } },
      {
        $group: {
          _id: { $dayOfWeek: '$createdAt' }, // 1=Sun 2=Mon … 7=Sat
          orders: { $sum: 1 },
          revenue: { $sum: '$total' },
        },
      },
      { $sort: { _id: 1 } },
    ]),

    // Total revenue in range
    Order.aggregate([
      { $match: { createdAt: { $gte: since }, paymentStatus: 'paid' } },
      { $group: { _id: null, total: { $sum: '$total' } } },
    ]),

    // Total orders in range
    Order.countDocuments({ createdAt: { $gte: since } }),

    // Avg order value
    Order.aggregate([
      { $match: { createdAt: { $gte: since }, paymentStatus: 'paid' } },
      { $group: { _id: null, avg: { $avg: '$total' } } },
    ]),
  ]);

  const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const dowFilled = Array.from({ length: 7 }, (_, i) => {
    const found = dowBreakdown.find((d) => d._id === i + 1);
    return { day: DOW[i], orders: found?.orders || 0, revenue: found?.revenue || 0 };
  });

  res.json({
    range,
    since,
    summary: {
      totalRevenue: totalRevAgg[0]?.total || 0,
      totalOrders: totalOrdersInRange,
      avgOrderValue: Math.round(avgOrderAgg[0]?.avg || 0),
    },
    revenueSeries,
    topProducts,
    topCustomers,
    gwBreakdown,
    statusBreakdown,
    dowBreakdown: dowFilled,
  });
});

module.exports = router;
