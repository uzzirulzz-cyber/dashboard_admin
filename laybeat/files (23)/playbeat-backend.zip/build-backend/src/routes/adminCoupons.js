// src/routes/adminCoupons.js
const express = require('express');
const adminAuth = require('../middleware/adminAuth');
const Coupon = require('../models/Coupon');

const router = express.Router();
router.use(adminAuth);

// GET /api/admin/coupons?active=&q=
router.get('/', async (req, res) => {
  const { active, q } = req.query;
  const filter = {};
  if (active === 'true') filter.active = true;
  if (active === 'false') filter.active = false;
  if (q) filter.code = { $regex: q, $options: 'i' };

  const coupons = await Coupon.find(filter).sort({ createdAt: -1 });
  res.json({ coupons, count: coupons.length });
});

// GET /api/admin/coupons/:id
router.get('/:id', async (req, res) => {
  const c = await Coupon.findById(req.params.id);
  if (!c) return res.status(404).json({ error: 'Coupon not found' });
  res.json({ coupon: c });
});

// POST /api/admin/coupons
router.post('/', async (req, res) => {
  try {
    const coupon = await Coupon.create(req.body);
    res.status(201).json({ coupon });
  } catch (err) {
    if (err.code === 11000) return res.status(409).json({ error: 'Coupon code already exists' });
    res.status(400).json({ error: err.message });
  }
});

// PATCH /api/admin/coupons/:id
router.patch('/:id', async (req, res) => {
  const coupon = await Coupon.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!coupon) return res.status(404).json({ error: 'Coupon not found' });
  res.json({ coupon });
});

// DELETE /api/admin/coupons/:id
router.delete('/:id', async (req, res) => {
  const c = await Coupon.findByIdAndDelete(req.params.id);
  if (!c) return res.status(404).json({ error: 'Coupon not found' });
  res.json({ ok: true });
});

// POST /api/admin/coupons/validate — also used by checkout
router.post('/validate', async (req, res) => {
  const { code, cartTotal } = req.body;
  const c = await Coupon.findOne({ code: code?.toUpperCase(), active: true });
  if (!c) return res.status(404).json({ error: 'Invalid or expired coupon code' });
  if (c.expiresAt && new Date() > c.expiresAt) return res.status(400).json({ error: 'Coupon has expired' });
  if (c.maxUses !== null && c.usedCount >= c.maxUses) return res.status(400).json({ error: 'Coupon usage limit reached' });
  if (cartTotal !== undefined && cartTotal < c.minOrder) {
    return res.status(400).json({ error: `Minimum order of PKR ${c.minOrder.toLocaleString()} required` });
  }

  const discount = c.type === 'percent'
    ? Math.round((cartTotal || 0) * (c.value / 100))
    : c.value;

  res.json({ coupon: c, discount });
});

module.exports = router;
