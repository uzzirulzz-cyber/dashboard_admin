// src/routes/adminGateways.js
const express = require('express');
const adminAuth = require('../middleware/adminAuth');
const PaymentSettings = require('../models/PaymentSettings');
const { getAdminPaymentMethods } = require('../config/payments');

const router = express.Router();
router.use(adminAuth);

// GET /api/admin/gateways -> { gateways: { stripe: {label, enabled, ...}, ... } }
router.get('/', async (req, res) => {
  const methods = getAdminPaymentMethods();
  const overrides = await PaymentSettings.find({});
  const overrideMap = overrides.reduce((acc, d) => {
    acc[d.gatewayId] = d.enabled;
    return acc;
  }, {});

  const gateways = {};
  methods.forEach((m) => {
    gateways[m.id] = {
      label: m.name,
      description: m.description,
      logo: m.logo,
      mode: m.mode,
      enabled: overrideMap[m.id] !== undefined ? overrideMap[m.id] : m.enabled,
      secretFields: m.secretFields,
    };
  });

  res.json({ gateways });
});

// PATCH /api/admin/gateways/:id -> { enabled }
router.patch('/:id', async (req, res) => {
  const { id } = req.params;
  const { enabled } = req.body;
  if (typeof enabled !== 'boolean') return res.status(400).json({ error: '"enabled" must be a boolean' });

  const allowed = ['stripe', 'jazzcash', 'alfalah', 'meezan'];
  if (!allowed.includes(id)) return res.status(404).json({ error: 'Unknown gateway' });

  const updated = await PaymentSettings.findOneAndUpdate(
    { gatewayId: id },
    { gatewayId: id, enabled, updatedBy: req.user?.email || 'admin' },
    { upsert: true, new: true }
  );

  res.json({ id: updated.gatewayId, enabled: updated.enabled });
});

module.exports = router;
