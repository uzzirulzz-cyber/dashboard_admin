// src/routes/adminHomepage.js
const express = require('express');
const adminAuth = require('../middleware/adminAuth');
const HomepageConfig = require('../models/HomepageConfig');

const router = express.Router();

const DEFAULT_CONFIG = {
  _key: 'singleton',
  ticker: {
    enabled: true,
    items: [
      '⚡ Instant digital delivery on all orders',
      '🛡️ 100% buyer protection guaranteed',
      '🎮 96 products across 6 categories',
      '🇵🇰 PKR pricing — no hidden conversion fees',
      '💬 24/7 support via WhatsApp',
    ],
  },
  heroBanners: [
    {
      id: 'games',
      title: 'Top Games — Lowest PKR Prices',
      subtitle: 'Steam, Epic, PlayStation & Xbox keys delivered instantly.',
      cta: 'Browse Games',
      href: '/games',
      badge: '🔥 Trending',
      gradient: 'linear-gradient(135deg,#0d1b2a,#1a3a5c)',
      emoji: '🎮',
      active: true,
      order: 0,
    },
    {
      id: 'ai-tools',
      title: 'AI Tools & Subscriptions',
      subtitle: 'ChatGPT Plus, Claude Pro, Midjourney and more — all in PKR.',
      cta: 'Explore AI Tools',
      href: '/ai-tools',
      badge: '🤖 New',
      gradient: 'linear-gradient(135deg,#0f0c29,#302b63)',
      emoji: '🤖',
      active: true,
      order: 1,
    },
    {
      id: 'gift-cards',
      title: 'Gift Cards for Every Platform',
      subtitle: 'Google Play, iTunes, Steam Wallet and more — instant codes.',
      cta: 'Shop Gift Cards',
      href: '/gift-cards',
      badge: '🎁 Popular',
      gradient: 'linear-gradient(135deg,#1a0533,#2d1b69)',
      emoji: '🎁',
      active: true,
      order: 2,
    },
  ],
  featuredCategories: ['games', 'ai-tools', 'gift-cards', 'software'],
  announcementBar: { enabled: false, text: '', color: '#d4af37' },
  seo: {
    title: 'PlayBeat — Gaming & Digital Store Pakistan',
    description: 'Buy games, gift cards, software and AI tools instantly in Pakistan. All prices in PKR.',
  },
};

// GET /api/admin/homepage  (also public: GET /api/homepage)
router.get('/', async (req, res) => {
  let config = await HomepageConfig.findOne({ _key: 'singleton' });
  if (!config) config = DEFAULT_CONFIG;
  res.json({ config });
});

// All write routes require admin auth
router.use(adminAuth);

// PUT /api/admin/homepage — full replace (upsert)
router.put('/', async (req, res) => {
  const config = await HomepageConfig.findOneAndUpdate(
    { _key: 'singleton' },
    { ...req.body, _key: 'singleton' },
    { upsert: true, new: true, runValidators: true }
  );
  res.json({ config });
});

// PATCH /api/admin/homepage — partial update
router.patch('/', async (req, res) => {
  const config = await HomepageConfig.findOneAndUpdate(
    { _key: 'singleton' },
    { $set: req.body },
    { upsert: true, new: true, runValidators: true }
  );
  res.json({ config });
});

// PATCH /api/admin/homepage/banner/:id
router.patch('/banner/:id', async (req, res) => {
  const config = await HomepageConfig.findOne({ _key: 'singleton' });
  const doc = config || await HomepageConfig.create(DEFAULT_CONFIG);
  const idx = doc.heroBanners.findIndex((b) => b.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Banner not found' });
  Object.assign(doc.heroBanners[idx], req.body);
  await doc.save();
  res.json({ config: doc });
});

// POST /api/admin/homepage/banner
router.post('/banner', async (req, res) => {
  let doc = await HomepageConfig.findOne({ _key: 'singleton' });
  if (!doc) doc = await HomepageConfig.create(DEFAULT_CONFIG);
  const id = req.body.id || `banner-${Date.now()}`;
  doc.heroBanners.push({ ...req.body, id, order: doc.heroBanners.length });
  await doc.save();
  res.status(201).json({ config: doc });
});

// DELETE /api/admin/homepage/banner/:id
router.delete('/banner/:id', async (req, res) => {
  const doc = await HomepageConfig.findOne({ _key: 'singleton' });
  if (!doc) return res.status(404).json({ error: 'Config not found' });
  doc.heroBanners = doc.heroBanners.filter((b) => b.id !== req.params.id);
  await doc.save();
  res.json({ config: doc });
});

module.exports = router;
