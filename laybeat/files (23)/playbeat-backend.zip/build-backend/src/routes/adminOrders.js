// src/routes/adminOrders.js
const express = require('express');
const adminAuth = require('../middleware/adminAuth');
const Order = require('../models/Order');
const { serializeOrder } = require('../utils/serializeOrder');

const router = express.Router();
router.use(adminAuth);

// GET /api/admin/orders?status=&q=&limit=
router.get('/', async (req, res) => {
  const { status, q, limit } = req.query;
  const filter = {};
  if (status) filter.status = status;
  if (q) {
    filter.$or = [
      { 'customer.email': { $regex: q, $options: 'i' } },
      { 'customer.name': { $regex: q, $options: 'i' } },
    ];
  }

  const query = Order.find(filter).sort({ createdAt: -1 });
  if (limit) query.limit(Number(limit));

  const orders = await query;
  const total = await Order.countDocuments(filter);

  res.json({ orders: orders.map(serializeOrder), total });
});

// PATCH /api/admin/orders/:id — update status / paymentStatus / notes / delivery key
router.patch('/:id', async (req, res) => {
  const { status, paymentStatus, notes, deliveryKey } = req.body;
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });

  if (status) order.status = status;
  if (paymentStatus) order.paymentStatus = paymentStatus;
  if (notes !== undefined) order.adminNotes = notes;
  if (deliveryKey !== undefined && order.items[0]) order.items[0].deliveryKey = deliveryKey;

  await order.save();
  res.json({ order: serializeOrder(order) });
});

// DELETE /api/admin/orders/:id — cancel
router.delete('/:id', async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  order.status = 'cancelled';
  await order.save();
  res.json({ ok: true });
});

module.exports = router;
