// src/routes/payments.js
const express = require('express');
const { getMethods, initiateCheckout } = require('../controllers/paymentsController');

const router = express.Router();

router.get('/methods', getMethods);
router.post('/checkout', initiateCheckout);

module.exports = router;
