// src/routes/adminProducts.js — admin product CRUD
const express = require('express');
const adminAuth = require('../middleware/adminAuth');
const Product = require('../models/Product');

const router = express.Router();
router.use(adminAuth);

// GET /api/admin/products?cat=&q=&limit=
router.get('/', async (req, res) => {
  const { cat, q, limit } = req.query;
  const filter = {};
  if (cat) filter.category = cat;
  if (q) filter.name = { $regex: q, $options: 'i' };

  const query = Product.find(filter).sort({ createdAt: -1 });
  if (limit) query.limit(Number(limit));

  const products = await query;
  res.json({ products, count: products.length, source: 'db' });
});

// POST /api/admin/products
router.post('/', async (req, res) => {
  try {
    const body = req.body;
    const id =
      body.id ||
      body.name
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');

    const product = await Product.create({ ...body, id });
    res.status(201).json({ product });
  } catch (err) {
    if (err.code === 11000) return res.status(409).json({ error: 'A product with this name/id already exists' });
    res.status(400).json({ error: err.message });
  }
});

// PATCH /api/admin/products/:id
router.patch('/:id', async (req, res) => {
  const product = await Product.findOneAndUpdate({ id: req.params.id }, req.body, { new: true });
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json({ product });
});

// DELETE /api/admin/products/:id
router.delete('/:id', async (req, res) => {
  const product = await Product.findOneAndDelete({ id: req.params.id });
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json({ ok: true });
});

module.exports = router;
