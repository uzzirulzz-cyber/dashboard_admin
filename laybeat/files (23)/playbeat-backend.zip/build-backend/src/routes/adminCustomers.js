// src/routes/adminCustomers.js
// Customer profiles aggregated from orders.
// No separate User model yet — customers are identified by email from orders.
const express = require('express');
const adminAuth = require('../middleware/adminAuth');
const Order = require('../models/Order');

const router = express.Router();
router.use(adminAuth);

// GET /api/admin/customers?q=&limit=
router.get('/', async (req, res) => {
  const { q, limit = '100' } = req.query;

  const match = {};
  if (q) {
    match.$or = [
      { 'customer.email': { $regex: q, $options: 'i' } },
      { 'customer.name': { $regex: q, $options: 'i' } },
    ];
  }

  const customers = await Order.aggregate([
    { $match: match },
    { $sort: { createdAt: -1 } },
    {
      $group: {
        _id: { $toLower: '$customer.email' },
        name: { $first: '$customer.name' },
        email: { $first: '$customer.email' },
        phone: { $first: '$customer.phone' },
        orderCount: { $sum: 1 },
        totalSpent: { $sum: '$total' },
        lastOrderAt: { $max: '$createdAt' },
        firstOrderAt: { $min: '$createdAt' },
        paymentMethods: { $addToSet: '$paymentMethod' },
        statuses: { $addToSet: '$status' },
      },
    },
    { $sort: { totalSpent: -1 } },
    { $limit: Number(limit) },
  ]);

  const total = await Order.distinct('customer.email').then((e) => e.filter(Boolean).length);

  res.json({ customers, total });
});

// GET /api/admin/customers/:email — profile + order history
router.get('/:email', async (req, res) => {
  const email = decodeURIComponent(req.params.email);
  const orders = await Order.find({ 'customer.email': { $regex: `^${email}$`, $options: 'i' } })
    .sort({ createdAt: -1 })
    .limit(50);

  if (!orders.length) return res.status(404).json({ error: 'Customer not found' });

  const { name, phone } = orders[0].customer;
  const totalSpent = orders.reduce((s, o) => s + o.total, 0);
  const paidSpent = orders.filter((o) => o.paymentStatus === 'paid').reduce((s, o) => s + o.total, 0);

  res.json({
    customer: { email, name, phone, orderCount: orders.length, totalSpent, paidSpent },
    orders: orders.map((o) => ({
      orderId: o._id,
      total: o.total,
      status: o.status,
      paymentStatus: o.paymentStatus,
      paymentMethod: o.paymentMethod,
      items: o.items.map((i) => ({ name: i.name, qty: i.qty, price: i.price })),
      createdAt: o.createdAt,
    })),
  });
});

module.exports = router;
