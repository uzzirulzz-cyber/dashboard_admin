// src/routes/adminPayments.js
const express = require('express');
const adminAuth = require('../middleware/adminAuth');
const { getSettings, updateSetting } = require('../controllers/adminPaymentsController');

const router = express.Router();

router.use(adminAuth);
router.get('/', getSettings);
router.patch('/:gatewayId', updateSetting);

module.exports = router;
