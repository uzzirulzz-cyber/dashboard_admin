// src/utils/serializeOrder.js
function serializeOrder(order) {
  const o = order.toObject ? order.toObject() : order;
  return {
    ...o,
    orderId: String(o._id),
    email: o.customer?.email || '',
    totalPKR: o.total,
  };
}

module.exports = { serializeOrder };
