// src/utils/paymentSettingsStore.js
const PaymentSettings = require('../models/PaymentSettings');
const { CATALOG } = require('../config/payments');

// Merge DB overrides (set via admin panel) on top of the .env defaults.
// If Mongo isn't connected yet, falls back to .env values only.
async function getMergedCatalog() {
  let overrides = {};
  try {
    const docs = await PaymentSettings.find({});
    overrides = docs.reduce((acc, d) => {
      acc[d.gatewayId] = d.enabled;
      return acc;
    }, {});
  } catch (err) {
    // DB not available — use env defaults
  }

  return CATALOG.map((g) => ({
    ...g,
    enabled: overrides[g.id] !== undefined ? overrides[g.id] : g.config.enabled,
  }));
}

module.exports = { getMergedCatalog };
