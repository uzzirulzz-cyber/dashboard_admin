const stripe = require('./stripe');
const alfalah = require('./alfalah');
const meezan = require('./meezan');
const jazzcash = require('./jazzcash');

// Public catalog shown to the frontend (checkout page + admin panel).
// IMPORTANT: only non-secret display info goes here. Keys/passwords/hashes
// never leave this module.
const CATALOG = [
  {
    id: 'stripe',
    name: 'Card (Stripe)',
    logo: '/payment-logos/stripe.svg',
    description: 'Visa, Mastercard via Stripe Checkout',
    config: stripe,
  },
  {
    id: 'jazzcash',
    name: 'JazzCash',
    logo: '/payment-logos/jazzcash.svg',
    description: `Mobile wallet — ${jazzcash.accountNumber} (${jazzcash.accountTitle})`,
    config: jazzcash,
  },
  {
    id: 'alfalah',
    name: 'Bank Alfalah',
    logo: '/payment-logos/alfalah.svg',
    description: `Account ${alfalah.accountNumber} — ${alfalah.accountTitle}`,
    config: alfalah,
  },
  {
    id: 'meezan',
    name: 'Meezan Bank',
    logo: '/payment-logos/meezan.svg',
    description: `IBAN ${meezan.iban} — ${meezan.accountTitle}`,
    config: meezan,
  },
];

// Returns ONLY what the storefront checkout page needs (logos + enabled flags).
function getPublicPaymentMethods() {
  return CATALOG.map((g) => ({
    id: g.id,
    name: g.name,
    logo: g.logo,
    enabled: !!g.config.enabled,
  }));
}

// Returns masked status for the admin panel — never raw secrets.
function getAdminPaymentMethods() {
  return CATALOG.map((g) => {
    const secretFields = Object.entries(g.config)
      .filter(([key, val]) => typeof val === 'string' && /key|secret|password|hash|mpin/i.test(key))
      .map(([key, val]) => ({
        field: key,
        configured: !!val,
        preview: val ? maskSecret(val) : null,
      }));

    return {
      id: g.id,
      name: g.name,
      description: g.description,
      logo: g.logo,
      enabled: !!g.config.enabled,
      mode: g.config.mode || null,
      secretFields,
    };
  });
}

function maskSecret(value) {
  if (value.length <= 8) return '••••••••';
  return `${value.slice(0, 4)}••••••••${value.slice(-4)}`;
}

module.exports = {
  stripe,
  alfalah,
  meezan,
  jazzcash,
  CATALOG,
  getPublicPaymentMethods,
  getAdminPaymentMethods,
};
