// Meezan Bank (MezPay) configuration — ported from the Laravel config you shared.
module.exports = {
  enabled: process.env.MEZPAY_ENABLED === 'true',
  username: process.env.MEZPAY_USERNAME || '',
  password: process.env.MEZPAY_PASSWORD || '',
  successCallback: process.env.MEZPAY_SUCCESS_CALLBACK || 'success',
  failedCallback: process.env.MEZPAY_FAILED_CALLBACK || 'failed',
  iban: process.env.MEZPAY_IBAN || 'PK86MEZN0015040115102971',
  accountTitle: process.env.MEZPAY_ACCOUNT_TITLE || 'PLAYBEAT DIGITAL PRIVATE LIMITED',
};
