// JazzCash configuration — ported from the Laravel config you shared.
module.exports = {
  enabled: process.env.JAZZCASH_ENABLED === 'true',
  mode: process.env.JAZZCASH_PAYMENTMODE || 'sandbox',
  apiUrl: process.env.JAZZCASH_PRODUCTION_URL || '',
  sandboxApiUrl:
    process.env.JAZZCASH_SANDBOX_URL ||
    'https://sandbox.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform',
  merchantId: process.env.JAZZCASH_MERCHANTID || '',
  password: process.env.JAZZCASH_PASSWORD || '',
  hashKey: process.env.JAZZCASH_HASHKEY || '',
  returnUrl: process.env.JAZZCASH_RETURNURL || '',
  mpin: process.env.JAZZCASH_MPIN || '',
  timezone: process.env.JAZZCASH_TIMEZONE || 'Asia/Karachi',
  accountNumber: process.env.JAZZCASH_ACCOUNT_NUMBER || '03318333368',
  accountTitle: process.env.JAZZCASH_ACCOUNT_TITLE || 'PLAYBEAT ARENA MERCHANT ACCOUNT',
};
