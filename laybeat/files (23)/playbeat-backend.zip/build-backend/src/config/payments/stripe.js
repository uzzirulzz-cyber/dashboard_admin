// Stripe configuration — server-side only, never exposed to the frontend.
module.exports = {
  enabled: process.env.STRIPE_ENABLED === 'true',
  mode: process.env.STRIPE_MODE || 'sandbox',
  accountId: process.env.STRIPE_ACCOUNT_ID || '',
  publishableKey: process.env.STRIPE_PUBLISHABLE_KEY || '',
  secretKey: process.env.STRIPE_SECRET_KEY || '',
  restrictedKey: process.env.STRIPE_RESTRICTED_KEY || '',
  webhookSecret: process.env.STRIPE_WEBHOOK_SECRET || '',
};
