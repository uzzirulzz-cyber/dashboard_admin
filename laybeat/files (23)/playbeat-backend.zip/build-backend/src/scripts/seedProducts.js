// src/scripts/seedProducts.js
// Run with: npm run seed
// Migrates the static catalog (productData.js, mirrored from the Next.js
// frontend's lib/products.js) into the MongoDB "products" collection.
// Safe to re-run — upserts by `id`.
require('dotenv').config();
const mongoose = require('mongoose');
const Product = require('../models/Product');
const { PRODUCTS } = require('./productData');

async function seed() {
  if (!process.env.MONGODB_URI) {
    console.error('❌ MONGODB_URI not set in .env');
    process.exit(1);
  }
  await mongoose.connect(process.env.MONGODB_URI);
  console.log('✅ Connected to MongoDB');

  let created = 0;
  let updated = 0;

  for (const p of PRODUCTS) {
    const res = await Product.findOneAndUpdate(
      { id: p.id },
      {
        $set: {
          name: p.name,
          category: p.category,
          brand: p.brand,
          emoji: p.emoji,
          price: p.price,
          oldPrice: p.oldPrice,
          badge: p.badge || '',
          delivery: 'Instant',
          active: true,
        },
        $setOnInsert: {
          stock: 50, // default starting stock — adjust per product in the admin panel
        },
      },
      { upsert: true, new: true, rawResult: true }
    );
    if (res.lastErrorObject?.upserted) created++;
    else updated++;
  }

  console.log(`✅ Seed complete — ${created} created, ${updated} updated`);
  await mongoose.disconnect();
}

seed().catch((err) => {
  console.error('❌ Seed failed:', err);
  process.exit(1);
});
