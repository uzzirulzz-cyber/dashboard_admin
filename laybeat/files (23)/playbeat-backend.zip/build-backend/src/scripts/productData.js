// lib/products.js
// Central data layer. Shape mirrors the future MongoDB "products" collection,
// so swapping these functions for fetch() calls to the Express API later
// (see lib/api.js) requires no changes in the page components.

const CATEGORIES = [
  {
    slug: 'games',
    label: 'Games',
    icon: '🎮',
    eyebrow: 'Steam · Epic · Xbox · PlayStation',
    title: '🎮 Games',
    description: 'All prices in PKR · Instant key delivery · 100% authentic',
    stats: ['⚡ Instant Delivery', '🛡️ Buyer Protected', '120+ Titles'],
  },
  {
    slug: 'gift-cards',
    label: 'Gift Cards',
    icon: '🎁',
    eyebrow: 'All Regions · All Platforms',
    title: '🎁 Gift Cards',
    description: 'All prices in PKR · Instant digital delivery · 100% authentic',
    stats: ['⚡ Instant Delivery', '🛡️ Buyer Protected', '7 Platforms'],
  },
  {
    slug: 'software',
    label: 'Software',
    icon: '💻',
    eyebrow: 'Microsoft · Adobe · Security',
    title: '💻 Software',
    description: 'Genuine licenses · Instant key delivery · Lifetime activation where noted',
    stats: ['⚡ Instant Delivery', '🛡️ Genuine Keys', '40+ Licenses'],
  },
  {
    slug: 'ai-tools',
    label: 'AI Tools',
    icon: '🤖',
    eyebrow: 'ChatGPT · Midjourney · Claude · Gemini',
    title: '🤖 AI Tools',
    description: 'All major AI subscriptions · Activated on your account · Instant setup',
    stats: ['⚡ Instant Setup', '🛡️ Buyer Protected', '12 AI Tools'],
  },
  {
    slug: 'game-items',
    label: 'Game Items',
    icon: '⚔️',
    eyebrow: 'Skins · Weapons · Bundles',
    title: '⚔️ Game Items',
    description: 'All prices in PKR · Account-bound delivery · 100% authentic items',
    stats: ['⚡ Fast Delivery', '🛡️ Buyer Protected', '60+ Items'],
  },
  {
    slug: 'accounts',
    label: 'Accounts',
    icon: '👤',
    eyebrow: 'High-Rank · OG Skins · Verified',
    title: '👤 Accounts',
    description: 'All prices in PKR · Full credential handover · 100% verified accounts',
    stats: ['⚡ Same-Day Handover', '🛡️ Verified Sellers', '30+ Accounts'],
  },
  {
    slug: 'subscriptions',
    label: 'Subscriptions',
    icon: '📺',
    eyebrow: 'Netflix · Spotify · Game Pass',
    title: '📺 Subscriptions',
    description: 'All prices in PKR · Activated on your account · Renewable monthly',
    stats: ['⚡ Instant Activation', '🛡️ Buyer Protected', '12 Services'],
  },
  {
    slug: 'top-up',
    label: 'Top Up',
    icon: '💎',
    eyebrow: 'UC · V-Bucks · Diamonds',
    title: '💎 Top Up',
    description: 'All prices in PKR · Direct to player ID · Instant top-up',
    stats: ['⚡ Instant Top-Up', '🛡️ Buyer Protected', '9 Games'],
  },
];

// Flat product list. `id` matches the slugified names used as data-id in the
// original static pages so links/cart entries stay stable.
const PRODUCTS = [
  // ---- Games ----
  { id: 'valorant-elderflame-bundle', name: 'Valorant Elderflame Bundle', category: 'games', brand: 'Riot · Valorant', emoji: '⚡', price: 7999, oldPrice: 11499, badge: '⚡ FLASH' },
  { id: 'gta-v-premium-edition', name: 'GTA V Premium Edition', category: 'games', brand: 'Rockstar · Steam', emoji: '🚗', price: 3499 },
  { id: 'ea-fc-25', name: 'EA FC 25', category: 'games', brand: 'EA Sports · Steam', emoji: '⚽', price: 6999, oldPrice: 8999, badge: 'SALE' },
  { id: 'red-dead-redemption-2', name: 'Red Dead Redemption 2', category: 'games', brand: 'Rockstar · Steam', emoji: '🤠', price: 2999 },
  { id: 'call-of-duty-mw3', name: 'Call of Duty: MW3', category: 'games', brand: 'Activision', emoji: '🔫', price: 8999 },
  { id: 'minecraft-java--bedrock', name: 'Minecraft Java + Bedrock', category: 'games', brand: 'Mojang', emoji: '⛏️', price: 2499 },
  { id: 'cyberpunk-2077-ultimate', name: 'Cyberpunk 2077 Ultimate', category: 'games', brand: 'CD Projekt · Steam', emoji: '🤖', price: 3999, oldPrice: 5999, badge: 'SALE' },
  { id: 'elden-ring', name: 'Elden Ring', category: 'games', brand: 'FromSoftware · Steam', emoji: '⚔️', price: 4999 },
  { id: 'pubg-battlegrounds', name: 'PUBG: Battlegrounds', category: 'games', brand: 'Krafton · Steam', emoji: '🪂', price: 1999 },
  { id: 'forza-horizon-5', name: 'Forza Horizon 5', category: 'games', brand: 'Xbox · PC', emoji: '🏎️', price: 4499 },
  { id: 'hogwarts-legacy', name: 'Hogwarts Legacy', category: 'games', brand: 'WB Games · Steam', emoji: '🧙', price: 4799 },
  { id: 'god-of-war-ragnarök', name: 'God of War Ragnarök', category: 'games', brand: 'PlayStation PC', emoji: '⚔️', price: 5499, badge: 'NEW' },

  // ---- Gift Cards ----
  { id: 'steam-wallet-500', name: 'Steam Wallet ₨500', category: 'gift-cards', brand: 'Steam', emoji: '🎯', price: 520 },
  { id: 'steam-wallet-1000', name: 'Steam Wallet ₨1000', category: 'gift-cards', brand: 'Steam', emoji: '🎯', price: 1050 },
  { id: 'steam-wallet-2000', name: 'Steam Wallet ₨2000', category: 'gift-cards', brand: 'Steam', emoji: '🎯', price: 2100 },
  { id: 'steam-wallet-5000', name: 'Steam Wallet ₨5000', category: 'gift-cards', brand: 'Steam', emoji: '🎯', price: 5200, oldPrice: 5499, badge: 'SALE' },
  { id: 'psn-1000', name: 'PSN ₨1000', category: 'gift-cards', brand: 'PlayStation', emoji: '🎮', price: 1050 },
  { id: 'psn-3000', name: 'PSN ₨3000', category: 'gift-cards', brand: 'PlayStation', emoji: '🎮', price: 3100 },
  { id: 'xbox-500', name: 'Xbox ₨500', category: 'gift-cards', brand: 'Xbox', emoji: '💚', price: 520 },
  { id: 'xbox-1000', name: 'Xbox ₨1000', category: 'gift-cards', brand: 'Xbox', emoji: '💚', price: 1050 },
  { id: 'google-play-500', name: 'Google Play ₨500', category: 'gift-cards', brand: 'Google', emoji: '▶', price: 520 },
  { id: 'itunes-1000', name: 'iTunes ₨1000', category: 'gift-cards', brand: 'Apple', emoji: '🍎', price: 1050 },
  { id: 'amazon-1000', name: 'Amazon ₨1000', category: 'gift-cards', brand: 'Amazon', emoji: '📦', price: 1100, badge: 'NEW' },
  { id: 'roblox-400-robux', name: 'Roblox 400 Robux', category: 'gift-cards', brand: 'Roblox', emoji: '🟥', price: 480 },

  // ---- Software ----
  { id: 'windows-11-pro---digital-key', name: 'Windows 11 Pro — Digital Key', category: 'software', brand: 'Microsoft', emoji: '🪟', price: 3999, oldPrice: 5999, badge: 'NEW LOW' },
  { id: 'ms-office-365-personal---1yr', name: 'MS Office 365 Personal — 1yr', category: 'software', brand: 'Microsoft', emoji: '📄', price: 2499, oldPrice: 4999, badge: 'SALE' },
  { id: 'ms-office-365-family---1yr', name: 'MS Office 365 Family — 1yr', category: 'software', brand: 'Microsoft', emoji: '👨‍👩‍👧', price: 4999 },
  { id: 'adobe-photoshop---1-month', name: 'Adobe Photoshop — 1 Month', category: 'software', brand: 'Adobe', emoji: '🎨', price: 3499 },
  { id: 'adobe-creative-cloud---1-month', name: 'Adobe Creative Cloud — 1 Month', category: 'software', brand: 'Adobe', emoji: '🌈', price: 6999 },
  { id: 'norton-360-deluxe---1yr', name: 'Norton 360 Deluxe — 1yr', category: 'software', brand: 'Norton', emoji: '🛡️', price: 2999 },
  { id: 'kaspersky-total-security---1yr', name: 'Kaspersky Total Security — 1yr', category: 'software', brand: 'Kaspersky', emoji: '🔒', price: 1999 },
  { id: 'windows-10-pro---digital-key', name: 'Windows 10 Pro — Digital Key', category: 'software', brand: 'Microsoft', emoji: '🪟', price: 2999 },
  { id: 'ms-project-2021', name: 'MS Project 2021', category: 'software', brand: 'Microsoft', emoji: '📊', price: 5499 },
  { id: 'ms-visio-2021', name: 'MS Visio 2021', category: 'software', brand: 'Microsoft', emoji: '🗺️', price: 5499 },
  { id: 'parallels-desktop---1yr-mac', name: 'Parallels Desktop — 1yr (Mac)', category: 'software', brand: 'Parallels', emoji: '💻', price: 7999 },
  { id: 'winrar-license', name: 'WinRAR License', category: 'software', brand: 'RARLAB', emoji: '🗜️', price: 1499, badge: 'NEW' },

  // ---- AI Tools ----
  { id: 'chatgpt-plus---1-month', name: 'ChatGPT Plus — 1 Month', category: 'ai-tools', brand: 'OpenAI', emoji: '💬', price: 5999, badge: 'AI HOT' },
  { id: 'midjourney-basic---1-month', name: 'Midjourney Basic — 1 Month', category: 'ai-tools', brand: 'Midjourney', emoji: '🖼️', price: 2999, badge: 'AI' },
  { id: 'claude-pro---1-month', name: 'Claude Pro — 1 Month', category: 'ai-tools', brand: 'Anthropic', emoji: '🧠', price: 5499, badge: 'NEW' },
  { id: 'gemini-advanced---1-month', name: 'Gemini Advanced — 1 Month', category: 'ai-tools', brand: 'Google', emoji: '✨', price: 4999 },
  { id: 'github-copilot---1-month', name: 'GitHub Copilot — 1 Month', category: 'ai-tools', brand: 'GitHub', emoji: '🧑\u200d💻', price: 1999 },
  { id: 'perplexity-pro---1-month', name: 'Perplexity Pro — 1 Month', category: 'ai-tools', brand: 'Perplexity', emoji: '🔎', price: 3999 },
  { id: 'notion-ai-add-on---1-month', name: 'Notion AI Add-on — 1 Month', category: 'ai-tools', brand: 'Notion', emoji: '📝', price: 1799 },
  { id: 'elevenlabs-creator---1-month', name: 'ElevenLabs Creator — 1 Month', category: 'ai-tools', brand: 'ElevenLabs', emoji: '🎙️', price: 2499 },
  { id: 'runway-ml-standard---1-month', name: 'Runway ML Standard — 1 Month', category: 'ai-tools', brand: 'Runway', emoji: '🎬', price: 3499 },
  { id: 'canva-pro---1-year', name: 'Canva Pro — 1 Year', category: 'ai-tools', brand: 'Canva', emoji: '🖌️', price: 2999, oldPrice: 4999, badge: 'SALE' },
  { id: 'midjourney-standard---1-month', name: 'Midjourney Standard — 1 Month', category: 'ai-tools', brand: 'Midjourney', emoji: '🖼️', price: 5499 },
  { id: 'chatgpt-plus---1-year', name: 'ChatGPT Plus — 1 Year', category: 'ai-tools', brand: 'OpenAI', emoji: '💬', price: 59999, oldPrice: 71988, badge: 'BEST VALUE' },

  // ---- Game Items ----
  { id: 'reaver-knife-skin', name: 'Reaver Knife Skin', category: 'game-items', brand: 'Valorant', emoji: '🔪', price: 6499 },
  { id: 'ak-47-redline-field-tested', name: 'AK-47 Redline (Field-Tested)', category: 'game-items', brand: 'CS2', emoji: '🔫', price: 3999 },
  { id: 'glacier-m416-skin', name: 'Glacier M416 Skin', category: 'game-items', brand: 'PUBG Mobile', emoji: '❄️', price: 2999 },
  { id: 'incubator-bundle', name: 'Incubator Bundle', category: 'game-items', brand: 'Free Fire', emoji: '🎁', price: 1999 },
  { id: 'epic-skin-bundle', name: 'Epic Skin Bundle', category: 'game-items', brand: 'Mobile Legends', emoji: '🛡️', price: 1499 },
  { id: 'arcana-bundle', name: 'Arcana Bundle', category: 'game-items', brand: 'Dota 2', emoji: '🪓', price: 3499 },
  { id: 'heirloom-shards', name: 'Heirloom Shards', category: 'game-items', brand: 'Apex Legends', emoji: '💎', price: 7999 },
  { id: 'welkin-moon-30-days', name: 'Welkin Moon (30 Days)', category: 'game-items', brand: 'Genshin Impact', emoji: '🌙', price: 499 },
  { id: 'champions-bundle-2025', name: 'Champions Bundle 2025', category: 'game-items', brand: 'Valorant', emoji: '🏆', price: 5999, badge: 'NEW' },
  { id: 'karambit--doppler', name: 'Karambit | Doppler', category: 'game-items', brand: 'CS2', emoji: '🗡️', price: 24999, badge: 'RARE' },
  { id: 'mythic-outfit-bundle', name: 'Mythic Outfit Bundle', category: 'game-items', brand: 'PUBG Mobile', emoji: '👘', price: 3499 },
  { id: 'renegade-raider-acct-item', name: 'Renegade Raider (Acct Item)', category: 'game-items', brand: 'Fortnite', emoji: '🪂', price: 8999, badge: 'RARE' },

  // ---- Accounts ----
  { id: 'conqueror-account---season-20', name: 'Conqueror Account — Season 20', category: 'accounts', brand: 'PUBG Mobile', emoji: '🏅', price: 14999, badge: 'RARE' },
  { id: 'immortal---full-skin-collection', name: 'Immortal — Full Skin Collection', category: 'accounts', brand: 'Valorant', emoji: '💎', price: 12999 },
  { id: 'og-account---rare-bundles', name: 'OG Account — Rare Bundles', category: 'accounts', brand: 'Free Fire', emoji: '🔥', price: 8999 },
  { id: '50-games-library-account', name: '50+ Games Library Account', category: 'accounts', brand: 'Steam', emoji: '🎮', price: 9999 },
  { id: 'mythic-glory-account', name: 'Mythic Glory Account', category: 'accounts', brand: 'Mobile Legends', emoji: '👑', price: 6999 },
  { id: 'max-town-hall-15-account', name: 'Max Town Hall 15 Account', category: 'accounts', brand: 'Clash of Clans', emoji: '🏰', price: 11999 },
  { id: 'og-skins-account', name: 'OG Skins Account', category: 'accounts', brand: 'Fortnite', emoji: '⭐', price: 7499, badge: 'RARE' },
  { id: 'ar58-whale-account', name: 'AR58 Whale Account', category: 'accounts', brand: 'Genshin Impact', emoji: '🐳', price: 19999 },
  { id: 'prime-account---rank-global', name: 'Prime Account — Rank: Global', category: 'accounts', brand: 'CS2', emoji: '🌍', price: 5999 },
  { id: 'verified-account---limiteds', name: 'Verified Account — Limiteds', category: 'accounts', brand: 'Roblox', emoji: '🟥', price: 4999 },
  { id: 'nitro-aged-account', name: 'Nitro Aged Account', category: 'accounts', brand: 'Discord', emoji: '🎮', price: 1999 },
  { id: 'gaming-page---10k-followers', name: 'Gaming Page — 10k Followers', category: 'accounts', brand: 'Instagram', emoji: '📱', price: 14999, badge: 'NEW' },

  // ---- Subscriptions ----
  { id: 'netflix-premium-4k---1-month', name: 'Netflix Premium 4K — 1 Month', category: 'subscriptions', brand: 'Netflix', emoji: '📺', price: 699, badge: 'HOT' },
  { id: 'spotify-premium---3-months', name: 'Spotify Premium — 3 Months', category: 'subscriptions', brand: 'Spotify', emoji: '🎵', price: 499, oldPrice: 597, badge: 'SAVE 16%' },
  { id: 'youtube-premium---1-month', name: 'YouTube Premium — 1 Month', category: 'subscriptions', brand: 'YouTube', emoji: '▶️', price: 399 },
  { id: 'disney---1-month', name: 'Disney+ — 1 Month', category: 'subscriptions', brand: 'Disney', emoji: '🏰', price: 599 },
  { id: 'xbox-game-pass-ultimate---1-month', name: 'Xbox Game Pass Ultimate — 1 Month', category: 'subscriptions', brand: 'Xbox', emoji: '🟩', price: 1999, badge: 'HOT' },
  { id: 'playstation-plus-essential---1-month', name: 'PlayStation Plus Essential — 1 Month', category: 'subscriptions', brand: 'PlayStation', emoji: '🎮', price: 999 },
  { id: 'apple-music---3-months', name: 'Apple Music — 3 Months', category: 'subscriptions', brand: 'Apple', emoji: '🎧', price: 599 },
  { id: 'amazon-prime-video---1-month', name: 'Amazon Prime Video — 1 Month', category: 'subscriptions', brand: 'Amazon', emoji: '📦', price: 449 },
  { id: 'tinder-gold---1-month', name: 'Tinder Gold — 1 Month', category: 'subscriptions', brand: 'Tinder', emoji: '💛', price: 1499 },
  { id: 'youtube-premium---1-year', name: 'YouTube Premium — 1 Year', category: 'subscriptions', brand: 'YouTube', emoji: '▶️', price: 3999, oldPrice: 4788, badge: 'SALE' },
  { id: 'crunchyroll-premium---1-month', name: 'Crunchyroll Premium — 1 Month', category: 'subscriptions', brand: 'Crunchyroll', emoji: '🍙', price: 549 },
  { id: 'hbo-max---1-month', name: 'HBO Max — 1 Month', category: 'subscriptions', brand: 'HBO', emoji: '🎬', price: 699, badge: 'NEW' },

  // ---- Top Up ----
  { id: 'pubg-mobile-uc---1800-uc', name: 'PUBG Mobile UC — 1800 UC', category: 'top-up', brand: 'PUBG Mobile', emoji: '🎯', price: 1799, badge: 'POPULAR' },
  { id: 'free-fire---1000-diamonds', name: 'Free Fire — 1000 Diamonds', category: 'top-up', brand: 'Free Fire', emoji: '🔥', price: 1499 },
  { id: 'valorant-points---475-vp', name: 'Valorant Points — 475 VP', category: 'top-up', brand: 'Valorant', emoji: '⚡', price: 699 },
  { id: 'mobile-legends---86-diamonds', name: 'Mobile Legends — 86 Diamonds', category: 'top-up', brand: 'Mobile Legends', emoji: '⚔️', price: 349 },
  { id: 'fortnite---1000-v-bucks', name: 'Fortnite — 1000 V-Bucks', category: 'top-up', brand: 'Fortnite', emoji: '🪂', price: 1899 },
  { id: 'genshin-impact---980-crystals', name: 'Genshin Impact — 980 Crystals', category: 'top-up', brand: 'Genshin Impact', emoji: '💎', price: 2799 },
  { id: 'call-of-duty-mobile---800-cp', name: 'Call of Duty Mobile — 800 CP', category: 'top-up', brand: 'COD Mobile', emoji: '🔫', price: 1299 },
  { id: 'league-of-legends---1380-rp', name: 'League of Legends — 1380 RP', category: 'top-up', brand: 'League of Legends', emoji: '🛡️', price: 1599 },
  { id: 'pubg-mobile-uc---660-uc', name: 'PUBG Mobile UC — 660 UC', category: 'top-up', brand: 'PUBG Mobile', emoji: '🎯', price: 699 },
  { id: 'honkai-star-rail---1090-shards', name: 'Honkai Star Rail — 1090 Shards', category: 'top-up', brand: 'Honkai Star Rail', emoji: '🌌', price: 2799 },
  { id: 'roblox---800-robux', name: 'Roblox — 800 Robux', category: 'top-up', brand: 'Roblox', emoji: '🟥', price: 960 },
  { id: 'free-fire---5000-diamonds', name: 'Free Fire — 5000 Diamonds', category: 'top-up', brand: 'Free Fire', emoji: '🔥', price: 6999, oldPrice: 7499, badge: 'SALE' },
];

function getCategory(slug) {
  return CATEGORIES.find((c) => c.slug === slug);
}

function getProductsByCategory(slug) {
  return PRODUCTS.filter((p) => p.category === slug);
}

function getProductById(id) {
  return PRODUCTS.find((p) => p.id === id);
}

// "Trending" — curated cross-category ranking (mirrors trending.html)
function getTrending() {
  const order = [
    'netflix-premium-4k---1-month',
    'chatgpt-plus---1-month',
    'pubg-mobile-uc---1800-uc',
    'ms-office-365-personal---1yr',
    'steam-wallet-5000',
    'valorant-points---475-vp',
    'spotify-premium---3-months',
    'midjourney-basic---1-month',
    'valorant-elderflame-bundle',
    'free-fire---1000-diamonds',
    'xbox-game-pass-ultimate---1-month',
    'conqueror-account---season-20',
    'windows-11-pro---digital-key',
    'ak-47-redline-field-tested',
    'roblox-400-robux',
    'mobile-legends---86-diamonds',
  ];
  return order.map((id) => getProductById(id)).filter(Boolean);
}

// "Best Value" — items with the biggest % discount
function getBestValue() {
  return PRODUCTS
    .filter((p) => p.oldPrice)
    .map((p) => ({ ...p, discount: Math.round(((p.oldPrice - p.price) / p.oldPrice) * 100) }))
    .sort((a, b) => b.discount - a.discount);
}

function formatPKR(amount) {
  return `PKR ${amount.toLocaleString('en-US')}`;
}

module.exports = { PRODUCTS, CATEGORIES };
