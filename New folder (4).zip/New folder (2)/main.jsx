import { useState, useEffect, useCallback } from "react";
import axios from "axios";  // use axios or fetch as you prefer

// (Keep your design tokens `T` and style `css` as is.)

// Remove static CATEGORIES and PRODUCTS arrays.

const API_BASE = "https://xtra11111111.onrender.com/api";

// Your helper states for cart, toast etc. can stay unchanged.

// ... Your sub-components Stars, Badge, ProductCard, Toasts stay unchanged.

// ─── Pages ────────────────────────────────────────────────────────────────────

function HomePage({ setPage, categories, products, loadingCategories, loadingProducts }) {
  if (loadingCategories || loadingProducts) return <div style={{padding:20}}>Loading...</div>;
  
  if (!categories.length) return <div style={{padding:20}}>No categories found</div>;

  return (
    <div className="page-fade">
      {/* Your existing markup for hero banner and other UI */}
      {/* Replace usages of CATEGORIES and PRODUCTS with categories/products props */}
      {/* Example: Category grid */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        {categories.slice(0, 6).map(c => (
          <button key={c.slug} onClick={() => setPage("category", c.slug)} 
            /* style and handlers same as before */
          >
            <span style={{ fontSize: 28 }}>{c.icon}</span>
            <span style={{ fontSize: 11, fontWeight: 700, color: T.text, letterSpacing: "0.03em" }}>{c.label}</span>
          </button>
        ))}
      </div>
      {/* Featured products */}
      <section className="section">
        <div className="wrap">
          <div className="grid-4">
            {products.slice(0, 8).map(p => <ProductCard key={p.id} product={p} onClick={(prod) => setPage("product", prod.slug, prod)} />)}
          </div>
        </div>
      </section>
      {/* ... rest unchanged ... */}
    </div>
  );
}

function CategoryPage({ category, setPage, categories, products }) {
  const cat = categories.find(c => c.slug === category) || { slug: category, label: category, icon: "📦" };
  const categoryProducts = products.filter(p => p.category === category);
  const allIfEmpty = categoryProducts.length === 0 ? products : categoryProducts;

  return (
    <div className="page-fade">
      {/* ... your existing markup */}
      <div className="grid-4">
        {allIfEmpty.map(p => <ProductCard key={p.id} product={p} onClick={(prod) => setPage("product", prod.slug, prod)} />)}
      </div>
    </div>
  );
}

function ProductPage({ product, setPage }) {
  // your existing markup
}

// Similarly update TrendingPage to accept products prop and sort/filter appropriately.

// ─── App Root ─────────────────────────────────────────────────────────────────

export default function App() {
  const [page, setPageState] = useState({ name: "home", slug: null, data: null });
  const [searchQuery, setSearchQuery] = useState("");
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [loadingCategories, setLoadingCategories] = useState(true);
  const [loadingProducts, setLoadingProducts] = useState(true);

  const setPage = useCallback((name, slug = null, data = null) => {
    setPageState({ name, slug, data });
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    // Fetch categories
    setLoadingCategories(true);
    axios.get(`${API_BASE}/categories`).then(res => {
      setCategories(res.data.categories || []);
    }).catch(() => setCategories([]))
    .finally(() => setLoadingCategories(false));
  }, []);

  useEffect(() => {
    // Fetch products (optionally add filtering by category or search here)
    setLoadingProducts(true);
    let url = `${API_BASE}/products`;
    // Example: filter on searchQuery
    if (searchQuery) url += `?search=${encodeURIComponent(searchQuery)}`;

    axios.get(url).then(res => {
      setProducts(res.data.products || []);
    }).catch(() => setProducts([]))
    .finally(() => setLoadingProducts(false));
  }, [searchQuery]);

  const renderPage = () => {
    switch(page.name){
      case "home": return <HomePage setPage={setPage} categories={categories} products={products} loadingCategories={loadingCategories} loadingProducts={loadingProducts} searchQuery={searchQuery} />;
      case "category": return <CategoryPage category={page.slug} setPage={setPage} categories={categories} products={products} />;
      case "product": return <ProductPage product={page.data || products.find(p => p.slug === page.slug)} setPage={setPage} />;
      case "trending": return <TrendingPage setPage={setPage} products={products} />;
      case "cart": return <CartPage setPage={setPage} />;
      case "checkout": return <CheckoutPage setPage={setPage} />;
      case "order-success": return <OrderSuccessPage setPage={setPage} />;
      case "login": return <AuthPage mode="login" setPage={setPage} />;
      case "register": return <AuthPage mode="register" setPage={setPage} />;
      case "account": return <OrderSuccessPage setPage={setPage} />;
      default: return <HomePage setPage={setPage} categories={categories} products={products} loadingCategories={loadingCategories} loadingProducts={loadingProducts} searchQuery={searchQuery} />;
    }
  };

  return (
    <>
      <style>{css}</style>
      <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
        <Header currentPage={page.name} setPage={setPage} searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
        <main style={{ flex: 1 }}>
          {renderPage()}
        </main>
        <Footer setPage={setPage} />
      </div>
      <Toasts />
    </>
  );
}
