import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// ─── API base ─────────────────────────────────────────────────────────────────
export const API_BASE = import.meta.env.VITE_API_URL || 'https://playbeat-api.onrender.com/api';

// Generic fetch wrapper
export async function apiFetch(path, opts = {}) {
  // Lazy import to avoid circular dependency
  const { useAuthStore } = await import('../store');
  const token = useAuthStore.getState().token;
  const res = await fetch(`${API_BASE}${path}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...opts.headers,
    },
    ...opts,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: res.statusText }));
    throw new Error(err.message || `HTTP ${res.status}`);
  }
  return res.json();
}

// ─── UI STORE ─────────────────────────────────────────────────────────────────
export const useUIStore = create(persist(
  (set) => ({
    sidebarOpen: true,
    toggleSidebar: () => set(s => ({ sidebarOpen: !s.sidebarOpen })),
    unreadCount: 3,
    setUnreadCount: (n) => set({ unreadCount: n }),
  }),
  { name: 'pb-ui', partialize: s => ({ sidebarOpen: s.sidebarOpen }) }
));

// ─── SOCKET STORE ─────────────────────────────────────────────────────────────
export const useSocketStore = create((set) => ({
  connected: false,
  setConnected: (v) => set({ connected: v }),
}));

// ─── PRODUCTS STORE ───────────────────────────────────────────────────────────
export const useProductsStore = create((set, get) => ({
  products: [],
  total: 0,
  page: 1,
  limit: 20,
  loading: false,
  error: null,
  filters: { search: '', category: '', status: '', sort: '-createdAt' },

  setFilters: (filters) => set(s => ({ filters: { ...s.filters, ...filters }, page: 1 })),
  setPage: (page) => set({ page }),

  fetchProducts: async () => {
    const { page, limit, filters } = get();
    set({ loading: true, error: null });
    try {
      const params = new URLSearchParams({
        page, limit, sort: filters.sort,
        ...(filters.search   ? { search:   filters.search }   : {}),
        ...(filters.category ? { category: filters.category } : {}),
        ...(filters.status   ? { status:   filters.status }   : {}),
      });
      const data = await apiFetch(`/products?${params}`);
      set({ products: data.products ?? data.data ?? data, total: data.total ?? 0, loading: false });
    } catch (e) {
      set({ error: e.message, loading: false });
    }
  },

  createProduct: async (body) => {
    const data = await apiFetch('/products', { method: 'POST', body: JSON.stringify(body) });
    await get().fetchProducts();
    return data;
  },

  updateProduct: async (id, body) => {
    const data = await apiFetch(`/products/${id}`, { method: 'PUT', body: JSON.stringify(body) });
    set(s => ({ products: s.products.map(p => p._id === id ? { ...p, ...data } : p) }));
    return data;
  },

  deleteProduct: async (id) => {
    await apiFetch(`/products/${id}`, { method: 'DELETE' });
    set(s => ({ products: s.products.filter(p => p._id !== id), total: s.total - 1 }));
  },
}));

// ─── ORDERS STORE ─────────────────────────────────────────────────────────────
export const useOrdersStore = create((set, get) => ({
  orders: [],
  total: 0,
  page: 1,
  limit: 20,
  loading: false,
  error: null,
  filters: { search: '', status: '', sort: '-createdAt' },

  setFilters: (f) => set(s => ({ filters: { ...s.filters, ...f }, page: 1 })),
  setPage: (page) => set({ page }),

  fetchOrders: async () => {
    const { page, limit, filters } = get();
    set({ loading: true, error: null });
    try {
      const params = new URLSearchParams({ page, limit, sort: filters.sort,
        ...(filters.search ? { search: filters.search } : {}),
        ...(filters.status ? { status: filters.status } : {}),
      });
      const data = await apiFetch(`/orders?${params}`);
      set({ orders: data.orders ?? data.data ?? data, total: data.total ?? 0, loading: false });
    } catch (e) {
      set({ error: e.message, loading: false });
    }
  },

  updateOrderStatus: async (id, status) => {
    const data = await apiFetch(`/orders/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
    set(s => ({ orders: s.orders.map(o => o._id === id ? { ...o, status } : o) }));
    return data;
  },
}));

// ─── CUSTOMERS STORE ──────────────────────────────────────────────────────────
export const useCustomersStore = create((set, get) => ({
  customers: [],
  total: 0,
  page: 1,
  limit: 20,
  loading: false,
  error: null,
  filters: { search: '', sort: '-createdAt' },

  setFilters: (f) => set(s => ({ filters: { ...s.filters, ...f }, page: 1 })),
  setPage: (page) => set({ page }),

  fetchCustomers: async () => {
    const { page, limit, filters } = get();
    set({ loading: true, error: null });
    try {
      const params = new URLSearchParams({ page, limit, sort: filters.sort,
        ...(filters.search ? { search: filters.search } : {}),
      });
      const data = await apiFetch(`/users?${params}`);
      set({ customers: data.users ?? data.data ?? data, total: data.total ?? 0, loading: false });
    } catch (e) {
      set({ error: e.message, loading: false });
    }
  },
}));

// ─── INVENTORY STORE ──────────────────────────────────────────────────────────
export const useInventoryStore = create((set, get) => ({
  items: [],
  total: 0,
  loading: false,
  error: null,
  filters: { search: '', status: '' },

  setFilters: (f) => set(s => ({ filters: { ...s.filters, ...f } })),

  fetchInventory: async () => {
    const { filters } = get();
    set({ loading: true, error: null });
    try {
      const params = new URLSearchParams({
        ...(filters.search ? { search: filters.search } : {}),
        ...(filters.status ? { status: filters.status } : {}),
      });
      const data = await apiFetch(`/inventory?${params}`);
      set({ items: data.items ?? data.data ?? data, total: data.total ?? 0, loading: false });
    } catch (e) {
      set({ error: e.message, loading: false });
    }
  },

  addStock: async (productId, qty) => {
    const data = await apiFetch(`/inventory/${productId}/add`, { method: 'POST', body: JSON.stringify({ qty }) });
    await get().fetchInventory();
    return data;
  },
}));

// ─── ANALYTICS STORE ──────────────────────────────────────────────────────────
export const useAnalyticsStore = create((set) => ({
  overview: null,
  revenue: [],
  topProducts: [],
  loading: false,
  error: null,
  range: '30d',

  setRange: (range) => set({ range }),

  fetchAnalytics: async () => {
    set({ loading: true, error: null });
    try {
      const [overview, revenue, topProducts] = await Promise.all([
        apiFetch('/analytics/overview'),
        apiFetch('/analytics/revenue'),
        apiFetch('/analytics/top-products'),
      ]);
      set({ overview, revenue: revenue.data ?? revenue, topProducts: topProducts.data ?? topProducts, loading: false });
    } catch (e) {
      set({ error: e.message, loading: false });
    }
  },
}));

// ─── CATEGORIES STORE ─────────────────────────────────────────────────────────
export const useCategoriesStore = create((set, get) => ({
  categories: [],
  loading: false,
  error: null,

  fetchCategories: async () => {
    set({ loading: true, error: null });
    try {
      const data = await apiFetch('/categories');
      set({ categories: data.categories ?? data.data ?? data, loading: false });
    } catch (e) {
      set({ error: e.message, loading: false });
    }
  },

  createCategory: async (body) => {
    const data = await apiFetch('/categories', { method: 'POST', body: JSON.stringify(body) });
    await get().fetchCategories();
    return data;
  },

  updateCategory: async (id, body) => {
    const data = await apiFetch(`/categories/${id}`, { method: 'PUT', body: JSON.stringify(body) });
    set(s => ({ categories: s.categories.map(c => c._id === id ? { ...c, ...data } : c) }));
    return data;
  },

  deleteCategory: async (id) => {
    await apiFetch(`/categories/${id}`, { method: 'DELETE' });
    set(s => ({ categories: s.categories.filter(c => c._id !== id) }));
  },
}));

// ─── MEDIA STORE ──────────────────────────────────────────────────────────────
export const useMediaStore = create((set) => ({
  files: [],
  total: 0,
  loading: false,
  error: null,
  uploading: false,

  fetchMedia: async () => {
    set({ loading: true, error: null });
    try {
      const data = await apiFetch('/media');
      set({ files: data.files ?? data.data ?? data, total: data.total ?? 0, loading: false });
    } catch (e) {
      set({ error: e.message, loading: false });
    }
  },

  uploadFile: async (file) => {
    set({ uploading: true });
    try {
      const { useAuthStore } = await import('../store');
      const token = useAuthStore.getState().token;
      const form = new FormData();
      form.append('file', file);
      const res = await fetch(`${API_BASE}/media/upload`, {
        method: 'POST',
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: form,
      });
      if (!res.ok) throw new Error('Upload failed');
      const data = await res.json();
      set(s => ({ files: [data, ...s.files], uploading: false }));
      return data;
    } catch (e) {
      set({ uploading: false });
      throw e;
    }
  },

  deleteFile: async (id) => {
    await apiFetch(`/media/${id}`, { method: 'DELETE' });
    set(s => ({ files: s.files.filter(f => f._id !== id) }));
  },
}));

// ─── HOMEPAGE STORE ───────────────────────────────────────────────────────────
export const useHomepageStore = create((set) => ({
  config: null,
  loading: false,
  error: null,
  saving: false,

  fetchConfig: async () => {
    set({ loading: true, error: null });
    try {
      const data = await apiFetch('/homepage');
      set({ config: data, loading: false });
    } catch (e) {
      set({ error: e.message, loading: false });
    }
  },

  saveConfig: async (config) => {
    set({ saving: true });
    try {
      const data = await apiFetch('/homepage', { method: 'PUT', body: JSON.stringify(config) });
      set({ config: data, saving: false });
      return data;
    } catch (e) {
      set({ saving: false });
      throw e;
    }
  },
}));

// ─── SETTINGS STORE ───────────────────────────────────────────────────────────
export const useSettingsStore = create((set) => ({
  settings: null,
  loading: false,
  saving: false,
  error: null,

  fetchSettings: async () => {
    set({ loading: true, error: null });
    try {
      const data = await apiFetch('/settings');
      set({ settings: data, loading: false });
    } catch (e) {
      set({ error: e.message, loading: false });
    }
  },

  saveSettings: async (settings) => {
    set({ saving: true });
    try {
      const data = await apiFetch('/settings', { method: 'PUT', body: JSON.stringify(settings) });
      set({ settings: data, saving: false });
      return data;
    } catch (e) {
      set({ saving: false });
      throw e;
    }
  },
}));
