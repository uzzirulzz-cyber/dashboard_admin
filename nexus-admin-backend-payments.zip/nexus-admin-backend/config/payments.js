// ─── config/payments.js ──────────────────────────────────────────────────────
// Central, NON-SECRET payment configuration.
//
// SECURITY: nothing in here may contain a real secret/restricted key. All
// credentials are read from process.env inside each provider. The objects below
// are safe to expose to the admin UI; the `public` metadata is the ONLY thing
// ever sent to the storefront (logos + labels — never keys, merchant IDs, or
// account numbers).

// Region → default currency. Pakistan defaults to PKR (the project default).
const REGION_CURRENCY = {
  PK: 'PKR',
  US: 'USD',
  GB: 'GBP',
  AE: 'AED',
  IN: 'INR',
};
const DEFAULT_REGION   = process.env.DEFAULT_REGION   || 'PK';
const DEFAULT_CURRENCY = process.env.DEFAULT_CURRENCY || 'PKR';

// Which methods are offered per region. Pakistan gets the local rails + cards.
const REGION_METHODS = {
  PK: ['jazzcash', 'alfalah', 'meezan', 'stripe'],
  // Everywhere else: cards via Stripe only (extend as you expand).
  default: ['stripe'],
};

// Public, client-safe metadata. `logo` is a path the storefront renders — the
// customer sees ONLY these. No secrets, no merchant identifiers.
const PROVIDERS = {
  stripe:   { id: 'stripe',   label: 'Card',          logo: '/pay/stripe.svg',   kind: 'card'   },
  jazzcash: { id: 'jazzcash', label: 'JazzCash',      logo: '/pay/jazzcash.svg', kind: 'wallet' },
  alfalah:  { id: 'alfalah',  label: 'Bank Alfalah',  logo: '/pay/alfalah.svg',  kind: 'bank'   },
  meezan:   { id: 'meezan',   label: 'Meezan Bank',   logo: '/pay/meezan.svg',   kind: 'bank'   },
};

// Master on/off switch per provider, controlled by env so the admin can disable
// a rail without a deploy. e.g. PAYMENTS_ENABLED="stripe,jazzcash,alfalah,meezan"
const ENABLED = (process.env.PAYMENTS_ENABLED || 'stripe,jazzcash,alfalah,meezan')
  .split(',').map(s => s.trim()).filter(Boolean);

// Mode is a SINGLE env flag — never a code change. Keep a sandbox path.
const MODE = (process.env.PAYMENTS_MODE || 'sandbox').toLowerCase(); // 'sandbox' | 'live'

function currencyForRegion(region) {
  return REGION_CURRENCY[(region || '').toUpperCase()] || DEFAULT_CURRENCY;
}

function methodsForRegion(region) {
  const list = REGION_METHODS[(region || '').toUpperCase()] || REGION_METHODS.default;
  return list.filter(id => ENABLED.includes(id));
}

module.exports = {
  MODE,
  ENABLED,
  PROVIDERS,
  DEFAULT_REGION,
  DEFAULT_CURRENCY,
  REGION_CURRENCY,
  currencyForRegion,
  methodsForRegion,
};
