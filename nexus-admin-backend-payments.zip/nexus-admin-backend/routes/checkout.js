// ─── routes/checkout.js ──────────────────────────────────────────────────────
// Auth-gated, payment-FIRST checkout.
//
//   • No guest checkout — every session-creating route requires a logged-in user.
//   • Prices are recomputed server-side from the DB; client prices are ignored.
//   • An order is created as pending/unpaid, the customer pays on the gateway,
//     and the order is confirmed ONLY when the server verifies the payment via
//     a signed webhook (Stripe) or a verified callback (local rails).
//
// Mount in server.js as:  app.use('/api/checkout', require('./routes/checkout'))
// The Stripe webhook needs the RAW body, so it is mounted separately in
// server.js BEFORE express.json() — see routes/checkout.js → stripeWebhook.

const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Product = require('../models/Product');
const { protect } = require('../middleware/auth');
const payments = require('../services/payments');
const cfg = require('../config/payments');

const FRONTEND = process.env.FRONTEND_URL || 'http://localhost:3000';

// ─── PUBLIC: which methods to show (logos only, no secrets) ───────────────────
router.get('/methods', (req, res) => {
  const region = req.query.region || cfg.DEFAULT_REGION;
  res.json({
    success: true,
    region,
    currency: cfg.currencyForRegion(region),
    methods: payments.publicMethods(region), // [{ id, label, logo, kind }]
  });
});

// ─── AUTH REQUIRED for everything below (blocks guest checkout) ───────────────
router.use(protect);

// ─── POST /api/checkout/session ──────────────────────────────────────────────
// body: { method, region, items:[{ productId, quantity }], shipping?, address? }
router.post('/session', async (req, res) => {
  try {
    const { method, items, shipping = 0, address } = req.body;
    const region = req.body.region || req.user.region || cfg.DEFAULT_REGION;
    const currency = cfg.currencyForRegion(region);

    if (!cfg.methodsForRegion(region).includes(method)) {
      return res.status(400).json({ success: false, message: 'Payment method not available in your region' });
    }
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ success: false, message: 'Cart is empty' });
    }

    // Recompute everything from the DB — never trust client-supplied prices.
    const ids = items.map(i => i.productId);
    const products = await Product.find({ _id: { $in: ids }, status: 'active' });
    const map = new Map(products.map(p => [String(p._id), p]));
    const lineItems = [];
    for (const i of items) {
      const p = map.get(String(i.productId));
      if (!p) return res.status(400).json({ success: false, message: `Product unavailable: ${i.productId}` });
      const qty = Math.max(1, Number(i.quantity) || 1);
      const price = p.salePrice && p.salePrice < p.price ? p.salePrice : p.price;
      lineItems.push({ product: p._id, name: p.name, sku: p.sku, price, quantity: qty, subtotal: price * qty });
    }
    const subtotal = lineItems.reduce((s, i) => s + i.subtotal, 0);
    const total = subtotal + Number(shipping || 0);

    // Create the order in a NOT-paid, NOT-confirmed state.
    const order = await Order.create({
      customer: req.user._id,
      customerName: req.user.name,
      customerEmail: req.user.email,
      items: lineItems,
      subtotal,
      shipping: Number(shipping || 0),
      total,
      currency,
      region,
      status: 'pending',
      paymentStatus: 'unpaid',
      paymentMethod: method,
      shippingAddress: address || {},
    });

    const returnUrl = `${FRONTEND}/order/${order._id}?from=gateway`;
    const cancelUrl = `${FRONTEND}/checkout?canceled=1&order=${order._id}`;

    const provider = payments.getProvider(method);
    const session = await provider.createSession({
      order, currency, returnUrl, cancelUrl,
      customer: { email: req.user.email, name: req.user.name },
    });

    // Persist the provider reference so callbacks can find this order.
    order.paymentProvider = method;
    order.paymentRef = session.providerRef;
    await order.save();

    res.json({ success: true, orderId: order._id, orderNumber: order.orderNumber, payment: session });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── GET /api/checkout/order/:id — poll confirmation status (own orders only) ─
router.get('/order/:id', async (req, res) => {
  try {
    const order = await Order.findById(req.params.id).select('orderNumber status paymentStatus total currency customer');
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });
    if (String(order.customer) !== String(req.user._id)) {
      return res.status(403).json({ success: false, message: 'Not your order' });
    }
    res.json({ success: true, status: order.status, paymentStatus: order.paymentStatus, orderNumber: order.orderNumber });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Shared: confirm an order as paid (idempotent) ───────────────────────────
async function confirmPaid({ orderId, providerRef, provider, raw }, app) {
  let order = null;
  if (orderId) order = await Order.findById(orderId).catch(() => null);
  if (!order && providerRef) order = await Order.findOne({ paymentRef: providerRef });
  if (!order) return { ok: false, reason: 'order_not_found' };
  if (order.paymentStatus === 'paid') return { ok: true, already: true }; // idempotent

  order.paymentStatus = 'paid';
  order.status = 'processing';              // "confirmed" — only reached after payment
  order.paidAt = new Date();
  order.paymentProvider = provider;
  order.paymentMeta = raw;
  order.statusHistory.push({ status: 'processing', note: `Payment confirmed via ${provider}` });
  await order.save();

  // Decrement stock now that money is in (optional; guard against negatives).
  for (const it of order.items) {
    if (it.product) await Product.updateOne({ _id: it.product }, { $inc: { stock: -it.quantity, salesCount: it.quantity } });
  }

  app?.get('io')?.emit('order:paid', { orderId: order._id, orderNumber: order.orderNumber });
  return { ok: true, orderId: order._id };
}

// ─── Local-rail callbacks (parsed body is fine here) ─────────────────────────
async function handleCallback(providerId, req, res) {
  try {
    const provider = payments.getProvider(providerId);
    const result = await provider.resolvePaid(req);
    if (!result.paid) {
      // Mark failed (don't confirm). Redirect back to checkout.
      if (result.orderId || result.providerRef) {
        const o = result.orderId
          ? await Order.findById(result.orderId).catch(() => null)
          : await Order.findOne({ paymentRef: result.providerRef });
        if (o && o.paymentStatus !== 'paid') { o.paymentStatus = 'failed'; await o.save(); }
      }
      return res.redirect(`${FRONTEND}/checkout?failed=1`);
    }
    const conf = await confirmPaid(
      { orderId: result.orderId, providerRef: result.providerRef, provider: providerId, raw: result.raw },
      req.app
    );
    return res.redirect(`${FRONTEND}/order/${conf.orderId || ''}?paid=1`);
  } catch (err) {
    return res.redirect(`${FRONTEND}/checkout?error=1`);
  }
}

router.post('/callback/jazzcash', (req, res) => handleCallback('jazzcash', req, res));
router.post('/callback/alfalah',  (req, res) => handleCallback('alfalah',  req, res));
router.post('/callback/meezan',   (req, res) => handleCallback('meezan',   req, res));
// Banks also redirect the browser back via GET in some flows:
router.get('/callback/jazzcash',  (req, res) => handleCallback('jazzcash', req, res));
router.get('/callback/alfalah',   (req, res) => handleCallback('alfalah',  req, res));
router.get('/callback/meezan',    (req, res) => handleCallback('meezan',   req, res));

module.exports = router;

// ─── Stripe webhook — mounted in server.js with express.raw BEFORE json ──────
// Exported so server.js can attach it to a raw-body route.
module.exports.stripeWebhook = async function stripeWebhook(req, res) {
  try {
    const provider = payments.getProvider('stripe');
    const result = await provider.resolvePaid(req); // verifies signature; throws if bad
    if (result.ignored) return res.json({ received: true });
    if (result.paid) {
      await confirmPaid(
        { orderId: result.orderId, providerRef: result.providerRef, provider: 'stripe', raw: { id: result.providerRef } },
        req.app
      );
    }
    res.json({ received: true });
  } catch (err) {
    // Bad signature or processing error → 400 so Stripe retries.
    res.status(400).json({ success: false, message: err.message });
  }
};
