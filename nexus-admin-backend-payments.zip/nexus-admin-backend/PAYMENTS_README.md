# Payments — checkout & order confirmation

Auth-gated, payment-first checkout for the NexusAdmin backend. **An order is
confirmed only after the gateway confirms payment to the server.**

## Flow

1. `GET /api/checkout/methods?region=PK` → logos-only list (id/label/logo). The
   browser never receives keys, merchant IDs, or account numbers.
2. `POST /api/checkout/session` (**login required** — guests get 401):
   - prices are recomputed from the DB (client prices ignored),
   - an `Order` is created as `status: pending`, `paymentStatus: unpaid`,
   - the chosen gateway returns either a `redirect` URL (Stripe) or a `form`
     POST (JazzCash/Alfalah/Meezan) that the storefront auto-submits.
3. Customer pays on the provider's hosted page.
4. The **server** confirms payment:
   - Stripe → `POST /api/checkout/webhook/stripe` (signed; raw body),
   - local rails → `POST/GET /api/checkout/callback/{jazzcash|alfalah|meezan}`.
   Only on a verified "paid" result does the order flip to
   `paymentStatus: paid`, `status: processing` (idempotent), stock decremented,
   and a `order:paid` socket event emitted.

A canceled/failed payment leaves the order `unpaid`/`failed` and never confirms.

## Setup

1. `npm install` (adds `stripe`).
2. Copy `.env.payments.example` into your `.env` and fill the **rotated**
   credentials. Never commit real values.
3. Create a Stripe webhook → endpoint `…/api/checkout/webhook/stripe`,
   event `checkout.session.completed`; put the signing secret in
   `STRIPE_WEBHOOK_SECRET`.
4. Frontend: drop `checkout-ui/CheckoutPayment.jsx` into the storefront, add
   logos at `public/pay/*.svg`, and set `VITE_STRIPE_PUBLISHABLE_KEY` (pk_…) if
   you later use Stripe.js. The publishable key is the only payment key allowed
   in the browser.

`PAYMENTS_MODE=sandbox|live` and `PAYMENTS_ENABLED=…` are single env switches —
no code change to go live, and keep a sandbox path.

## Verification status (important)

| Provider | State |
|---|---|
| **Stripe** | Production-ready (Checkout Sessions + signed webhook). Confirm your Stripe account supports your settlement currency — many PK businesses cannot settle **PKR** on Stripe. |
| **JazzCash** | Implemented (Page-Redirect, HMAC-SHA256). **Test in JazzCash sandbox** and confirm the field set matches your integration guide (v1.1 vs v2.0). |
| **Bank Alfalah** | Scaffold only — refuses to run until `ALFALAH_VERIFIED=true`. The AES handshake field order must be confirmed against your merchant's HS-API doc. |
| **Meezan** | Scaffold only — refuses to run until `MEEZAN_VERIFIED=true`. Needs your IPG spec. |

Settlement accounts (configured on each gateway's portal, not in the API):
Alfalah `00681011050474` · Meezan `PK86MEZN0015040115102971` · JazzCash
`03318333368` — all titled PLAYBEAT DIGITAL / PLAYBEAT ARENA.

## Security

- All secrets are read from `process.env`; nothing is hardcoded.
- The keys shared in chat are compromised — **rotate them** before use.
- Secret/restricted keys must never reach the frontend or a git repo.
