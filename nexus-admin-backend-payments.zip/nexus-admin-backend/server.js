require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);

// ─── Socket.IO (real-time inventory + order alerts) ────────────────────────
const io = new Server(server, {
  cors: { origin: process.env.FRONTEND_URL || 'http://localhost:3000', methods: ['GET', 'POST'] }
});
app.set('io', io);
io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);
  socket.on('disconnect', () => console.log('Client disconnected:', socket.id));
});

// ─── Middleware ─────────────────────────────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:3000', credentials: true }));
app.use(morgan('dev'));

// ─── Stripe webhook (RAW body, must precede express.json) ───────────────────
// Signature verification needs the unparsed body. All other routes use JSON.
app.post('/api/checkout/webhook/stripe',
  express.raw({ type: 'application/json' }),
  require('./routes/checkout').stripeWebhook
);

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Rate limiting
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 500 });
app.use('/api/', limiter);

// ─── Routes ─────────────────────────────────────────────────────────────────
app.use('/api/auth',       require('./routes/auth'));
app.use('/api/products',   require('./routes/products'));
app.use('/api/homepage',   require('./routes/homepage'));
app.use('/api/orders',     require('./routes/orders'));
app.use('/api/customers',  require('./routes/customers'));
app.use('/api/inventory',  require('./routes/inventory'));
app.use('/api/media',      require('./routes/media'));
app.use('/api/analytics',  require('./routes/analytics'));
app.use('/api/categories', require('./routes/categories'));
app.use('/api/settings',   require('./routes/settings'));
app.use('/api/checkout',   require('./routes/checkout'));

// Health check
app.get('/api/health', (req, res) => res.json({
  status: 'ok',
  dbConnected: app.get('dbConnected'),
  timestamp: new Date()
}));

// ─── Error Handler ──────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// ─── Start server FIRST, then connect to the DB ────────────────────────────
// IMPORTANT (Render/most PaaS): the host only marks a deploy "live" once it
// detects an open port. Previously this app waited for MongoDB to connect
// before calling server.listen(), and exited the process if that connection
// failed. If Mongo was slow, unreachable, or misconfigured (bad URI, Atlas IP
// allowlist, etc.), no port was ever opened and Render would report the
// deploy as failed/stuck — even though the rest of the app was fine. Now the
// HTTP server binds immediately, and Mongo connects (with retry) in the
// background, so the service comes up and /api/health is reachable
// regardless of DB state.
const PORT = process.env.PORT || 5000;

server.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));

app.set('dbConnected', false);

function connectDB(retryDelayMs = 5000) {
  mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/nexus-admin')
    .then(() => {
      app.set('dbConnected', true);
      console.log('✅ MongoDB connected');
    })
    .catch(err => {
      app.set('dbConnected', false);
      console.error('❌ MongoDB connection error:', err.message);
      console.log(`Retrying MongoDB connection in ${retryDelayMs / 1000}s...`);
      setTimeout(() => connectDB(retryDelayMs), retryDelayMs);
    });
}
connectDB();

mongoose.connection.on('disconnected', () => {
  app.set('dbConnected', false);
  console.warn('⚠️ MongoDB disconnected');
});

// Never let an unexpected error silently kill the container
process.on('unhandledRejection', (err) => console.error('Unhandled rejection:', err));
process.on('uncaughtException', (err) => console.error('Uncaught exception:', err));
