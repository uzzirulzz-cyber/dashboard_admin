// ─── services/payments/meezanProvider.js ─────────────────────────────────────
// Meezan Bank Internet Payment Gateway scaffold.
//
// ⚠️ NOT VERIFIED. Meezan's IPG request/response format and signing differ by
// merchant onboarding; confirm against the spec Meezan gives you and test in
// their sandbox. Refuses to run until MEEZAN_VERIFIED=true.
//
// Env (matches the Laravel config you shared):
//   MEZPAY_USERNAME, MEZPAY_PASSWORD, MEZPAY_SUCCESS_CALLBACK,
//   MEZPAY_FAILED_CALLBACK, MEEZAN_API_URL, MEEZAN_SSO_URL
// Settlement: IBAN PK86MEZN0015040115102971 — PLAYBEAT DIGITAL PRIVATE LIMITED
//   (configured on Meezan's side, not sent in the API).

function env(k, required = true) {
  const v = process.env[k];
  if (required && !v) throw new Error(`${k} is not set`);
  return v;
}
function ensureVerified() {
  if (process.env.MEEZAN_VERIFIED !== 'true') {
    throw new Error(
      'Meezan is not enabled: complete a sandbox round-trip, confirm the IPG ' +
      'spec for your merchant, then set MEEZAN_VERIFIED=true.'
    );
  }
}

module.exports = {
  id: 'meezan',

  async createSession({ order, currency, returnUrl }) {
    ensureVerified();
    if ((currency || 'PKR').toUpperCase() !== 'PKR') throw new Error('Meezan only settles PKR');

    // ⚠️ Replace with Meezan's exact create-transaction call + redirect contract.
    const fields = {
      Username: env('MEZPAY_USERNAME'),
      // password is sent server→server only; never expose to the client
      OrderId: order.orderNumber || String(order._id),
      Amount: String(Math.round((order.total || 0) * 100) / 100),
      Currency: 'PKR',
      ReturnURL: returnUrl,
      SuccessCallback: env('MEZPAY_SUCCESS_CALLBACK'),
      FailedCallback: env('MEZPAY_FAILED_CALLBACK'),
    };
    const ssoUrl = env('MEEZAN_SSO_URL');
    return { type: 'form', providerRef: fields.OrderId, formPost: { action: ssoUrl, fields } };
  },

  async resolvePaid(req) {
    ensureVerified();
    const data = req.body || {};
    // ⚠️ Confirm Meezan's success indicator and verify any signature.
    const paid = data.status === 'success' || data.ResponseCode === '00';
    return { providerRef: data.OrderId || null, orderId: null, paid, raw: data };
  },
};
