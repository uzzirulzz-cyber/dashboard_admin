// ─── services/payments/alfalahProvider.js ────────────────────────────────────
// Bank Alfalah "HS" (Handshake) API — AES-encrypted handshake → hosted page
// redirect → server callback.
//
// ⚠️ NOT VERIFIED against a live Alfalah account. The handshake field list and
// the exact hash/encryption order MUST be confirmed against the integration
// guide for YOUR merchant + tested in Alfalah sandbox. To prevent accidental
// live use of unverified code, this provider refuses to run until you set
// ALFALAH_VERIFIED=true (do that only after a successful sandbox round-trip).
//
// Env (matches the Laravel config you shared):
//   ALFAPAY_API_URL, ALFAPAY_MODE, ALFAPAY_CHANNEL_ID, ALFAPAY_MERCHANT_ID,
//   ALFAPAY_STORE_ID, ALFAPAY_RETURN_URL, ALFAPAY_MERCHANT_USERNAME,
//   ALFAPAY_MERCHANT_PASSWORD, ALFAPAY_MERCHANT_HASH, ALFAPAY_KEY_1, ALFAPAY_KEY_2
// Settlement account: PLAYBEAT DIGITAL (PRIVATE LIMITED) 00681011050474
//   — configured on Alfalah's merchant portal, not sent in the API.

const crypto = require('crypto');

function env(k, required = true) {
  const v = process.env[k];
  if (required && !v) throw new Error(`${k} is not set`);
  return v;
}
function ensureVerified() {
  if (process.env.ALFALAH_VERIFIED !== 'true') {
    throw new Error(
      'Bank Alfalah is not enabled: complete a sandbox round-trip, confirm the ' +
      'handshake spec for your merchant, then set ALFALAH_VERIFIED=true.'
    );
  }
}

// AES-128-CBC using KEY_1 as key and KEY_2 as IV (Alfalah HS convention).
function aesEncrypt(plain) {
  const key = Buffer.from(env('ALFAPAY_KEY_1'), 'utf8');
  const iv  = Buffer.from(env('ALFAPAY_KEY_2'), 'utf8');
  const c = crypto.createCipheriv('aes-128-cbc', key, iv);
  return Buffer.concat([c.update(plain, 'utf8'), c.final()]).toString('base64');
}

module.exports = {
  id: 'alfalah',

  async createSession({ order, currency, returnUrl }) {
    ensureVerified();
    if ((currency || 'PKR').toUpperCase() !== 'PKR') throw new Error('Bank Alfalah only settles PKR');

    // Step 1 — handshake to obtain an AuthToken.  ⚠️ Confirm exact field names.
    const handshake = {
      HS_ChannelId:        env('ALFAPAY_CHANNEL_ID'),
      HS_MerchantId:       env('ALFAPAY_MERCHANT_ID'),
      HS_StoreId:          env('ALFAPAY_STORE_ID'),
      HS_MerchantHash:     env('ALFAPAY_MERCHANT_HASH'),
      HS_MerchantUsername: env('ALFAPAY_MERCHANT_USERNAME'),
      HS_MerchantPassword: env('ALFAPAY_MERCHANT_PASSWORD'),
      HS_TransactionReferenceNumber: order.orderNumber || String(order._id),
      HS_ReturnURL:        returnUrl || env('ALFAPAY_RETURN_URL'),
    };
    handshake.HS_RequestHash = aesEncrypt(Object.values(handshake).join('&'));

    const res = await fetch(env('ALFAPAY_API_URL'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(handshake),
    });
    const out = await res.json().catch(() => ({}));
    const authToken = out.AuthToken || out.authToken;
    if (!authToken) throw new Error('Alfalah handshake failed: ' + JSON.stringify(out));

    // Step 2 — redirect customer to the hosted SSO/checkout page with the token.
    const fields = {
      AuthToken: authToken,
      ChannelId: env('ALFAPAY_CHANNEL_ID'),
      MerchantId: env('ALFAPAY_MERCHANT_ID'),
      StoreId: env('ALFAPAY_STORE_ID'),
      ReturnURL: returnUrl || env('ALFAPAY_RETURN_URL'),
      TransactionReferenceNumber: order.orderNumber || String(order._id),
      TransactionAmount: String(Math.round((order.total || 0) * 100) / 100),
      Currency: 'PKR',
    };
    const ssoUrl = env('ALFALAH_SSO_URL', false) ||
      'https://sandbox.bankalfalah.com/SSO/SSO/SSO';
    return { type: 'form', providerRef: fields.TransactionReferenceNumber, formPost: { action: ssoUrl, fields } };
  },

  async resolvePaid(req) {
    ensureVerified();
    const data = req.body || {};
    // ⚠️ Confirm Alfalah's success field/code and verify any returned hash.
    const paid = data.success === 'true' || data.ResponseCode === '00' || data.RC === '00';
    return {
      providerRef: data.TransactionReferenceNumber || null,
      orderId: null, // map via providerRef → order lookup in the route
      paid,
      raw: data,
    };
  },
};
