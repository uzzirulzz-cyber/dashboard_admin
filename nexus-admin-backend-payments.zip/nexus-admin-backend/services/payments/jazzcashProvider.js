// ─── services/payments/jazzcashProvider.js ───────────────────────────────────
// JazzCash "Page Redirect (HTTP POST)" integration.
//
// ⚠️ VERIFY BEFORE LIVE: field set and hash recipe must match the exact version
// in YOUR JazzCash integration guide (v1.1 vs v2.0 differ). Test every path in
// the JazzCash sandbox first. This implements the common v1.1 hosted-checkout
// recipe: SecureHash = HMAC-SHA256( saltedSortedValues ), hex UPPERCASE.
//
// Env: JAZZCASH_MERCHANTID, JAZZCASH_PASSWORD, JAZZCASH_HASHKEY (integrity salt),
//      JAZZCASH_RETURNURL, JAZZCASH_SANDBOX_URL, JAZZCASH_PRODUCTION_URL,
//      PAYMENTS_MODE=sandbox|live
// Settlement: funds settle to your JazzCash merchant account
//      (PLAYBEAT ARENA MERCHANT, 03318333368) — configured on JazzCash's side,
//      not passed in the API.

const crypto = require('crypto');
const cfg = require('../../config/payments');

function env(k) { const v = process.env[k]; if (!v) throw new Error(`${k} is not set`); return v; }
function gatewayUrl() {
  return cfg.MODE === 'live'
    ? env('JAZZCASH_PRODUCTION_URL')
    : env('JAZZCASH_SANDBOX_URL');
}

// yyyyMMddHHmmss in Asia/Karachi
function pkTimestamp(offsetMs = 0) {
  const d = new Date(Date.now() + offsetMs);
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Karachi', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  }).formatToParts(d).reduce((a, p) => (a[p.type] = p.value, a), {});
  return `${parts.year}${parts.month}${parts.day}${parts.hour}${parts.minute}${parts.second}`;
}

// HMAC-SHA256 over salt + '&' + (non-empty values sorted by key, '&'-joined).
function secureHash(fields, salt) {
  const sorted = Object.keys(fields).sort()
    .filter(k => fields[k] !== '' && fields[k] != null)
    .map(k => fields[k]);
  const message = salt + '&' + sorted.join('&');
  return crypto.createHmac('sha256', salt).update(message).digest('hex').toUpperCase();
}

module.exports = {
  id: 'jazzcash',

  async createSession({ order, currency, returnUrl }) {
    if ((currency || 'PKR').toUpperCase() !== 'PKR') {
      throw new Error('JazzCash only settles PKR');
    }
    const salt = env('JAZZCASH_HASHKEY');
    const fields = {
      pp_Version: '1.1',
      pp_TxnType: 'MWALLET',
      pp_Language: 'EN',
      pp_MerchantID: env('JAZZCASH_MERCHANTID'),
      pp_SubMerchantID: '',
      pp_Password: env('JAZZCASH_PASSWORD'),
      pp_BankID: '',
      pp_ProductID: '',
      pp_TxnRefNo: 'T' + pkTimestamp() + String(order._id).slice(-6),
      pp_Amount: String(Math.round((order.total || 0) * 100)), // paisa
      pp_TxnCurrency: 'PKR',
      pp_TxnDateTime: pkTimestamp(),
      pp_BillReference: order.orderNumber || String(order._id),
      pp_Description: `Order ${order.orderNumber || order._id}`,
      pp_TxnExpiryDateTime: pkTimestamp(60 * 60 * 1000), // +1h
      pp_ReturnURL: returnUrl || env('JAZZCASH_RETURNURL'),
      ppmpf_1: String(order._id),
    };
    fields.pp_SecureHash = secureHash(fields, salt);

    // Storefront auto-submits this form to JazzCash's hosted page.
    return { type: 'form', providerRef: fields.pp_TxnRefNo, formPost: { action: gatewayUrl(), fields } };
  },

  // JazzCash POSTs back to the return URL. Re-verify the hash, then trust
  // pp_ResponseCode === '000'. Never trust the browser's word for it.
  async resolvePaid(req) {
    const data = req.body || {};
    const received = data.pp_SecureHash;
    const copy = { ...data };
    delete copy.pp_SecureHash;
    const expected = secureHash(copy, env('JAZZCASH_HASHKEY'));
    const valid = received && received.toUpperCase() === expected;
    return {
      providerRef: data.pp_TxnRefNo || null,
      orderId: data.ppmpf_1 || null,
      paid: valid && data.pp_ResponseCode === '000',
      raw: data,
      signatureValid: valid,
    };
  },
};
