// ─── services/payments/stripeProvider.js ─────────────────────────────────────
// Production-ready Stripe path using Checkout Sessions.
//
// Requires:  npm install stripe
// Env:       STRIPE_SECRET_KEY=sk_...        (server only — NEVER sent to client)
//            STRIPE_WEBHOOK_SECRET=whsec_... (from the webhook endpoint you create)
//
// Note on PKR: Stripe must support your account's settlement/presentment
// currency. Many Pakistani businesses cannot settle PKR on Stripe — verify in
// your Stripe Dashboard. If PKR isn't available, route PKR through the local
// rails (JazzCash/Alfalah/Meezan) and use Stripe for card/foreign currency.

let stripe = null;
function client() {
  if (stripe) return stripe;
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) throw new Error('STRIPE_SECRET_KEY is not set');
  // eslint-disable-next-line global-require
  stripe = require('stripe')(key);
  return stripe;
}

// Currencies Stripe treats as zero-decimal (amount is NOT multiplied by 100).
const ZERO_DECIMAL = new Set(['JPY', 'KRW', 'VND', 'CLP', 'BIF', 'DJF', 'GNF',
  'KMF', 'MGA', 'PYG', 'RWF', 'UGX', 'VUV', 'XAF', 'XOF', 'XPF']);

function toMinor(amountMajor, currency) {
  const cur = (currency || 'USD').toUpperCase();
  return ZERO_DECIMAL.has(cur) ? Math.round(amountMajor) : Math.round(amountMajor * 100);
}

module.exports = {
  id: 'stripe',

  // Create a hosted Checkout Session and return its URL for redirect.
  async createSession({ order, currency, returnUrl, cancelUrl, customer }) {
    const cur = (currency || 'USD').toLowerCase();
    const line_items = (order.items || []).map(i => ({
      price_data: {
        currency: cur,
        product_data: { name: i.name || 'Item' },
        unit_amount: toMinor(i.price, currency),
      },
      quantity: i.quantity || 1,
    }));
    // Fold shipping/tax/discount into a single adjustment line if present.
    const adj = (order.shipping || 0) + (order.tax || 0) - (order.discount || 0);
    if (adj > 0) {
      line_items.push({
        price_data: { currency: cur, product_data: { name: 'Shipping & tax' }, unit_amount: toMinor(adj, currency) },
        quantity: 1,
      });
    }

    const session = await client().checkout.sessions.create({
      mode: 'payment',
      line_items,
      customer_email: customer?.email,
      // We trust ONLY the order id we put here on the webhook, never client input.
      client_reference_id: String(order._id),
      metadata: { orderId: String(order._id), orderNumber: order.orderNumber || '' },
      success_url: returnUrl,
      cancel_url: cancelUrl,
    });

    return { type: 'redirect', providerRef: session.id, redirectUrl: session.url };
  },

  // Verify the webhook signature and report whether THIS event means "paid".
  // `req` must carry the raw (unparsed) body — see server.js wiring.
  async resolvePaid(req) {
    const secret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!secret) throw new Error('STRIPE_WEBHOOK_SECRET is not set');
    const sig = req.headers['stripe-signature'];
    const event = client().webhooks.constructEvent(req.body, sig, secret); // throws if invalid

    if (event.type === 'checkout.session.completed') {
      const s = event.data.object;
      const paid = s.payment_status === 'paid';
      return { providerRef: s.id, orderId: s.metadata?.orderId || s.client_reference_id, paid, raw: event };
    }
    // Other events: acknowledge but don't confirm anything.
    return { providerRef: null, orderId: null, paid: false, raw: event, ignored: true };
  },
};
