// ─── services/payments/index.js ──────────────────────────────────────────────
// Registry that maps a provider id to its implementation and exposes the
// client-safe list of methods. Every provider implements the same interface:
//
//   id
//   async createSession({ order, currency, amountMinor, returnUrl, cancelUrl, customer })
//        → { type, providerRef, redirectUrl?, formPost?, clientSecret? }
//   async resolvePaid(reqOrEvent)   // verify a webhook/callback → { providerRef, paid, raw }
//
// Adding a rail = drop a new file in this folder and register it here.

const cfg = require('../../config/payments');

const impls = {
  stripe:   require('./stripeProvider'),
  jazzcash: require('./jazzcashProvider'),
  alfalah:  require('./alfalahProvider'),
  meezan:   require('./meezanProvider'),
};

function getProvider(id) {
  const p = impls[id];
  if (!p) throw new Error(`Unknown payment provider: ${id}`);
  if (!cfg.ENABLED.includes(id)) throw new Error(`Payment provider disabled: ${id}`);
  return p;
}

// Client-safe: ONLY id/label/logo/kind. No secrets ever leave the server.
function publicMethods(region) {
  return cfg.methodsForRegion(region).map(id => cfg.PROVIDERS[id]).filter(Boolean);
}

module.exports = { getProvider, publicMethods, cfg };
