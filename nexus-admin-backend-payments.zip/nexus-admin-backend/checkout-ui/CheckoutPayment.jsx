// ─── CheckoutPayment.jsx ─────────────────────────────────────────────────────
// Storefront checkout step. Shows ONLY payment-provider logos (no card fields,
// no merchant details). Requires the customer to be logged in — guests are
// redirected to sign-up. On submit it asks the backend to create a gateway
// session and then hands the customer to the gateway. The order is confirmed
// server-side only after the gateway verifies payment.
//
// Expects:
//   - an auth token in localStorage 'token' (adjust to your auth store)
//   - the cart as [{ productId, quantity }]
//   - logos served at /pay/<id>.svg (public folder)

import { useEffect, useState } from 'react';

const API = import.meta.env.VITE_API_URL || '/api';

export default function CheckoutPayment({ cart = [], region = 'PK', shipping = 0, address }) {
  const [methods, setMethods] = useState([]);
  const [currency, setCurrency] = useState('PKR');
  const [selected, setSelected] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;

  // Guests cannot check out — bounce to sign-up.
  useEffect(() => {
    if (!token) window.location.href = `/register?redirect=/checkout`;
  }, [token]);

  // Load the region's methods (logos only).
  useEffect(() => {
    fetch(`${API}/checkout/methods?region=${encodeURIComponent(region)}`)
      .then(r => r.json())
      .then(d => { if (d.success) { setMethods(d.methods); setCurrency(d.currency); setSelected(d.methods[0]?.id || null); } })
      .catch(() => setError('Could not load payment methods'));
  }, [region]);

  async function pay() {
    if (!selected || busy) return;
    setBusy(true); setError('');
    try {
      const res = await fetch(`${API}/checkout/session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ method: selected, region, shipping, address, items: cart }),
      });
      if (res.status === 401) { window.location.href = `/login?redirect=/checkout`; return; }
      const data = await res.json();
      if (!data.success) throw new Error(data.message || 'Checkout failed');

      const p = data.payment;
      if (p.type === 'redirect') {
        window.location.href = p.redirectUrl;            // Stripe hosted checkout
      } else if (p.type === 'form') {
        autoSubmit(p.formPost.action, p.formPost.fields); // JazzCash / Alfalah / Meezan
      } else {
        throw new Error('Unsupported payment response');
      }
    } catch (e) {
      setError(e.message);
      setBusy(false);
    }
  }

  // Build and submit a hidden form to the gateway's hosted page.
  function autoSubmit(action, fields) {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = action;
    Object.entries(fields).forEach(([k, v]) => {
      const input = document.createElement('input');
      input.type = 'hidden'; input.name = k; input.value = v;
      form.appendChild(input);
    });
    document.body.appendChild(form);
    form.submit();
  }

  return (
    <div style={s.wrap}>
      <h3 style={s.title}>Payment</h3>
      <p style={s.sub}>Choose how to pay. You'll complete payment securely on the provider's page.</p>

      <div style={s.grid}>
        {methods.map(m => (
          <button
            key={m.id}
            onClick={() => setSelected(m.id)}
            style={{ ...s.method, ...(selected === m.id ? s.methodOn : {}) }}
            aria-pressed={selected === m.id}
            title={m.label}
          >
            {/* Logos only — no underlying details are ever shown */}
            <img src={m.logo} alt={m.label} style={s.logo}
                 onError={(e) => { e.currentTarget.replaceWith(Object.assign(document.createElement('span'), { textContent: m.label, style: 'font-size:13px;color:#ddd' })); }} />
          </button>
        ))}
      </div>

      {error && <div style={s.err}>{error}</div>}

      <button onClick={pay} disabled={!selected || busy} style={{ ...s.cta, ...((!selected || busy) ? s.ctaOff : {}) }}>
        {busy ? 'Redirecting…' : `Pay with ${methods.find(m => m.id === selected)?.label || '—'}`}
      </button>
      <div style={s.note}>Prices in {currency}. Your order is confirmed only after payment is received.</div>
    </div>
  );
}

const s = {
  wrap: { maxWidth: 460, margin: '0 auto', color: '#f0f0f0', fontFamily: 'Inter, system-ui, sans-serif' },
  title: { fontSize: 18, fontWeight: 600, marginBottom: 4 },
  sub: { fontSize: 13, color: '#aaa', marginBottom: 16 },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10, marginBottom: 16 },
  method: { display: 'flex', alignItems: 'center', justifyContent: 'center', height: 64, background: '#161616', border: '1px solid #2a2a2a', borderRadius: 10, cursor: 'pointer', transition: 'all .15s' },
  methodOn: { borderColor: '#f97316', boxShadow: '0 0 0 2px rgba(249,115,22,0.25)' },
  logo: { maxHeight: 28, maxWidth: '70%', objectFit: 'contain' },
  cta: { width: '100%', padding: '12px 16px', background: '#f97316', color: '#fff', border: 'none', borderRadius: 10, fontSize: 14, fontWeight: 600, cursor: 'pointer' },
  ctaOff: { opacity: 0.5, cursor: 'not-allowed' },
  err: { background: 'rgba(239,68,68,0.12)', color: '#f87171', padding: '8px 12px', borderRadius: 8, fontSize: 13, marginBottom: 12 },
  note: { fontSize: 11, color: '#666', textAlign: 'center', marginTop: 10 },
};
