# PlayBeat Frontend — Vercel Deployment

## One-time Setup

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "PlayBeat frontend v2"
git remote add origin https://github.com/YOUR_ORG/playbeat-frontend.git
git push -u origin main
```

### 2. Import to Vercel
1. Go to [vercel.com](https://vercel.com) → New Project
2. Import your `playbeat-frontend` GitHub repo
3. Vercel auto-detects Vite — settings are pre-configured in `vercel.json`
4. **Do not change** Framework Preset — leave as Vite

### 3. Set Environment Variables in Vercel
In Vercel → Project → Settings → Environment Variables:

| Key | Value | Environments |
|-----|-------|-------------|
| `VITE_API_URL` | `https://playbeat-backend.onrender.com` | Production, Preview |
| `VITE_API_URL` | `http://localhost:3000` | Development |
| `VITE_STRIPE_PUBLISHABLE_KEY` | `pk_live_...` | Production |
| `VITE_STRIPE_PUBLISHABLE_KEY` | `pk_test_...` | Development, Preview |

> ⚠️ All frontend env vars **must** start with `VITE_` to be accessible in the browser.

### 4. Deploy
Click **Deploy** — Vercel builds and serves from `dist/`. Every `git push` to `main` auto-deploys.

### 5. Custom Domain
Vercel → Settings → Domains → Add `playbeat.digital`
- Add `CNAME` pointing to `cname.vercel-dns.com` in your DNS

---

## Local Development
```bash
npm install
cp .env.local.example .env.local   # edit with your local values
npm run dev                         # starts on :5173
```
Vite proxies `/api/*` → `http://localhost:3000` in dev mode.

---

## Project Structure
```
src/
├── components/
│   ├── Layout.jsx          # Sticky header, nav, footer
│   └── ProductCard.jsx     # Product card
├── pages/
│   ├── Home.jsx            # Homepage
│   ├── Product.jsx         # Product detail
│   ├── Cart.jsx            # Cart
│   ├── Checkout.jsx        # Multi-gateway checkout
│   ├── OrderSuccess.jsx    # Post-order page
│   ├── Trending.jsx
│   ├── BestValue.jsx
│   ├── category/           # Games, GiftCards, Software, AiTools...
│   ├── auth/               # Login, Register, Account, Orders
│   └── admin/
│       └── AdminLayout.jsx # Full admin panel (15 sections)
├── store.js                # Zustand: auth + cart + toast
├── utils/api.js            # Axios with JWT interceptor
├── App.jsx                 # All routes
└── index.css               # Design system / CSS variables
```

## Admin Panel
URL: `https://playbeat.vercel.app/admin`

Accessible to roles: `super_admin`, `admin`, `manager`, `support`, `content_manager`

| Section | Path | Description |
|---------|------|-------------|
| Dashboard | /admin | Revenue, order stats |
| Products | /admin/products | Add/edit/delete products |
| Categories | /admin/categories | Manage categories |
| Orders | /admin/orders | View, update, deliver keys |
| Customers | /admin/customers | Manage users, suspend/ban |
| Subscriptions | /admin/subscriptions | Plans + user subscriptions |
| Inventory | /admin/inventory | Add digital keys per product |
| Homepage | /admin/homepage | Banners, blocks, announcements |
| Coupons | /admin/coupons | Create discount codes |
| Payments | /admin/payments | Toggle gateway visibility |
| Support | /admin/support | Ticket management |
| Analytics | /admin/analytics | Revenue charts, gateway stats |
| Roles & Staff | /admin/roles | Staff accounts and roles |
| Audit Logs | /admin/audit | Action audit trail |
| Settings | /admin/settings | Store configuration |

## Payment Gateways (displayed at checkout)
- 🌍 **International**: Stripe, PayPal, Paddle, Skrill, Wise, Revolut
- 🇵🇰 **Pakistan**: JazzCash, EasyPaisa, Bank Alfalah, Meezan Bank, Raast
- ₿ **Crypto**: Bitcoin, Ethereum, USDT TRC20/ERC20, Litecoin
