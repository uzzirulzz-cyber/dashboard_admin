import React, { Suspense, lazy } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore, useToastStore } from './store';
import Layout from './components/Layout';

const Home          = lazy(() => import('./pages/Home'));
const Games         = lazy(() => import('./pages/category/Games'));
const GiftCards     = lazy(() => import('./pages/category/GiftCards'));
const Software      = lazy(() => import('./pages/category/Software'));
const AiTools       = lazy(() => import('./pages/category/AiTools'));
const GameItems     = lazy(() => import('./pages/category/GameItems'));
const Accounts      = lazy(() => import('./pages/category/Accounts'));
const Subscriptions = lazy(() => import('./pages/category/Subscriptions'));
const TopUp         = lazy(() => import('./pages/category/TopUp'));
const Trending      = lazy(() => import('./pages/Trending'));
const BestValue     = lazy(() => import('./pages/BestValue'));
const Product       = lazy(() => import('./pages/Product'));
const Cart          = lazy(() => import('./pages/Cart'));
const Checkout      = lazy(() => import('./pages/Checkout'));
const OrderSuccess  = lazy(() => import('./pages/OrderSuccess'));
const Login         = lazy(() => import('./pages/auth/Login'));
const Register      = lazy(() => import('./pages/auth/Register'));
const Account       = lazy(() => import('./pages/auth/Account'));
const Orders        = lazy(() => import('./pages/auth/Orders'));
const AdminLayout   = lazy(() => import('./pages/admin/AdminLayout'));

const STAFF_ROLES = ['admin','super_admin','manager','support','content_manager'];

function Spinner() {
  return <div style={{ display:'flex', justifyContent:'center', alignItems:'center', height:'60vh' }}><div style={{ width:36, height:36, border:'3px solid #2a2a3a', borderTopColor:'#7c6cff', borderRadius:'50%', animation:'spin 0.8s linear infinite' }} /><style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style></div>;
}

function Toasts() {
  const { toasts, removeToast } = useToastStore();
  return (
    <div style={{ position:'fixed', top:20, right:20, zIndex:9999, display:'flex', flexDirection:'column', gap:8 }}>
      {toasts.map(t => (
        <div key={t.id} onClick={() => removeToast(t.id)} style={{ padding:'12px 18px', borderRadius:10, background: t.type==='error'?'#2a1015':t.type==='success'?'#0f2a10':'#1a1a2a', border:`1px solid ${t.type==='error'?'#ef4444':t.type==='success'?'#22c55e':'#3a3a4a'}`, color:'#e2e2f0', fontSize:14, cursor:'pointer', maxWidth:340, boxShadow:'0 4px 24px rgba(0,0,0,.4)' }}>
          {t.type === 'error' ? '❌ ' : t.type === 'success' ? '✅ ' : 'ℹ️ '}{t.message}
        </div>
      ))}
    </div>
  );
}

const PrivateRoute = ({ children }) => {
  const { user, token } = useAuthStore();
  return (user && token) ? children : <Navigate to="/login" replace />;
};

const AdminRoute = ({ children }) => {
  const { user, token } = useAuthStore();
  if (!user || !token) return <Navigate to="/login" replace />;
  if (!STAFF_ROLES.includes(user.role)) return <Navigate to="/" replace />;
  return children;
};

export default function App() {
  return (
    <>
      <Toasts />
      <Suspense fallback={<Spinner />}>
        <Routes>
          {/* Storefront */}
          <Route element={<Layout />}>
            <Route path="/"               element={<Home />} />
            <Route path="/games"          element={<Games />} />
            <Route path="/gift-cards"     element={<GiftCards />} />
            <Route path="/software"       element={<Software />} />
            <Route path="/ai-tools"       element={<AiTools />} />
            <Route path="/game-items"     element={<GameItems />} />
            <Route path="/accounts"       element={<Accounts />} />
            <Route path="/subscriptions"  element={<Subscriptions />} />
            <Route path="/top-up"         element={<TopUp />} />
            <Route path="/trending"       element={<Trending />} />
            <Route path="/best-value"     element={<BestValue />} />
            <Route path="/product/:slug"  element={<Product />} />
            <Route path="/cart"           element={<Cart />} />
            <Route path="/checkout"       element={<Checkout />} />
            <Route path="/order-success"  element={<OrderSuccess />} />
            <Route path="/login"          element={<Login />} />
            <Route path="/register"       element={<Register />} />
            <Route path="/account"        element={<PrivateRoute><Account /></PrivateRoute>} />
            <Route path="/my-orders"      element={<PrivateRoute><Orders /></PrivateRoute>} />
          </Route>

          {/* Admin — all staff roles */}
          <Route path="/admin/*" element={<AdminRoute><AdminLayout /></AdminRoute>} />

          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Suspense>
    </>
  );
}
