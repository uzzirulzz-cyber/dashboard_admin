import React, { useState, useEffect, useCallback } from 'react';
import { Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuthStore, useToastStore } from '../../store';
import api from '../../utils/api';

// ─── SIDEBAR NAV ──────────────────────────────────────────────────────────────
const NAV = [
  { path:'',              icon:'📊', label:'Dashboard',    roles:['super_admin','admin','manager','support','content_manager'] },
  { path:'products',      icon:'📦', label:'Products',     roles:['super_admin','admin','manager','content_manager'] },
  { path:'categories',    icon:'🗂', label:'Categories',   roles:['super_admin','admin','manager','content_manager'] },
  { path:'orders',        icon:'🛒', label:'Orders',       roles:['super_admin','admin','manager','support'] },
  { path:'customers',     icon:'👥', label:'Customers',    roles:['super_admin','admin','manager'] },
  { path:'subscriptions', icon:'🔄', label:'Subscriptions',roles:['super_admin','admin','manager'] },
  { path:'inventory',     icon:'🔑', label:'Inventory',    roles:['super_admin','admin','manager'] },
  { path:'homepage',      icon:'🏠', label:'Homepage',     roles:['super_admin','admin','manager','content_manager'] },
  { path:'coupons',       icon:'🎟', label:'Coupons',      roles:['super_admin','admin','manager'] },
  { path:'payments',      icon:'💳', label:'Payments',     roles:['super_admin','admin'] },
  { path:'support',       icon:'🎧', label:'Support',      roles:['super_admin','admin','manager','support'] },
  { path:'analytics',     icon:'📈', label:'Analytics',    roles:['super_admin','admin','manager'] },
  { path:'roles',         icon:'🛡', label:'Roles & Staff',roles:['super_admin','admin'] },
  { path:'audit',         icon:'📋', label:'Audit Logs',   roles:['super_admin','admin'] },
  { path:'settings',      icon:'⚙️',  label:'Settings',    roles:['super_admin','admin'] },
];

const S = {
  bg: '#0a0a0f', panel: '#0f0f1a', border: '#1a1a2e', accent: '#7c6cff',
  text: '#e2e2f0', muted: '#5a5a72', success: '#22c55e', danger: '#ef4444',
  warning: '#f59e0b', info: '#06b6d4'
};

function Sidebar({ current, userRole }) {
  const { logout } = useAuthStore();
  const navigate = useNavigate();
  const visibleNav = NAV.filter(n => n.roles.includes(userRole));
  return (
    <aside style={{ width:220, background:S.bg, borderRight:`1px solid ${S.border}`, display:'flex', flexDirection:'column', height:'100vh', flexShrink:0, overflow:'hidden' }}>
      <div style={{ padding:'18px 16px', borderBottom:`1px solid ${S.border}`, flexShrink:0 }}>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <div style={{ width:30, height:30, background:S.accent, borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', fontSize:16 }}>⚡</div>
          <div>
            <div style={{ fontSize:14, fontWeight:700, color:S.text }}>PlayBeat</div>
            <div style={{ fontSize:10, color:S.muted, textTransform:'uppercase', letterSpacing:'.06em' }}>Admin Panel</div>
          </div>
        </div>
      </div>
      <nav style={{ flex:1, overflowY:'auto', padding:'8px 0' }}>
        {visibleNav.map(n => {
          const active = current === n.path || (n.path && current?.startsWith(n.path));
          return (
            <Link key={n.path} to={`/admin/${n.path}`} style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 16px', textDecoration:'none', color: active ? S.text : S.muted, background: active ? 'rgba(124,108,255,.15)' : 'transparent', borderLeft: active ? `2px solid ${S.accent}` : '2px solid transparent', fontSize:13, fontWeight: active ? 600 : 400, transition:'all .15s' }}>
              <span style={{ fontSize:15 }}>{n.icon}</span>{n.label}
            </Link>
          );
        })}
      </nav>
      <div style={{ padding:'12px 16px', borderTop:`1px solid ${S.border}` }}>
        <button onClick={() => { logout(); navigate('/'); }} style={{ width:'100%', padding:'8px', background:'rgba(239,68,68,.1)', border:`1px solid rgba(239,68,68,.3)`, borderRadius:8, color:S.danger, fontSize:13, cursor:'pointer' }}>Sign Out</button>
      </div>
    </aside>
  );
}

function PageWrap({ title, action, children }) {
  return (
    <div style={{ padding:28 }}>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:24 }}>
        <h1 style={{ fontSize:20, fontWeight:700, color:S.text, margin:0 }}>{title}</h1>
        {action}
      </div>
      {children}
    </div>
  );
}

function Card({ children, style }) {
  return <div style={{ background:S.panel, border:`1px solid ${S.border}`, borderRadius:12, padding:20, ...style }}>{children}</div>;
}

function Stat({ label, value, icon, color = S.accent, sub }) {
  return (
    <Card>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
        <div>
          <div style={{ fontSize:12, color:S.muted, marginBottom:6 }}>{label}</div>
          <div style={{ fontSize:26, fontWeight:700, color:S.text }}>{value}</div>
          {sub && <div style={{ fontSize:11, color:S.muted, marginTop:4 }}>{sub}</div>}
        </div>
        <div style={{ fontSize:24 }}>{icon}</div>
      </div>
    </Card>
  );
}

function Badge({ children, color = S.accent }) {
  return <span style={{ background:`${color}22`, color, border:`1px solid ${color}44`, borderRadius:6, padding:'2px 8px', fontSize:11, fontWeight:600 }}>{children}</span>;
}

function Btn({ children, onClick, variant='primary', size='md', disabled, style: extra }) {
  const bg = variant==='danger' ? S.danger : variant==='success' ? S.success : variant==='ghost' ? 'transparent' : S.accent;
  const border = variant==='ghost' ? `1px solid ${S.border}` : 'none';
  const pad = size==='sm' ? '5px 12px' : '9px 18px';
  return (
    <button onClick={onClick} disabled={disabled} style={{ background:bg, color:'#fff', border, borderRadius:8, padding:pad, fontSize:13, fontWeight:600, cursor:disabled?'not-allowed':'pointer', opacity:disabled?.6:1, ...extra }}>
      {children}
    </button>
  );
}

function Input({ label, value, onChange, type='text', placeholder, style: extra }) {
  return (
    <div style={{ marginBottom:14 }}>
      {label && <div style={{ fontSize:12, color:S.muted, marginBottom:5 }}>{label}</div>}
      <input type={type} value={value} onChange={onChange} placeholder={placeholder} style={{ width:'100%', background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'9px 12px', color:S.text, fontSize:13, outline:'none', boxSizing:'border-box', ...extra }} />
    </div>
  );
}

function Select({ label, value, onChange, options, style: extra }) {
  return (
    <div style={{ marginBottom:14 }}>
      {label && <div style={{ fontSize:12, color:S.muted, marginBottom:5 }}>{label}</div>}
      <select value={value} onChange={onChange} style={{ width:'100%', background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'9px 12px', color:S.text, fontSize:13, outline:'none', boxSizing:'border-box', ...extra }}>
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

function Table({ cols, rows, renderRow }) {
  return (
    <div style={{ overflowX:'auto' }}>
      <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
        <thead>
          <tr>{cols.map(c => <th key={c} style={{ textAlign:'left', padding:'10px 12px', borderBottom:`1px solid ${S.border}`, color:S.muted, fontWeight:500, fontSize:11, textTransform:'uppercase', letterSpacing:'.05em', whiteSpace:'nowrap' }}>{c}</th>)}</tr>
        </thead>
        <tbody>{rows.map((r,i) => <tr key={i} style={{ borderBottom:`1px solid ${S.border}22` }}>{renderRow(r, i)}</tr>)}</tbody>
      </table>
    </div>
  );
}

function TD({ children, muted }) {
  return <td style={{ padding:'10px 12px', color: muted ? S.muted : S.text, whiteSpace:'nowrap' }}>{children}</td>;
}

function Modal({ open, onClose, title, children, width=480 }) {
  if (!open) return null;
  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.7)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:1000 }} onClick={onClose}>
      <div style={{ background:S.panel, border:`1px solid ${S.border}`, borderRadius:14, padding:24, width, maxWidth:'90vw', maxHeight:'90vh', overflowY:'auto' }} onClick={e=>e.stopPropagation()}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
          <div style={{ fontSize:16, fontWeight:700, color:S.text }}>{title}</div>
          <button onClick={onClose} style={{ background:'none', border:'none', color:S.muted, fontSize:20, cursor:'pointer' }}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ─── STATUS HELPERS ───────────────────────────────────────────────────────────
const statusColor = s => ({ pending:S.warning, processing:S.info, completed:S.success, cancelled:S.muted, refunded:S.info, disputed:S.danger, paid:S.success, failed:S.danger, active:S.success, expired:S.danger, cancelled:S.muted, open:S.warning, resolved:S.success, closed:S.muted, in_progress:S.info })[s] || S.muted;
const fmt = n => n >= 1e6 ? (n/1e6).toFixed(1)+'M' : n >= 1e3 ? (n/1e3).toFixed(1)+'K' : (n||0).toFixed ? n.toFixed(2) : n;
const fmtDate = d => d ? new Date(d).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}) : '–';

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function Dashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    api.get('/api/admin/dashboard').then(r => { setStats(r.data.stats); setLoading(false); }).catch(()=>setLoading(false));
  }, []);
  if (loading) return <PageWrap title="Dashboard"><div style={{ color:S.muted, padding:40, textAlign:'center' }}>Loading...</div></PageWrap>;
  const s = stats || {};
  return (
    <PageWrap title="Dashboard">
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:16, marginBottom:28 }}>
        <Stat label="Total Revenue" value={`$${fmt(s.totalRevenue)}`} icon="💰" sub={`$${fmt(s.monthRevenue)} this month`} />
        <Stat label="Total Orders" value={s.totalOrders||0} icon="🛒" sub={`${s.pendingOrders||0} pending`} color={S.warning} />
        <Stat label="Customers" value={s.totalCustomers||0} icon="👥" color={S.info} />
        <Stat label="Completed" value={s.completedOrders||0} icon="✅" color={S.success} />
      </div>
      <Card>
        <div style={{ fontSize:14, fontWeight:600, color:S.text, marginBottom:16 }}>Recent Orders</div>
        {s.recentOrders?.length ? (
          <Table
            cols={['Order #','Customer','Amount','Payment','Status','Date']}
            rows={s.recentOrders}
            renderRow={o => <>
              <TD><span style={{ color:S.accent, fontFamily:'monospace', fontSize:12 }}>{o.orderNumber}</span></TD>
              <TD>{o.customerName || '–'}</TD>
              <TD>${(o.total||0).toFixed(2)}</TD>
              <TD><Badge>{o.paymentMethod}</Badge></TD>
              <TD><Badge color={statusColor(o.status)}>{o.status}</Badge></TD>
              <TD muted>{fmtDate(o.createdAt)}</TD>
            </>}
          />
        ) : <div style={{ color:S.muted, fontSize:13 }}>No orders yet</div>}
      </Card>
    </PageWrap>
  );
}

// ─── PRODUCTS ─────────────────────────────────────────────────────────────────
function Products() {
  const { addToast } = useToastStore();
  const [products, setProducts] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name:'', category:'games', price:'', comparePrice:'', description:'', shortDescription:'', sku:'', stock:'', badge:'', featured:false, active:true, deliveryType:'instant', deliveryInstructions:'', tags:'', region:'Global', platform:'' });

  const load = useCallback(async () => {
    const r = await api.get(`/api/products?page=${page}&limit=20&search=${search}&adminMode=true`);
    setProducts(r.data.products || []); setTotal(r.data.total || 0);
  }, [page, search]);
  useEffect(() => { load(); }, [load]);

  const openAdd = () => { setEditing(null); setForm({ name:'', category:'games', price:'', comparePrice:'', description:'', shortDescription:'', sku:'', stock:'', badge:'', featured:false, active:true, deliveryType:'instant', deliveryInstructions:'', tags:'', region:'Global', platform:'' }); setModal(true); };
  const openEdit = p => { setEditing(p); setForm({ ...p, price: p.price||'', comparePrice: p.comparePrice||'', stock: p.stock||'', tags: (p.tags||[]).join(', ') }); setModal(true); };
  const save = async () => {
    try {
      const d = { ...form, price: +form.price, comparePrice: form.comparePrice ? +form.comparePrice : undefined, stock: +form.stock, tags: form.tags.split(',').map(t=>t.trim()).filter(Boolean) };
      if (editing) await api.put(`/api/products/${editing._id}`, d);
      else await api.post('/api/products', d);
      addToast(editing ? 'Product updated' : 'Product created', 'success');
      setModal(false); load();
    } catch(e) { addToast(e.response?.data?.message || 'Error', 'error'); }
  };
  const del = async id => { if (!confirm('Delete?')) return; await api.delete(`/api/products/${id}`); load(); };

  const CATS = ['games','gift-cards','software','ai-tools','game-items','accounts','subscriptions','top-up'];
  const f = k => e => setForm(p=>({...p,[k]:e.target.type==='checkbox'?e.target.checked:e.target.value}));

  return (
    <PageWrap title={`Products (${total})`} action={<Btn onClick={openAdd}>+ Add Product</Btn>}>
      <Card>
        <div style={{ display:'flex', gap:12, marginBottom:16 }}>
          <input value={search} onChange={e=>{setSearch(e.target.value);setPage(1);}} placeholder="Search products..." style={{ flex:1, background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'8px 12px', color:S.text, fontSize:13, outline:'none' }} />
        </div>
        <Table
          cols={['Product','Category','Price','Stock','Status','Featured','']}
          rows={products}
          renderRow={p => <>
            <TD><div style={{ display:'flex', alignItems:'center', gap:10 }}>{p.thumbnail && <img src={p.thumbnail} style={{ width:32, height:32, borderRadius:6, objectFit:'cover' }} />}<div><div style={{ fontWeight:600 }}>{p.name}</div><div style={{ fontSize:11, color:S.muted }}>{p.sku}</div></div></div></TD>
            <TD><Badge>{p.category}</Badge></TD>
            <TD>${(p.price||0).toFixed(2)}{p.comparePrice ? <span style={{ color:S.muted, textDecoration:'line-through', marginLeft:6, fontSize:11 }}>${p.comparePrice}</span> : null}</TD>
            <TD>{p.unlimited ? '∞' : (p.keys?.filter(k=>!k.used).length || p.stock || 0)}</TD>
            <TD><Badge color={p.active?S.success:S.muted}>{p.active?'Active':'Inactive'}</Badge></TD>
            <TD>{p.featured?'⭐':'–'}</TD>
            <TD><div style={{ display:'flex', gap:8 }}><Btn size="sm" onClick={()=>openEdit(p)} variant="ghost">Edit</Btn><Btn size="sm" onClick={()=>del(p._id)} variant="danger">Del</Btn></div></TD>
          </>}
        />
        {total > 20 && <div style={{ display:'flex', gap:8, marginTop:16, justifyContent:'center' }}>
          {Array.from({length:Math.ceil(total/20)},(_,i)=>i+1).slice(0,8).map(p=><button key={p} onClick={()=>setPage(p)} style={{ padding:'4px 10px', borderRadius:6, border:`1px solid ${S.border}`, background:p===page?S.accent:'transparent', color:S.text, cursor:'pointer', fontSize:12 }}>{p}</button>)}
        </div>}
      </Card>
      <Modal open={modal} onClose={()=>setModal(false)} title={editing?'Edit Product':'Add Product'} width={560}>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0 16px' }}>
          <div style={{ gridColumn:'1/-1' }}><Input label="Product Name *" value={form.name} onChange={f('name')} /></div>
          <Select label="Category" value={form.category} onChange={f('category')} options={CATS.map(c=>({value:c,label:c}))} />
          <Select label="Delivery Type" value={form.deliveryType} onChange={f('deliveryType')} options={[{value:'instant',label:'Instant Key'},{value:'manual',label:'Manual'},{value:'email',label:'Email'}]} />
          <Input label="Price (USD) *" type="number" value={form.price} onChange={f('price')} />
          <Input label="Compare Price" type="number" value={form.comparePrice} onChange={f('comparePrice')} />
          <Input label="SKU" value={form.sku} onChange={f('sku')} />
          <Input label="Stock" type="number" value={form.stock} onChange={f('stock')} />
          <Input label="Platform" value={form.platform} onChange={f('platform')} />
          <Input label="Region" value={form.region} onChange={f('region')} />
          <Select label="Badge" value={form.badge||''} onChange={f('badge')} options={[{value:'',label:'None'},{value:'HOT',label:'HOT'},{value:'NEW',label:'NEW'},{value:'SALE',label:'SALE'},{value:'TRENDING',label:'TRENDING'},{value:'RARE',label:'RARE'},{value:'BESTSELLER',label:'BESTSELLER'}]} />
          <div style={{ gridColumn:'1/-1' }}><Input label="Short Description" value={form.shortDescription} onChange={f('shortDescription')} /></div>
          <div style={{ gridColumn:'1/-1' }}>
            <div style={{ fontSize:12, color:S.muted, marginBottom:5 }}>Description *</div>
            <textarea value={form.description} onChange={f('description')} rows={3} style={{ width:'100%', background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'9px 12px', color:S.text, fontSize:13, outline:'none', resize:'vertical', boxSizing:'border-box' }} />
          </div>
          <div style={{ gridColumn:'1/-1' }}><Input label="Delivery Instructions" value={form.deliveryInstructions} onChange={f('deliveryInstructions')} /></div>
          <div style={{ gridColumn:'1/-1' }}><Input label="Tags (comma separated)" value={form.tags} onChange={f('tags')} /></div>
          <div style={{ gridColumn:'1/-1', display:'flex', gap:20, marginBottom:14 }}>
            <label style={{ display:'flex', alignItems:'center', gap:6, fontSize:13, color:S.text, cursor:'pointer' }}><input type="checkbox" checked={form.featured} onChange={f('featured')} /> Featured</label>
            <label style={{ display:'flex', alignItems:'center', gap:6, fontSize:13, color:S.text, cursor:'pointer' }}><input type="checkbox" checked={form.active} onChange={f('active')} /> Active</label>
          </div>
        </div>
        <div style={{ display:'flex', gap:10, justifyContent:'flex-end' }}>
          <Btn variant="ghost" onClick={()=>setModal(false)}>Cancel</Btn>
          <Btn onClick={save}>{editing?'Update':'Create'} Product</Btn>
        </div>
      </Modal>
    </PageWrap>
  );
}

// ─── CATEGORIES ───────────────────────────────────────────────────────────────
function Categories() {
  const { addToast } = useToastStore();
  const [cats, setCats] = useState([]);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name:'', slug:'', icon:'', color:'#7c6cff', description:'', image:'', active:true, order:0 });
  const load = () => api.get('/api/admin/categories').then(r => setCats(r.data.categories||[]));
  useEffect(() => { load(); }, []);
  const openAdd = () => { setEditing(null); setForm({ name:'', slug:'', icon:'', color:'#7c6cff', description:'', image:'', active:true, order:0 }); setModal(true); };
  const openEdit = c => { setEditing(c); setForm({ ...c }); setModal(true); };
  const save = async () => {
    try {
      if (!form.slug) form.slug = form.name.toLowerCase().replace(/[^a-z0-9]+/g,'-');
      if (editing) await api.put(`/api/admin/categories/${editing._id}`, form);
      else await api.post('/api/admin/categories', form);
      addToast('Saved', 'success'); setModal(false); load();
    } catch(e) { addToast(e.response?.data?.message||'Error','error'); }
  };
  const del = async id => { if (!confirm('Delete category?')) return; await api.delete(`/api/admin/categories/${id}`); load(); };
  const f = k => e => setForm(p=>({...p,[k]:e.target.type==='checkbox'?e.target.checked:e.target.value}));
  return (
    <PageWrap title="Categories" action={<Btn onClick={openAdd}>+ Add Category</Btn>}>
      <Card>
        <Table cols={['Category','Slug','Icon','Order','Status','']} rows={cats} renderRow={c => <>
          <TD><div style={{ display:'flex', alignItems:'center', gap:8 }}>{c.image && <img src={c.image} style={{ width:28, height:28, borderRadius:6, objectFit:'cover' }} />}<span style={{ fontWeight:600 }}>{c.name}</span></div></TD>
          <TD muted>{c.slug}</TD>
          <TD>{c.icon} {c.color && <span style={{ background:c.color, width:12, height:12, display:'inline-block', borderRadius:3, verticalAlign:'middle', marginLeft:4 }} />}</TD>
          <TD>{c.order}</TD>
          <TD><Badge color={c.active?S.success:S.muted}>{c.active?'Visible':'Hidden'}</Badge></TD>
          <TD><div style={{ display:'flex', gap:8 }}><Btn size="sm" onClick={()=>openEdit(c)} variant="ghost">Edit</Btn><Btn size="sm" onClick={()=>del(c._id)} variant="danger">Del</Btn></div></TD>
        </>} />
      </Card>
      <Modal open={modal} onClose={()=>setModal(false)} title={editing?'Edit Category':'Add Category'}>
        <Input label="Name *" value={form.name} onChange={f('name')} />
        <Input label="Slug" value={form.slug} onChange={f('slug')} placeholder="auto-generated" />
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0 16px' }}>
          <Input label="Icon (emoji)" value={form.icon} onChange={f('icon')} />
          <Input label="Color" type="color" value={form.color} onChange={f('color')} />
          <Input label="Order" type="number" value={form.order} onChange={f('order')} />
          <div style={{ paddingTop:19 }}><label style={{ display:'flex', alignItems:'center', gap:6, fontSize:13, color:S.text, cursor:'pointer' }}><input type="checkbox" checked={form.active} onChange={f('active')} /> Active / Visible</label></div>
        </div>
        <Input label="Image URL" value={form.image} onChange={f('image')} />
        <Input label="Description" value={form.description} onChange={f('description')} />
        <div style={{ display:'flex', gap:10, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={()=>setModal(false)}>Cancel</Btn><Btn onClick={save}>{editing?'Update':'Create'}</Btn></div>
      </Modal>
    </PageWrap>
  );
}

// ─── ORDERS ───────────────────────────────────────────────────────────────────
function Orders() {
  const { addToast } = useToastStore();
  const [orders, setOrders] = useState([]);
  const [total, setTotal] = useState(0);
  const [filter, setFilter] = useState({ status:'', paymentMethod:'', search:'' });
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState(null);
  const [keyModal, setKeyModal] = useState(false);
  const [keyForm, setKeyForm] = useState({ itemIndex:0, key:'' });

  const load = useCallback(() => {
    const q = new URLSearchParams({ page, limit:20, ...filter }).toString();
    api.get(`/api/admin/orders?${q}`).then(r => { setOrders(r.data.orders||[]); setTotal(r.data.total||0); });
  }, [page, filter]);
  useEffect(() => { load(); }, [load]);

  const updateStatus = async (id, status, paymentStatus) => {
    await api.put(`/api/admin/orders/${id}/status`, { status, paymentStatus });
    addToast('Order updated', 'success'); load();
  };
  const deliverKey = async () => {
    await api.post(`/api/admin/orders/${selected._id}/deliver-key`, keyForm);
    addToast('Key delivered', 'success'); setKeyModal(false); load();
  };

  return (
    <PageWrap title={`Orders (${total})`}>
      <Card style={{ marginBottom:16 }}>
        <div style={{ display:'flex', gap:12, flexWrap:'wrap' }}>
          <input value={filter.search} onChange={e=>setFilter(p=>({...p,search:e.target.value}))} placeholder="Search order #, email..." style={{ flex:1, minWidth:180, background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'8px 12px', color:S.text, fontSize:13, outline:'none' }} />
          <select value={filter.status} onChange={e=>setFilter(p=>({...p,status:e.target.value}))} style={{ background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'8px 12px', color:S.text, fontSize:13, outline:'none' }}>
            <option value="">All Status</option>
            {['pending','processing','completed','cancelled','refunded','disputed'].map(s=><option key={s} value={s}>{s}</option>)}
          </select>
          <select value={filter.paymentMethod} onChange={e=>setFilter(p=>({...p,paymentMethod:e.target.value}))} style={{ background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'8px 12px', color:S.text, fontSize:13, outline:'none' }}>
            <option value="">All Gateways</option>
            {['stripe','jazzcash','easypaisa','alfalah','meezan','paypal','crypto_btc','manual'].map(m=><option key={m} value={m}>{m}</option>)}
          </select>
        </div>
      </Card>
      <Card>
        <Table
          cols={['Order #','Customer','Total','Payment','Status','Date','']}
          rows={orders}
          renderRow={o => <>
            <TD><span style={{ color:S.accent, fontFamily:'monospace', fontSize:12 }}>{o.orderNumber}</span></TD>
            <TD><div><div>{o.customerName||o.user?.name||'Guest'}</div><div style={{ fontSize:11, color:S.muted }}>{o.customerEmail||o.user?.email}</div></div></TD>
            <TD>${(o.total||0).toFixed(2)}</TD>
            <TD><Badge>{o.paymentMethod}</Badge></TD>
            <TD>
              <select value={o.status} onChange={e=>updateStatus(o._id,e.target.value,undefined)} style={{ background:'#0a0a14', border:`1px solid ${statusColor(o.status)}44`, borderRadius:6, padding:'3px 8px', color:statusColor(o.status), fontSize:11, outline:'none', cursor:'pointer' }}>
                {['pending','processing','completed','cancelled','refunded','disputed'].map(s=><option key={s} value={s}>{s}</option>)}
              </select>
            </TD>
            <TD muted>{fmtDate(o.createdAt)}</TD>
            <TD>
              <Btn size="sm" variant="ghost" onClick={()=>{ setSelected(o); setKeyModal(true); }}>Key</Btn>
            </TD>
          </>}
        />
        {total > 20 && <div style={{ display:'flex', gap:8, marginTop:16, justifyContent:'center' }}>
          {Array.from({length:Math.min(8,Math.ceil(total/20))},(_,i)=>i+1).map(p=><button key={p} onClick={()=>setPage(p)} style={{ padding:'4px 10px', borderRadius:6, border:`1px solid ${S.border}`, background:p===page?S.accent:'transparent', color:S.text, cursor:'pointer', fontSize:12 }}>{p}</button>)}
        </div>}
      </Card>
      <Modal open={keyModal} onClose={()=>setKeyModal(false)} title="Deliver Key Manually">
        {selected && <div>
          <div style={{ fontSize:13, color:S.muted, marginBottom:16 }}>Order: <span style={{ color:S.text }}>{selected.orderNumber}</span> — {selected.items?.length} item(s)</div>
          <Select label="Item" value={keyForm.itemIndex} onChange={e=>setKeyForm(p=>({...p,itemIndex:+e.target.value}))} options={(selected.items||[]).map((it,i)=>({value:i,label:it.name}))} />
          <Input label="Key / Code to Deliver" value={keyForm.key} onChange={e=>setKeyForm(p=>({...p,key:e.target.value}))} placeholder="Enter the digital key or code" />
          <div style={{ display:'flex', gap:10, justifyContent:'flex-end' }}>
            <Btn variant="ghost" onClick={()=>setKeyModal(false)}>Cancel</Btn>
            <Btn onClick={deliverKey}>Deliver Key</Btn>
          </div>
        </div>}
      </Modal>
    </PageWrap>
  );
}

// ─── CUSTOMERS ────────────────────────────────────────────────────────────────
function Customers() {
  const { addToast } = useToastStore();
  const [users, setUsers] = useState([]);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('customer');
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState(null);
  const [modal, setModal] = useState(false);
  const [editForm, setEditForm] = useState({});

  const load = useCallback(() => {
    api.get(`/api/admin/users?search=${search}&role=${roleFilter}&page=${page}&limit=20`)
      .then(r => { setUsers(r.data.users||[]); setTotal(r.data.total||0); });
  }, [search, roleFilter, page]);
  useEffect(() => { load(); }, [load]);

  const openEdit = u => { setSelected(u); setEditForm({ role:u.role, isActive:u.isActive, isSuspended:u.isSuspended, suspendReason:u.suspendReason||'', isBanned:u.isBanned, banReason:u.banReason||'', notes:u.notes||'' }); setModal(true); };
  const save = async () => {
    try {
      await api.put(`/api/admin/users/${selected._id}`, editForm);
      addToast('User updated', 'success'); setModal(false); load();
    } catch(e) { addToast(e.response?.data?.message||'Error','error'); }
  };
  const f = k => e => setEditForm(p=>({...p,[k]:e.target.type==='checkbox'?e.target.checked:e.target.value}));

  return (
    <PageWrap title={`Customers (${total})`}>
      <Card style={{ marginBottom:16 }}>
        <div style={{ display:'flex', gap:12 }}>
          <input value={search} onChange={e=>{setSearch(e.target.value);setPage(1);}} placeholder="Search name or email..." style={{ flex:1, background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'8px 12px', color:S.text, fontSize:13, outline:'none' }} />
          <select value={roleFilter} onChange={e=>{setRoleFilter(e.target.value);setPage(1);}} style={{ background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'8px 12px', color:S.text, fontSize:13, outline:'none' }}>
            <option value="">All Roles</option>
            {['customer','support','content_manager','manager','admin','super_admin'].map(r=><option key={r} value={r}>{r}</option>)}
          </select>
        </div>
      </Card>
      <Card>
        <Table
          cols={['User','Email','Role','Orders','Spent','Status','']}
          rows={users}
          renderRow={u => <>
            <TD><div style={{ display:'flex', alignItems:'center', gap:8 }}>{u.avatar?<img src={u.avatar} style={{ width:28, height:28, borderRadius:'50%' }} />:<div style={{ width:28, height:28, borderRadius:'50%', background:S.accent+'33', display:'flex', alignItems:'center', justifyContent:'center', fontSize:12 }}>{u.name?.charAt(0).toUpperCase()}</div>}<span style={{ fontWeight:600 }}>{u.name}</span></div></TD>
            <TD muted>{u.email}</TD>
            <TD><Badge color={u.role==='admin'||u.role==='super_admin'?S.danger:u.role==='customer'?S.muted:S.info}>{u.role}</Badge></TD>
            <TD>{u.orderCount||0}</TD>
            <TD>${(u.totalSpent||0).toFixed(2)}</TD>
            <TD><Badge color={u.isBanned?S.danger:u.isSuspended?S.warning:u.isActive?S.success:S.muted}>{u.isBanned?'Banned':u.isSuspended?'Suspended':u.isActive?'Active':'Inactive'}</Badge></TD>
            <TD><Btn size="sm" onClick={()=>openEdit(u)} variant="ghost">Manage</Btn></TD>
          </>}
        />
      </Card>
      <Modal open={modal} onClose={()=>setModal(false)} title={`Manage: ${selected?.name}`}>
        {selected && <>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0 16px' }}>
            <div style={{ gridColumn:'1/-1' }}>
              <Select label="Role" value={editForm.role} onChange={f('role')} options={[{value:'customer',label:'Customer'},{value:'support',label:'Support'},{value:'content_manager',label:'Content Manager'},{value:'manager',label:'Manager'},{value:'admin',label:'Admin'},{value:'super_admin',label:'Super Admin'}]} />
            </div>
            <div style={{ marginBottom:14 }}>
              <label style={{ display:'flex', alignItems:'center', gap:6, fontSize:13, color:S.text, cursor:'pointer', marginBottom:10 }}><input type="checkbox" checked={editForm.isActive} onChange={f('isActive')} /> Account Active</label>
              <label style={{ display:'flex', alignItems:'center', gap:6, fontSize:13, color:S.text, cursor:'pointer', marginBottom:10 }}><input type="checkbox" checked={editForm.isSuspended} onChange={f('isSuspended')} /> Suspended</label>
              <label style={{ display:'flex', alignItems:'center', gap:6, fontSize:13, color:S.danger, cursor:'pointer' }}><input type="checkbox" checked={editForm.isBanned} onChange={f('isBanned')} /> Banned</label>
            </div>
            <div>
              <Input label="Suspend Reason" value={editForm.suspendReason} onChange={f('suspendReason')} />
              <Input label="Ban Reason" value={editForm.banReason} onChange={f('banReason')} />
            </div>
            <div style={{ gridColumn:'1/-1' }}><Input label="Internal Notes" value={editForm.notes} onChange={f('notes')} /></div>
          </div>
          <div style={{ display:'flex', gap:10, justifyContent:'flex-end' }}>
            <Btn variant="ghost" onClick={()=>setModal(false)}>Cancel</Btn>
            <Btn onClick={save}>Save Changes</Btn>
          </div>
        </>}
      </Modal>
    </PageWrap>
  );
}

// ─── SUBSCRIPTIONS ────────────────────────────────────────────────────────────
function Subscriptions() {
  const { addToast } = useToastStore();
  const [tab, setTab] = useState('subs');
  const [subs, setSubs] = useState([]);
  const [plans, setPlans] = useState([]);
  const [modal, setModal] = useState(false);
  const [planModal, setPlanModal] = useState(false);
  const [editingPlan, setEditingPlan] = useState(null);
  const [planForm, setPlanForm] = useState({ name:'', type:'iptv', interval:'monthly', price:'', comparePrice:'', description:'', features:'', autoRenew:true, trialDays:0, active:true });

  const loadSubs = () => api.get('/api/subscriptions/admin/subscriptions').then(r=>setSubs(r.data.subscriptions||[]));
  const loadPlans = () => api.get('/api/subscriptions/admin/plans').then(r=>setPlans(r.data.plans||[]));
  useEffect(() => { loadSubs(); loadPlans(); }, []);

  const openPlanEdit = p => { setEditingPlan(p); setPlanForm({ ...p, features:(p.features||[]).join('\n'), price:p.price||'', comparePrice:p.comparePrice||'' }); setPlanModal(true); };
  const openPlanAdd = () => { setEditingPlan(null); setPlanForm({ name:'', type:'iptv', interval:'monthly', price:'', comparePrice:'', description:'', features:'', autoRenew:true, trialDays:0, active:true }); setPlanModal(true); };
  const savePlan = async () => {
    try {
      const d = { ...planForm, price:+planForm.price, comparePrice:planForm.comparePrice?+planForm.comparePrice:undefined, features:planForm.features.split('\n').map(f=>f.trim()).filter(Boolean) };
      if (editingPlan) await api.put(`/api/subscriptions/admin/plans/${editingPlan._id}`, d);
      else await api.post('/api/subscriptions/admin/plans', d);
      addToast('Plan saved','success'); setPlanModal(false); loadPlans();
    } catch(e) { addToast(e.response?.data?.message||'Error','error'); }
  };
  const delPlan = async id => { if (!confirm('Delete plan?')) return; await api.delete(`/api/subscriptions/admin/plans/${id}`); loadPlans(); };
  const pf = k => e => setPlanForm(p=>({...p,[k]:e.target.type==='checkbox'?e.target.checked:e.target.value}));

  return (
    <PageWrap title="Subscriptions" action={
      <div style={{ display:'flex', gap:8 }}>
        <button onClick={()=>setTab('subs')} style={{ padding:'8px 16px', borderRadius:8, border:`1px solid ${tab==='subs'?S.accent:S.border}`, background:tab==='subs'?`${S.accent}22`:'transparent', color:tab==='subs'?S.accent:S.muted, fontSize:12, cursor:'pointer' }}>Subscriptions</button>
        <button onClick={()=>setTab('plans')} style={{ padding:'8px 16px', borderRadius:8, border:`1px solid ${tab==='plans'?S.accent:S.border}`, background:tab==='plans'?`${S.accent}22`:'transparent', color:tab==='plans'?S.accent:S.muted, fontSize:12, cursor:'pointer' }}>Plans</button>
        {tab==='plans'&&<Btn onClick={openPlanAdd}>+ Add Plan</Btn>}
      </div>
    }>
      {tab==='subs'&&<Card>
        <Table cols={['User','Plan','Type','Interval','Status','Expires','']} rows={subs} renderRow={s => <>
          <TD><div><div>{s.user?.name||'–'}</div><div style={{ fontSize:11, color:S.muted }}>{s.user?.email}</div></div></TD>
          <TD>{s.planName||s.plan?.name||'–'}</TD>
          <TD><Badge>{s.plan?.type||'–'}</Badge></TD>
          <TD><Badge color={S.info}>{s.planInterval||s.plan?.interval}</Badge></TD>
          <TD><Badge color={statusColor(s.status)}>{s.status}</Badge></TD>
          <TD muted>{fmtDate(s.endDate)}</TD>
          <TD>
            <select value={s.status} onChange={async e=>{ await api.put(`/api/subscriptions/admin/subscriptions/${s._id}`,{status:e.target.value}); loadSubs(); }} style={{ background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:6, padding:'3px 8px', color:S.text, fontSize:11, outline:'none', cursor:'pointer' }}>
              {['active','cancelled','expired','paused'].map(v=><option key={v} value={v}>{v}</option>)}
            </select>
          </TD>
        </>} />
      </Card>}
      {tab==='plans'&&<Card>
        <Table cols={['Plan','Type','Interval','Price','Active','']} rows={plans} renderRow={p => <>
          <TD><span style={{ fontWeight:600 }}>{p.name}</span></TD>
          <TD><Badge>{p.type}</Badge></TD>
          <TD><Badge color={S.info}>{p.interval}</Badge></TD>
          <TD>${(p.price||0).toFixed(2)}</TD>
          <TD><Badge color={p.active?S.success:S.muted}>{p.active?'Yes':'No'}</Badge></TD>
          <TD><div style={{ display:'flex', gap:8 }}><Btn size="sm" onClick={()=>openPlanEdit(p)} variant="ghost">Edit</Btn><Btn size="sm" onClick={()=>delPlan(p._id)} variant="danger">Del</Btn></div></TD>
        </>} />
      </Card>}
      <Modal open={planModal} onClose={()=>setPlanModal(false)} title={editingPlan?'Edit Plan':'Add Plan'}>
        <Input label="Plan Name *" value={planForm.name} onChange={pf('name')} />
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0 16px' }}>
          <Select label="Type" value={planForm.type} onChange={pf('type')} options={[{value:'iptv',label:'IPTV'},{value:'gaming',label:'Gaming'},{value:'membership',label:'Membership'},{value:'software',label:'Software'}]} />
          <Select label="Interval" value={planForm.interval} onChange={pf('interval')} options={[{value:'monthly',label:'Monthly'},{value:'quarterly',label:'Quarterly'},{value:'annual',label:'Annual'},{value:'lifetime',label:'Lifetime'}]} />
          <Input label="Price *" type="number" value={planForm.price} onChange={pf('price')} />
          <Input label="Compare Price" type="number" value={planForm.comparePrice} onChange={pf('comparePrice')} />
          <Input label="Trial Days" type="number" value={planForm.trialDays} onChange={pf('trialDays')} />
          <div style={{ paddingTop:19 }}><label style={{ display:'flex', alignItems:'center', gap:6, fontSize:13, color:S.text, cursor:'pointer', marginBottom:10 }}><input type="checkbox" checked={planForm.autoRenew} onChange={pf('autoRenew')} /> Auto-Renew</label><label style={{ display:'flex', alignItems:'center', gap:6, fontSize:13, color:S.text, cursor:'pointer' }}><input type="checkbox" checked={planForm.active} onChange={pf('active')} /> Active</label></div>
        </div>
        <Input label="Description" value={planForm.description} onChange={pf('description')} />
        <div>
          <div style={{ fontSize:12, color:S.muted, marginBottom:5 }}>Features (one per line)</div>
          <textarea value={planForm.features} onChange={pf('features')} rows={4} style={{ width:'100%', background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'9px 12px', color:S.text, fontSize:13, outline:'none', resize:'vertical', boxSizing:'border-box' }} />
        </div>
        <div style={{ display:'flex', gap:10, justifyContent:'flex-end', marginTop:14 }}>
          <Btn variant="ghost" onClick={()=>setPlanModal(false)}>Cancel</Btn>
          <Btn onClick={savePlan}>{editingPlan?'Update':'Create'} Plan</Btn>
        </div>
      </Modal>
    </PageWrap>
  );
}

// ─── INVENTORY ────────────────────────────────────────────────────────────────
function Inventory() {
  const { addToast } = useToastStore();
  const [inventory, setInventory] = useState([]);
  const [selected, setSelected] = useState(null);
  const [keys, setKeys] = useState('');
  const load = () => api.get('/api/admin/inventory').then(r=>setInventory(r.data.inventory||[]));
  useEffect(() => { load(); }, []);
  const addKeys = async () => {
    if (!selected || !keys.trim()) return;
    await api.post(`/api/admin/inventory/${selected._id}/add-keys`, { keys });
    addToast('Keys added', 'success'); setSelected(null); setKeys(''); load();
  };
  return (
    <PageWrap title="Inventory — Digital Keys">
      <div style={{ display:'grid', gridTemplateColumns:'1fr 340px', gap:20, alignItems:'start' }}>
        <Card>
          <Table cols={['Product','Category','Available','Used','Total','']} rows={inventory} renderRow={p => <>
            <TD><div style={{ display:'flex', alignItems:'center', gap:8 }}>{p.thumbnail&&<img src={p.thumbnail} style={{ width:28, height:28, borderRadius:6, objectFit:'cover' }}/>}<span style={{ fontWeight:600 }}>{p.name}</span></div></TD>
            <TD><Badge>{p.category}</Badge></TD>
            <TD><span style={{ color: p.stock===0?S.danger:p.stock<5?S.warning:S.success, fontWeight:600 }}>{p.unlimited?'∞':p.stock}</span></TD>
            <TD muted>{p.usedKeys}</TD>
            <TD muted>{p.totalKeys}</TD>
            <TD><Btn size="sm" onClick={()=>setSelected(p)}>Add Keys</Btn></TD>
          </>} />
        </Card>
        <Card>
          <div style={{ fontSize:14, fontWeight:600, color:S.text, marginBottom:16 }}>Add Keys</div>
          {selected ? <>
            <div style={{ fontSize:13, color:S.accent, marginBottom:12 }}>➤ {selected.name}</div>
            <div style={{ fontSize:12, color:S.muted, marginBottom:6 }}>Keys (one per line)</div>
            <textarea value={keys} onChange={e=>setKeys(e.target.value)} rows={10} placeholder={"KEY-XXXX-YYYY\nKEY-XXXX-ZZZZ\n..."} style={{ width:'100%', background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'9px 12px', color:S.text, fontSize:12, outline:'none', resize:'vertical', boxSizing:'border-box', fontFamily:'monospace' }} />
            <div style={{ display:'flex', gap:8, marginTop:12 }}>
              <Btn variant="ghost" onClick={()=>setSelected(null)}>Cancel</Btn>
              <Btn onClick={addKeys}>Add {keys.split('\n').filter(l=>l.trim()).length} Keys</Btn>
            </div>
          </> : <div style={{ color:S.muted, fontSize:13, padding:'20px 0', textAlign:'center' }}>Select a product to add keys</div>}
        </Card>
      </div>
    </PageWrap>
  );
}

// ─── HOMEPAGE EDITOR ──────────────────────────────────────────────────────────
function Homepage() {
  const { addToast } = useToastStore();
  const [tab, setTab] = useState('blocks');
  const [blocks, setBlocks] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [banners, setBanners] = useState([]);
  const [modal, setModal] = useState(false);
  const [modalType, setModalType] = useState('block');
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({});

  const loadBlocks = () => api.get('/api/homepage/admin/blocks').then(r=>setBlocks(r.data.blocks||[]));
  const loadAnn = () => api.get('/api/homepage/admin/announcements').then(r=>setAnnouncements(r.data.announcements||[]));
  const loadBanners = () => api.get('/api/homepage/admin/banners').then(r=>setBanners(r.data.banners||[]));
  useEffect(() => { loadBlocks(); loadAnn(); loadBanners(); }, []);

  const openBanner = b => { setEditing(b); setForm(b||{ title:'', subtitle:'', image:'', link:'', badge:'', ctaText:'', type:'promo', active:true, order:0 }); setModalType('banner'); setModal(true); };
  const openAnn = a => { setEditing(a); setForm(a||{ text:'', link:'', type:'info', active:true }); setModalType('announcement'); setModal(true); };
  const openBlock = bl => { setEditing(bl); setForm(bl||{ key:'', label:'', type:'custom', active:true, order:0 }); setModalType('block'); setModal(true); };

  const save = async () => {
    try {
      if (modalType === 'banner') {
        if (editing) await api.put(`/api/homepage/admin/banners/${editing._id}`, form);
        else await api.post('/api/homepage/admin/banners', form);
        loadBanners();
      } else if (modalType === 'announcement') {
        if (editing) await api.put(`/api/homepage/admin/announcements/${editing._id}`, form);
        else await api.post('/api/homepage/admin/announcements', form);
        loadAnn();
      } else {
        if (editing) await api.put(`/api/homepage/admin/blocks/${editing.key}`, form);
        else await api.post('/api/homepage/admin/blocks', form);
        loadBlocks();
      }
      addToast('Saved','success'); setModal(false);
    } catch(e) { addToast(e.response?.data?.message||'Error','error'); }
  };
  const del = async (type, id) => {
    if (!confirm('Delete?')) return;
    if (type==='banner') { await api.delete(`/api/homepage/admin/banners/${id}`); loadBanners(); }
    else if (type==='announcement') { await api.delete(`/api/homepage/admin/announcements/${id}`); loadAnn(); }
    else { await api.delete(`/api/homepage/admin/blocks/${id}`); loadBlocks(); }
  };
  const toggle = async (type, id, active) => {
    if (type==='banner') { await api.put(`/api/homepage/admin/banners/${id}`,{active}); loadBanners(); }
    else if (type==='announcement') { await api.put(`/api/homepage/admin/announcements/${id}`,{active}); loadAnn(); }
    else { await api.put(`/api/homepage/admin/blocks/${id.key||id}`,{active}); loadBlocks(); }
  };
  const f = k => e => setForm(p=>({...p,[k]:e.target.type==='checkbox'?e.target.checked:e.target.value}));

  return (
    <PageWrap title="Homepage Content Manager" action={
      <div style={{ display:'flex', gap:8 }}>
        {['blocks','banners','announcements'].map(t=><button key={t} onClick={()=>setTab(t)} style={{ padding:'7px 14px', borderRadius:8, border:`1px solid ${tab===t?S.accent:S.border}`, background:tab===t?`${S.accent}22`:'transparent', color:tab===t?S.accent:S.muted, fontSize:12, cursor:'pointer', textTransform:'capitalize' }}>{t}</button>)}
      </div>
    }>
      {tab==='blocks'&&<>
        <div style={{ display:'flex', justifyContent:'flex-end', marginBottom:12 }}><Btn onClick={()=>openBlock(null)}>+ Add Block</Btn></div>
        <Card>
          <Table cols={['Key','Label','Type','Order','Active','']} rows={blocks} renderRow={bl=><>
            <TD><span style={{ fontFamily:'monospace', fontSize:12, color:S.accent }}>{bl.key}</span></TD>
            <TD>{bl.label}</TD>
            <TD><Badge>{bl.type}</Badge></TD>
            <TD>{bl.order}</TD>
            <TD><button onClick={()=>toggle('block',bl,!bl.active)} style={{ background:bl.active?`${S.success}22`:`${S.muted}22`, border:`1px solid ${bl.active?S.success:S.muted}44`, borderRadius:20, padding:'2px 10px', color:bl.active?S.success:S.muted, fontSize:11, cursor:'pointer' }}>{bl.active?'On':'Off'}</button></TD>
            <TD><div style={{ display:'flex', gap:8 }}><Btn size="sm" onClick={()=>openBlock(bl)} variant="ghost">Edit</Btn><Btn size="sm" onClick={()=>del('block',bl._id)} variant="danger">Del</Btn></div></TD>
          </>} />
        </Card>
      </>}
      {tab==='banners'&&<>
        <div style={{ display:'flex', justifyContent:'flex-end', marginBottom:12 }}><Btn onClick={()=>openBanner(null)}>+ Add Banner</Btn></div>
        <Card>
          <Table cols={['Title','Type','CTA','Active','']} rows={banners} renderRow={b=><>
            <TD><div><div style={{ fontWeight:600 }}>{b.title}</div><div style={{ fontSize:11, color:S.muted }}>{b.subtitle}</div></div></TD>
            <TD><Badge>{b.type}</Badge></TD>
            <TD muted>{b.ctaText}</TD>
            <TD><button onClick={()=>toggle('banner',b._id,!b.active)} style={{ background:b.active?`${S.success}22`:`${S.muted}22`, border:`1px solid ${b.active?S.success:S.muted}44`, borderRadius:20, padding:'2px 10px', color:b.active?S.success:S.muted, fontSize:11, cursor:'pointer' }}>{b.active?'On':'Off'}</button></TD>
            <TD><div style={{ display:'flex', gap:8 }}><Btn size="sm" onClick={()=>openBanner(b)} variant="ghost">Edit</Btn><Btn size="sm" onClick={()=>del('banner',b._id)} variant="danger">Del</Btn></div></TD>
          </>} />
        </Card>
      </>}
      {tab==='announcements'&&<>
        <div style={{ display:'flex', justifyContent:'flex-end', marginBottom:12 }}><Btn onClick={()=>openAnn(null)}>+ Add Announcement</Btn></div>
        <Card>
          <Table cols={['Text','Type','Active','']} rows={announcements} renderRow={a=><>
            <TD style={{ maxWidth:360, overflow:'hidden', textOverflow:'ellipsis' }}>{a.text}</TD>
            <TD><Badge color={{ info:S.info, success:S.success, warning:S.warning, danger:S.danger }[a.type]||S.muted}>{a.type}</Badge></TD>
            <TD><button onClick={()=>toggle('announcement',a._id,!a.active)} style={{ background:a.active?`${S.success}22`:`${S.muted}22`, border:`1px solid ${a.active?S.success:S.muted}44`, borderRadius:20, padding:'2px 10px', color:a.active?S.success:S.muted, fontSize:11, cursor:'pointer' }}>{a.active?'On':'Off'}</button></TD>
            <TD><div style={{ display:'flex', gap:8 }}><Btn size="sm" onClick={()=>openAnn(a)} variant="ghost">Edit</Btn><Btn size="sm" onClick={()=>del('announcement',a._id)} variant="danger">Del</Btn></div></TD>
          </>} />
        </Card>
      </>}
      <Modal open={modal} onClose={()=>setModal(false)} title={editing?`Edit ${modalType}`:`Add ${modalType}`}>
        {modalType==='block'&&<>
          <Input label="Key (unique identifier)" value={form.key||''} onChange={f('key')} />
          <Input label="Label" value={form.label||''} onChange={f('label')} />
          <Select label="Type" value={form.type||'custom'} onChange={f('type')} options={['hero','featured','categories','promo','announcements','slider','custom'].map(v=>({value:v,label:v}))} />
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0 16px' }}>
            <Input label="Order" type="number" value={form.order||0} onChange={f('order')} />
            <div style={{ paddingTop:19 }}><label style={{ display:'flex', alignItems:'center', gap:6, fontSize:13, color:S.text, cursor:'pointer' }}><input type="checkbox" checked={form.active} onChange={f('active')} /> Active</label></div>
          </div>
        </>}
        {modalType==='banner'&&<>
          <Input label="Title" value={form.title||''} onChange={f('title')} />
          <Input label="Subtitle" value={form.subtitle||''} onChange={f('subtitle')} />
          <Input label="Image URL" value={form.image||''} onChange={f('image')} />
          <Input label="Link URL" value={form.link||''} onChange={f('link')} />
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0 16px' }}>
            <Input label="Badge Text" value={form.badge||''} onChange={f('badge')} />
            <Input label="CTA Button Text" value={form.ctaText||''} onChange={f('ctaText')} />
            <Select label="Type" value={form.type||'promo'} onChange={f('type')} options={['hero','promo','announcement','slider'].map(v=>({value:v,label:v}))} />
            <Input label="Order" type="number" value={form.order||0} onChange={f('order')} />
            <Input label="Start Date" type="date" value={form.startDate?.split?.('T')[0]||''} onChange={f('startDate')} />
            <Input label="End Date" type="date" value={form.endDate?.split?.('T')[0]||''} onChange={f('endDate')} />
          </div>
          <label style={{ display:'flex', alignItems:'center', gap:6, fontSize:13, color:S.text, cursor:'pointer', marginBottom:14 }}><input type="checkbox" checked={form.active} onChange={f('active')} /> Active</label>
        </>}
        {modalType==='announcement'&&<>
          <div style={{ marginBottom:14 }}>
            <div style={{ fontSize:12, color:S.muted, marginBottom:5 }}>Announcement Text *</div>
            <textarea value={form.text||''} onChange={f('text')} rows={3} style={{ width:'100%', background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'9px 12px', color:S.text, fontSize:13, outline:'none', resize:'vertical', boxSizing:'border-box' }} />
          </div>
          <Select label="Type" value={form.type||'info'} onChange={f('type')} options={['info','success','warning','danger'].map(v=>({value:v,label:v}))} />
          <Input label="Link URL (optional)" value={form.link||''} onChange={f('link')} />
          <Input label="Expires At (optional)" type="date" value={form.expiresAt?.split?.('T')[0]||''} onChange={f('expiresAt')} />
          <label style={{ display:'flex', alignItems:'center', gap:6, fontSize:13, color:S.text, cursor:'pointer', marginBottom:14 }}><input type="checkbox" checked={form.active} onChange={f('active')} /> Active</label>
        </>}
        <div style={{ display:'flex', gap:10, justifyContent:'flex-end' }}>
          <Btn variant="ghost" onClick={()=>setModal(false)}>Cancel</Btn>
          <Btn onClick={save}>{editing?'Update':'Create'}</Btn>
        </div>
      </Modal>
    </PageWrap>
  );
}

// ─── COUPONS ──────────────────────────────────────────────────────────────────
function Coupons() {
  const { addToast } = useToastStore();
  const [coupons, setCoupons] = useState([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ code:'', type:'percent', value:'', minOrderAmount:'', maxUses:'', expiresAt:'', active:true });
  const load = () => api.get('/api/admin/coupons').then(r=>setCoupons(r.data.coupons||[]));
  useEffect(() => { load(); }, []);
  const save = async () => {
    try {
      await api.post('/api/admin/coupons', { ...form, value:+form.value, minOrderAmount:+form.minOrderAmount||0, maxUses:form.maxUses?+form.maxUses:null });
      addToast('Coupon created','success'); setModal(false); load();
    } catch(e) { addToast(e.response?.data?.message||'Error','error'); }
  };
  const del = async id => { if (!confirm('Delete coupon?')) return; await api.delete(`/api/admin/coupons/${id}`); load(); };
  const toggle = async (id, active) => { await api.put(`/api/admin/coupons/${id}`,{active}); load(); };
  const f = k => e => setForm(p=>({...p,[k]:e.target.type==='checkbox'?e.target.checked:e.target.value}));
  return (
    <PageWrap title="Coupons" action={<Btn onClick={()=>setModal(true)}>+ Create Coupon</Btn>}>
      <Card>
        <Table cols={['Code','Type','Value','Min Order','Uses','Expires','Active','']} rows={coupons} renderRow={c=><>
          <TD><span style={{ fontFamily:'monospace', fontWeight:700, color:S.accent, letterSpacing:'.08em' }}>{c.code}</span></TD>
          <TD><Badge>{c.type}</Badge></TD>
          <TD style={{ color:S.success, fontWeight:600 }}>{c.type==='percent'?`${c.value}%`:`$${c.value}`}</TD>
          <TD muted>{c.minOrderAmount?`$${c.minOrderAmount}`:'–'}</TD>
          <TD muted>{c.usedCount||0}{c.maxUses?`/${c.maxUses}`:' (∞)'}</TD>
          <TD muted>{c.expiresAt?fmtDate(c.expiresAt):'Never'}</TD>
          <TD><button onClick={()=>toggle(c._id,!c.active)} style={{ background:c.active?`${S.success}22`:`${S.muted}22`, border:`1px solid ${c.active?S.success:S.muted}44`, borderRadius:20, padding:'2px 10px', color:c.active?S.success:S.muted, fontSize:11, cursor:'pointer' }}>{c.active?'On':'Off'}</button></TD>
          <TD><Btn size="sm" onClick={()=>del(c._id)} variant="danger">Del</Btn></TD>
        </>} />
      </Card>
      <Modal open={modal} onClose={()=>setModal(false)} title="Create Coupon">
        <Input label="Coupon Code *" value={form.code} onChange={f('code')} placeholder="SAVE20" />
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0 16px' }}>
          <Select label="Discount Type" value={form.type} onChange={f('type')} options={[{value:'percent',label:'Percentage %'},{value:'fixed',label:'Fixed Amount $'}]} />
          <Input label="Discount Value *" type="number" value={form.value} onChange={f('value')} placeholder={form.type==='percent'?'20':'5.00'} />
          <Input label="Min Order Amount" type="number" value={form.minOrderAmount} onChange={f('minOrderAmount')} placeholder="0" />
          <Input label="Max Uses (blank = ∞)" type="number" value={form.maxUses} onChange={f('maxUses')} />
          <Input label="Expires At" type="date" value={form.expiresAt} onChange={f('expiresAt')} />
          <div style={{ paddingTop:19 }}><label style={{ display:'flex', alignItems:'center', gap:6, fontSize:13, color:S.text, cursor:'pointer' }}><input type="checkbox" checked={form.active} onChange={f('active')} /> Active</label></div>
        </div>
        <div style={{ display:'flex', gap:10, justifyContent:'flex-end', marginTop:4 }}>
          <Btn variant="ghost" onClick={()=>setModal(false)}>Cancel</Btn>
          <Btn onClick={save}>Create Coupon</Btn>
        </div>
      </Modal>
    </PageWrap>
  );
}

// ─── PAYMENT GATEWAYS ─────────────────────────────────────────────────────────
function Payments() {
  const { addToast } = useToastStore();
  const [gateways, setGateways] = useState([]);
  const [gatewayStats, setGatewayStats] = useState([]);
  const load = () => {
    api.get('/api/admin/gateways').then(r=>setGateways(r.data.gateways||[]));
    api.get('/api/analytics/gateways').then(r=>setGatewayStats(r.data.gateways||[])).catch(()=>{});
  };
  useEffect(() => { load(); }, []);
  const toggle = async (id, enabled) => {
    await api.put(`/api/admin/gateways/${id}/toggle`, { enabled });
    addToast(`Gateway ${enabled?'enabled':'disabled'}`, 'success'); load();
  };
  const regions = [...new Set(gateways.map(g=>g.region))];
  return (
    <PageWrap title="Payment Gateways">
      <div style={{ fontSize:12, color:S.muted, background:`${S.warning}15`, border:`1px solid ${S.warning}30`, borderRadius:8, padding:'10px 14px', marginBottom:20 }}>
        ⚠️ API keys and credentials are managed via environment variables on Render. Only gateway visibility is controlled here.
      </div>
      {regions.map(region => (
        <div key={region} style={{ marginBottom:24 }}>
          <div style={{ fontSize:12, fontWeight:600, color:S.muted, textTransform:'uppercase', letterSpacing:'.08em', marginBottom:12 }}>{region}</div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(220px,1fr))', gap:12 }}>
            {gateways.filter(g=>g.region===region).map(gw => {
              const stat = gatewayStats.find(s=>s._id===gw.id);
              return (
                <div key={gw.id} style={{ background:S.panel, border:`1px solid ${gw.enabled?S.border:S.border+'88'}`, borderRadius:12, padding:16, opacity:gw.enabled?1:.6 }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                      <span style={{ fontSize:22 }}>{gw.logo}</span>
                      <span style={{ fontSize:14, fontWeight:600, color:S.text }}>{gw.label}</span>
                    </div>
                    <button onClick={()=>toggle(gw.id,!gw.enabled)} style={{ position:'relative', width:40, height:22, borderRadius:11, border:'none', background:gw.enabled?S.success:'#333', cursor:gw.enabled||gw.id==='manual'?'default':'pointer', transition:'all .2s' }} disabled={gw.id==='manual'}>
                      <div style={{ position:'absolute', top:3, left:gw.enabled?20:3, width:16, height:16, borderRadius:'50%', background:'#fff', transition:'all .2s' }} />
                    </button>
                  </div>
                  {stat && <div style={{ fontSize:11, color:S.muted }}>
                    <div>Revenue: <span style={{ color:S.success }}>${(stat.totalRevenue||0).toFixed(0)}</span></div>
                    <div>Orders: {stat.paidCount} paid · {stat.failedCount} failed</div>
                    <div>Success: <span style={{ color:stat.successRate>70?S.success:S.warning }}>{stat.successRate}%</span></div>
                  </div>}
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </PageWrap>
  );
}

// ─── SUPPORT ──────────────────────────────────────────────────────────────────
function Support() {
  const { addToast } = useToastStore();
  const [tickets, setTickets] = useState([]);
  const [total, setTotal] = useState(0);
  const [stats, setStats] = useState({});
  const [filter, setFilter] = useState({ status:'', priority:'' });
  const [selected, setSelected] = useState(null);
  const [reply, setReply] = useState('');
  const load = useCallback(() => {
    api.get(`/api/support/admin?status=${filter.status}&priority=${filter.priority}&limit=30`)
      .then(r=>{ setTickets(r.data.tickets||[]); setTotal(r.data.total||0); });
    api.get('/api/support/admin/stats/overview').then(r=>setStats(r.data.stats||{}));
  }, [filter]);
  useEffect(() => { load(); }, [load]);
  const open = async id => { const r = await api.get(`/api/support/admin/${id}`); setSelected(r.data.ticket); };
  const updateTicket = async (id, data) => { await api.put(`/api/support/admin/${id}`, data); load(); if (selected?._id===id) open(id); };
  const sendReply = async () => {
    if (!reply.trim()) return;
    await api.post(`/api/support/admin/${selected._id}/reply`, { message:reply });
    addToast('Reply sent','success'); setReply(''); open(selected._id);
  };
  const priorityColor = p => ({ low:S.muted, medium:S.info, high:S.warning, urgent:S.danger })[p];

  return (
    <PageWrap title={`Support Tickets (${total})`}>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:20 }}>
        <Stat label="Open" value={stats.open||0} icon="📬" color={S.warning} />
        <Stat label="In Progress" value={stats.in_progress||0} icon="🔧" color={S.info} />
        <Stat label="Resolved" value={stats.resolved||0} icon="✅" color={S.success} />
        <Stat label="Urgent" value={stats.urgent||0} icon="🚨" color={S.danger} />
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 420px', gap:20 }}>
        <Card>
          <div style={{ display:'flex', gap:10, marginBottom:14 }}>
            <select value={filter.status} onChange={e=>setFilter(p=>({...p,status:e.target.value}))} style={{ background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'7px 12px', color:S.text, fontSize:12, outline:'none' }}>
              <option value="">All Status</option>
              {['open','in_progress','waiting','resolved','closed'].map(s=><option key={s} value={s}>{s}</option>)}
            </select>
            <select value={filter.priority} onChange={e=>setFilter(p=>({...p,priority:e.target.value}))} style={{ background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'7px 12px', color:S.text, fontSize:12, outline:'none' }}>
              <option value="">All Priority</option>
              {['low','medium','high','urgent'].map(s=><option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <Table cols={['Ticket','User','Category','Priority','Status','Date']} rows={tickets} renderRow={t=><>
            <TD><span onClick={()=>open(t._id)} style={{ color:S.accent, cursor:'pointer', fontFamily:'monospace', fontSize:12 }}>{t.ticketNumber}</span><div style={{ fontSize:11, color:S.muted }}>{t.subject.slice(0,30)}...</div></TD>
            <TD muted>{t.user?.name||t.guestName||'Guest'}</TD>
            <TD><Badge>{t.category}</Badge></TD>
            <TD><Badge color={priorityColor(t.priority)}>{t.priority}</Badge></TD>
            <TD>
              <select value={t.status} onChange={e=>updateTicket(t._id,{status:e.target.value})} style={{ background:'#0a0a14', border:`1px solid ${statusColor(t.status)}44`, borderRadius:6, padding:'2px 8px', color:statusColor(t.status), fontSize:11, outline:'none' }}>
                {['open','in_progress','waiting','resolved','closed'].map(s=><option key={s} value={s}>{s}</option>)}
              </select>
            </TD>
            <TD muted>{fmtDate(t.createdAt)}</TD>
          </>} />
        </Card>
        <Card>
          {selected ? <>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
              <div>
                <div style={{ fontSize:12, color:S.accent, fontFamily:'monospace' }}>{selected.ticketNumber}</div>
                <div style={{ fontSize:14, fontWeight:600, color:S.text, marginTop:2 }}>{selected.subject}</div>
              </div>
              <Badge color={priorityColor(selected.priority)}>{selected.priority}</Badge>
            </div>
            <div style={{ maxHeight:300, overflowY:'auto', marginBottom:16, display:'flex', flexDirection:'column', gap:10 }}>
              {(selected.messages||[]).map((m,i) => (
                <div key={i} style={{ background: m.senderRole==='customer'?'#1a1a2e':'#0f1a0f', borderRadius:8, padding:'10px 12px' }}>
                  <div style={{ fontSize:11, color:S.muted, marginBottom:4 }}>{m.senderName} ({m.senderRole}) · {fmtDate(m.createdAt)}</div>
                  <div style={{ fontSize:13, color:S.text, lineHeight:1.5 }}>{m.content}</div>
                </div>
              ))}
            </div>
            <textarea value={reply} onChange={e=>setReply(e.target.value)} placeholder="Type your reply..." rows={3} style={{ width:'100%', background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'9px 12px', color:S.text, fontSize:13, outline:'none', resize:'none', boxSizing:'border-box', marginBottom:10 }} />
            <div style={{ display:'flex', gap:8 }}>
              <Btn onClick={sendReply} style={{ flex:1 }}>Send Reply</Btn>
              <Btn onClick={()=>updateTicket(selected._id,{status:'resolved'})} variant="success" size="sm">Resolve</Btn>
              <Btn onClick={()=>updateTicket(selected._id,{status:'closed'})} variant="ghost" size="sm">Close</Btn>
            </div>
          </> : <div style={{ color:S.muted, fontSize:13, padding:'40px 0', textAlign:'center' }}>Click a ticket to view thread</div>}
        </Card>
      </div>
    </PageWrap>
  );
}

// ─── ANALYTICS ────────────────────────────────────────────────────────────────
function Analytics() {
  const [data, setData] = useState(null);
  const [products, setProducts] = useState([]);
  useEffect(() => {
    api.get('/api/analytics/dashboard').then(r=>setData(r.data.stats)).catch(()=>{});
    api.get('/api/analytics/products').then(r=>setProducts(r.data.products||[])).catch(()=>{});
  }, []);
  const d = data || {};

  const barMax = (d.revenueByDay||[]).reduce((m,x)=>Math.max(m,x.revenue),1);

  return (
    <PageWrap title="Analytics">
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:16, marginBottom:24 }}>
        <Stat label="Total Revenue" value={`$${fmt(d.revenue?.total)}`} icon="💰" />
        <Stat label="This Month" value={`$${fmt(d.revenue?.thisMonth)}`} icon="📅" color={S.info} />
        <Stat label="Today" value={`$${fmt(d.revenue?.today)}`} icon="⚡" color={S.success} />
        <Stat label="Active Subscriptions" value={d.activeSubscriptions||0} icon="🔄" color={S.warning} />
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr', gap:20, marginBottom:20 }}>
        <Card>
          <div style={{ fontSize:13, fontWeight:600, color:S.text, marginBottom:16 }}>Revenue – Last 30 Days</div>
          <div style={{ display:'flex', alignItems:'flex-end', gap:3, height:120 }}>
            {(d.revenueByDay||[]).slice(-30).map((r,i)=>(
              <div key={i} title={`${r._id}: $${r.revenue.toFixed(2)}`} style={{ flex:1, background:`${S.accent}88`, borderRadius:'2px 2px 0 0', height:`${Math.max(4,(r.revenue/barMax)*100)}%`, minWidth:4, cursor:'pointer' }} />
            ))}
          </div>
        </Card>
        <Card>
          <div style={{ fontSize:13, fontWeight:600, color:S.text, marginBottom:16 }}>Orders by Status</div>
          {(d.ordersByStatus||[]).map(s=>(
            <div key={s._id} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <div style={{ width:8, height:8, borderRadius:'50%', background:statusColor(s._id) }} />
                <span style={{ fontSize:12, color:S.text, textTransform:'capitalize' }}>{s._id}</span>
              </div>
              <Badge color={statusColor(s._id)}>{s.count}</Badge>
            </div>
          ))}
        </Card>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:20 }}>
        <Card>
          <div style={{ fontSize:13, fontWeight:600, color:S.text, marginBottom:16 }}>Top Products by Sales</div>
          {products.slice(0,8).map((p,i)=>(
            <div key={p._id} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <span style={{ fontSize:11, color:S.muted, width:16 }}>#{i+1}</span>
                <span style={{ fontSize:13, color:S.text }}>{p.name.slice(0,28)}</span>
              </div>
              <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                <Badge color={S.info}>{p.soldCount} sold</Badge>
              </div>
            </div>
          ))}
        </Card>
        <Card>
          <div style={{ fontSize:13, fontWeight:600, color:S.text, marginBottom:16 }}>Payment Gateway Performance</div>
          {(d.ordersByPayment||[]).slice(0,8).map(g=>(
            <div key={g._id} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
              <span style={{ fontSize:12, color:S.text }}>{g._id}</span>
              <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                <span style={{ fontSize:11, color:S.muted }}>{g.count} orders</span>
                <Badge color={S.success}>${(g.revenue||0).toFixed(0)}</Badge>
              </div>
            </div>
          ))}
        </Card>
      </div>
    </PageWrap>
  );
}

// ─── ROLES & STAFF ────────────────────────────────────────────────────────────
function Roles() {
  const { addToast } = useToastStore();
  const [staff, setStaff] = useState([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ name:'', email:'', password:'', role:'support' });
  const load = () => api.get('/api/admin/users?role=support&limit=100').then(r=>{
    api.get('/api/admin/users?role=content_manager&limit=100').then(r2=>{
      api.get('/api/admin/users?role=manager&limit=100').then(r3=>{
        api.get('/api/admin/users?role=admin&limit=100').then(r4=>{
          setStaff([...(r.data.users||[]),...(r2.data.users||[]),...(r3.data.users||[]),...(r4.data.users||[])]);
        });
      });
    });
  });
  useEffect(() => { load(); }, []);
  const createStaff = async () => {
    try {
      await api.post('/api/auth/register', form);
      // update role right after
      const users = await api.get(`/api/admin/users?search=${form.email}`);
      if (users.data.users?.[0]) await api.put(`/api/admin/users/${users.data.users[0]._id}`, { role:form.role });
      addToast('Staff member created','success'); setModal(false); load();
    } catch(e) { addToast(e.response?.data?.message||'Error','error'); }
  };
  const updateRole = async (id, role) => { await api.put(`/api/admin/users/${id}`, { role }); load(); };
  const f = k => e => setForm(p=>({...p,[k]:e.target.value}));

  const ROLES_INFO = [
    { role:'super_admin',     label:'Super Admin',     color:S.danger,   desc:'Full access, manage all admins' },
    { role:'admin',           label:'Admin',            color:S.warning,  desc:'Full access except super_admin controls' },
    { role:'manager',         label:'Manager',          color:S.info,     desc:'Orders, products, customers, analytics' },
    { role:'support',         label:'Support',          color:S.success,  desc:'Support tickets, order lookup' },
    { role:'content_manager', label:'Content Manager',  color:S.accent,   desc:'Products, categories, homepage, banners' },
  ];

  return (
    <PageWrap title="Roles & Staff" action={<Btn onClick={()=>setModal(true)}>+ Add Staff</Btn>}>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:12, marginBottom:24 }}>
        {ROLES_INFO.map(r=>(
          <Card key={r.role}>
            <Badge color={r.color}>{r.label}</Badge>
            <div style={{ fontSize:11, color:S.muted, marginTop:8, lineHeight:1.5 }}>{r.desc}</div>
          </Card>
        ))}
      </div>
      <Card>
        <Table cols={['Staff Member','Email','Role','Status','']} rows={staff} renderRow={u=><>
          <TD><span style={{ fontWeight:600 }}>{u.name}</span></TD>
          <TD muted>{u.email}</TD>
          <TD>
            <select value={u.role} onChange={e=>updateRole(u._id,e.target.value)} style={{ background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:6, padding:'3px 8px', color:S.text, fontSize:11, outline:'none' }}>
              {['support','content_manager','manager','admin'].map(r=><option key={r} value={r}>{r}</option>)}
            </select>
          </TD>
          <TD><Badge color={u.isActive?S.success:S.muted}>{u.isActive?'Active':'Inactive'}</Badge></TD>
          <TD><Btn size="sm" onClick={async()=>{ await api.put(`/api/admin/users/${u._id}`,{isActive:!u.isActive}); load(); }} variant="ghost">{u.isActive?'Deactivate':'Activate'}</Btn></TD>
        </>} />
      </Card>
      <Modal open={modal} onClose={()=>setModal(false)} title="Add Staff Member">
        <Input label="Full Name *" value={form.name} onChange={f('name')} />
        <Input label="Email *" type="email" value={form.email} onChange={f('email')} />
        <Input label="Password *" type="password" value={form.password} onChange={f('password')} />
        <Select label="Role" value={form.role} onChange={f('role')} options={[{value:'support',label:'Support'},{value:'content_manager',label:'Content Manager'},{value:'manager',label:'Manager'},{value:'admin',label:'Admin'}]} />
        <div style={{ display:'flex', gap:10, justifyContent:'flex-end', marginTop:4 }}>
          <Btn variant="ghost" onClick={()=>setModal(false)}>Cancel</Btn>
          <Btn onClick={createStaff}>Create Staff</Btn>
        </div>
      </Modal>
    </PageWrap>
  );
}

// ─── AUDIT LOGS ───────────────────────────────────────────────────────────────
function AuditLogs() {
  const [logs, setLogs] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  useEffect(() => {
    api.get(`/api/admin/audit-logs?page=${page}&limit=50`).then(r=>{ setLogs(r.data.logs||[]); setTotal(r.data.total||0); });
  }, [page]);
  return (
    <PageWrap title={`Audit Logs (${total})`}>
      <Card>
        <Table cols={['Time','User','Role','Action','Resource','IP','Result']} rows={logs} renderRow={l=><>
          <TD muted style={{ fontSize:11 }}>{new Date(l.createdAt).toLocaleString()}</TD>
          <TD muted>{l.userEmail||'–'}</TD>
          <TD><Badge>{l.userRole||'–'}</Badge></TD>
          <TD><span style={{ fontFamily:'monospace', fontSize:11, color:S.accent }}>{l.action}</span></TD>
          <TD muted>{l.resource}{l.resourceId?` (${l.resourceId.slice(-6)})`:''}​</TD>
          <TD muted style={{ fontSize:11 }}>{l.ipAddress}</TD>
          <TD><Badge color={l.success?S.success:S.danger}>{l.success?'OK':'FAIL'}</Badge></TD>
        </>} />
        <div style={{ display:'flex', gap:8, marginTop:16, justifyContent:'center' }}>
          {Array.from({length:Math.min(8,Math.ceil(total/50))},(_,i)=>i+1).map(p=><button key={p} onClick={()=>setPage(p)} style={{ padding:'4px 10px', borderRadius:6, border:`1px solid ${S.border}`, background:p===page?S.accent:'transparent', color:S.text, cursor:'pointer', fontSize:12 }}>{p}</button>)}
        </div>
      </Card>
    </PageWrap>
  );
}

// ─── SETTINGS ─────────────────────────────────────────────────────────────────
function Settings() {
  const { addToast } = useToastStore();
  const [settings, setSettings] = useState({});
  const [saving, setSaving] = useState(false);
  useEffect(() => { api.get('/api/admin/settings').then(r=>setSettings(r.data.settings||{})); }, []);
  const set = k => e => setSettings(p=>({...p,[k]:e.target.value}));
  const save = async () => {
    setSaving(true);
    await api.put('/api/admin/settings', settings);
    addToast('Settings saved','success'); setSaving(false);
  };
  const fields = [
    { key:'store_name',       label:'Store Name',        type:'text' },
    { key:'store_tagline',    label:'Tagline',            type:'text' },
    { key:'store_email',      label:'Support Email',      type:'email' },
    { key:'store_phone',      label:'Support Phone',      type:'text' },
    { key:'store_currency',   label:'Default Currency',   type:'text' },
    { key:'store_tax_rate',   label:'Tax Rate (%)',        type:'number' },
    { key:'store_min_order',  label:'Min Order Amount',   type:'number' },
    { key:'maintenance_mode', label:'Maintenance Mode',   type:'text', placeholder:'off / on' },
    { key:'order_prefix',     label:'Order Number Prefix',type:'text' },
    { key:'smtp_from_name',   label:'Email From Name',    type:'text' },
    { key:'footer_text',      label:'Footer Text',        type:'text' },
    { key:'terms_url',        label:'Terms & Conditions URL', type:'url' },
    { key:'privacy_url',      label:'Privacy Policy URL', type:'url' },
  ];
  return (
    <PageWrap title="Store Settings" action={<Btn onClick={save} disabled={saving}>{saving?'Saving...':'Save Settings'}</Btn>}>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0 24px', maxWidth:800 }}>
        {fields.map(f=>(
          <div key={f.key} style={{ marginBottom:16 }}>
            <div style={{ fontSize:12, color:S.muted, marginBottom:5 }}>{f.label}</div>
            <input type={f.type} value={settings[f.key]||''} onChange={set(f.key)} placeholder={f.placeholder||''} style={{ width:'100%', background:'#0a0a14', border:`1px solid ${S.border}`, borderRadius:8, padding:'9px 12px', color:S.text, fontSize:13, outline:'none', boxSizing:'border-box' }} />
          </div>
        ))}
      </div>
    </PageWrap>
  );
}

// ─── MAIN LAYOUT ──────────────────────────────────────────────────────────────
export default function AdminLayout() {
  const { user } = useAuthStore();
  const location = useLocation();
  const seg = location.pathname.replace('/admin','').replace(/^\//,'').split('/')[0];

  if (!user || !['admin','super_admin','manager','support','content_manager'].includes(user.role)) {
    return (
      <div style={{ height:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:S.bg, color:S.muted }}>
        <div style={{ textAlign:'center' }}><div style={{ fontSize:40, marginBottom:16 }}>🔒</div><div style={{ fontSize:18, color:S.text, marginBottom:8 }}>Access Denied</div><div style={{ fontSize:13 }}>Admin privileges required</div></div>
      </div>
    );
  }

  return (
    <div style={{ display:'flex', height:'100vh', background:S.bg, color:S.text, overflow:'hidden' }}>
      <Sidebar current={seg} userRole={user.role} />
      <main style={{ flex:1, overflowY:'auto' }}>
        <Routes>
          <Route path="/"              element={<Dashboard />} />
          <Route path="/products"      element={<Products />} />
          <Route path="/categories"    element={<Categories />} />
          <Route path="/orders"        element={<Orders />} />
          <Route path="/customers"     element={<Customers />} />
          <Route path="/subscriptions" element={<Subscriptions />} />
          <Route path="/inventory"     element={<Inventory />} />
          <Route path="/homepage"      element={<Homepage />} />
          <Route path="/coupons"       element={<Coupons />} />
          <Route path="/payments"      element={<Payments />} />
          <Route path="/support"       element={<Support />} />
          <Route path="/analytics"     element={<Analytics />} />
          <Route path="/roles"         element={<Roles />} />
          <Route path="/audit"         element={<AuditLogs />} />
          <Route path="/settings"      element={<Settings />} />
        </Routes>
      </main>
    </div>
  );
}
